title: Jdk动态代理和cglib动态代理使用方法
date: '2021-08-23 08:50:45'
updated: '2021-08-23 08:50:45'
tags: [java]
permalink: /articles/2021/08/23/1629679845539.html
---
![](https://b3logfile.com/bing/20190206.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

**JDK动态代理**
![jdk动态代里接口.png](https://b3logfile.com/file/2021/08/jdk动态代里接口-cb80b637.png)

**cglib动态代理**
![cglib动态代里类.png](https://b3logfile.com/file/2021/08/cglib动态代里类-9aca8f1c.png)

