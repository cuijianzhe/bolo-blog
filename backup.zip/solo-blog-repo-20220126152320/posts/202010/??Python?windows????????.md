title: 利用Python对windows桌面自动更换壁纸
date: '2020-10-29 11:48:30'
updated: '2020-10-31 14:18:08'
tags: [Python]
permalink: /articles/2020/10/29/1603943310078.html
---
### 根据时间星期几判断用哪张壁纸

```python
# !/usr/bin/env python3
# -*- coding:utf-8 -*-
import requests
# import pywintypes
import win32api
import win32con
import win32gui
import os
import datetime,time
from PIL import Image
def get_week_day(date):
  week_day_dict = {
    0 : '星期一',
    1 : '星期二',
    2 : '星期三',
    3 : '星期四',
    4 : '星期五',
    5 : '星期六',
    6 : '星期天',
  }
  day = date.weekday()
  return week_day_dict[day]

# print(get_week_day(datetime.datetime.now()))
def getImages():

    filepath = os.path.split(os.path.realpath(__file__))[0]   # 本地目录路径
    # print(filepath)
    dayNum = datetime.datetime.now().weekday()
    img_url = "http://imgmanage.com/images/{}/test.jpg".format(dayNum)
    img_data = requests.get(img_url)
    # filename = filepath + '\\' + "{}.jpg".format(get_week_day(datetime.datetime.now()))
    filename = filepath +  '/test.jpg'
    bmpImage = Image.open(filename)
    newPath = filename.replace('.jpg', '.bmp')
    bmpImage.save(newPath, "BMP")
    with open(filename, "wb")as f:
        f.write(img_data.content)
    return newPath


def setWallpaper(image_path):
    key = win32api.RegOpenKeyEx(win32con.HKEY_CURRENT_USER, "Control Panel\\Desktop", 0, win32con.KEY_SET_VALUE)
    win32api.RegSetValueEx(key, "WallpaperStyle", 0, win32con.REG_SZ, "2")
    win32api.RegSetValueEx(key, "TileWallpaper", 0, win32con.REG_SZ, "0")
    win32gui.SystemParametersInfo(win32con.SPI_SETDESKWALLPAPER, image_path, 1 + 2)


if __name__ == "__main__":
    time.sleep(15)
    image_path = getImages()
    setWallpaper(image_path)
```

