title: MyBatis(1)高级应用
date: '2022-04-11 14:47:49'
updated: '2022-04-11 14:47:49'
tags: [java]
permalink: /articles/2022/04/11/1649659669550.html
---
![](https://b3logfile.com/bing/20171201.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

MyBatis的特点：

1. 使用连接池对连接进行管理
2. SQL和代码分离，集中管理
3. 结果集映射
4. 参数映射和动态SQL
5. 重复SQL的提取
6. 缓存管理
7. 插件机制

##### MyBatis核心配置

###### 全局配置文件

MyBatis 的配置文件包含了会深深影响 MyBatis 行为的设置和属性信息。 配置文档的顶层结构如下：

> configuration（配置）
> properties（属性）
> settings（设置）
> typeAliases（类型别名）
> typeHandlers（类型处理器）
> objectFactory（对象工厂）
> plugins（插件）
> environments（环境配置）
> environment（环境变量）
> transactionManager（事务管理器）
> dataSource（数据源）
> databaseIdProvider（数据库厂商标识）
> mappers（映射器）

##### MyBatis最佳实践

###### Executor

> 1. SimpleExecutor：每执行一次update或select，就开启一个Statement对象，用完立刻关闭Statement对象。
> 2. ReuseExecutor：执行update或select，以sql作为key查找Statement对象，存在就使用，不存在就创建，用完后，不关闭Statement对象，而是放置于Map内，供下一次使用。简言之，就是重复使用Statement对象。
> 3. BatchExecutor：执行update（没有select，JDBC批处理不支持select），将所有sql都添加到批处理中（addBatch()），等待统一执行（executeBatch()），它缓存了多个Statement对象，每个Statement对象都是addBatch()完毕后，等待逐一执行executeBatch()批处理。与JDBC批处理相同。executeUpdate()是一个语句访问一次数据库，executeBatch()是一批语句访问一次数据库（具体一批发送多少条SQL跟服务端的max_allowed_packet有关）。BatchExecutor底层是对JDBC ps.addBatch()和ps. executeBatch()的封装。

###### 关联查询

用户和部门的对应关系是1对1的关系

```xml
<resultMap id="nestedMap1" type="user">
	<id property="id" column="id" jdbcType="INTEGER"/>
	<result property="userName" column="user_name" jdbcType="VARCHAR" />
	<result property="realName" column="real_name" jdbcType="VARCHAR" />
	<association property="dept" javaType="dept">
		<id column="did" property="dId"/>
		<result column="d_name" property="dName"/>
		<result column="d_desc" property="dDesc"/>
	</association>
</resultMap>
```

还有就是1对多的关联关系

```xml
<resultMap id="nestedMap2" type="dept">
	<id column="did" property="dId"/>
	<result column="d_name" property="dName"/>
	<result column="d_desc" property="dDesc"/>
	<collection property="users" ofType="user">
		<id property="id" column="id" jdbcType="INTEGER"/>
		<result property="userName" column="user_name" jdbcType="VARCHAR" />
		<result property="password" column="password" jdbcType="VARCHAR"/>
	</collection>
</resultMap>
```

###### 延迟加载

```xml
<!--延迟加载的全局开关。当开启时，所有关联对象都会延迟加载。默认false -->
<setting name="lazyLoadingEnabled" value="true"/>
<!--当开启时，任何方法的调用都会加载该对象的所有属性。默认false，可通过select标签的fetchType来覆盖-->
<!-- aggressiveLazyLoading决定了是不是对象的所有方法都会触发查询。 -->
<setting name="aggressiveLazyLoading" value="false"/>
<!-- MyBatis 创建具有延迟加载能力的对象所用到的代理工具，默认JAVASSIST -->
<setting name="proxyFactory" value="CGLIB" />
```



