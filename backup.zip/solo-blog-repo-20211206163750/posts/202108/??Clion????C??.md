title: 使用Clion创建运行C++代码
date: '2021-08-29 00:27:22'
updated: '2021-08-29 00:30:39'
tags: [c++]
permalink: /articles/2021/08/29/1630168042484.html
---
![](https://b3logfile.com/bing/20210506.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

#### 下载Clion

[Clion](https://www.jetbrains.com/clion/)
![image.png](https://b3logfile.com/file/2021/08/image-4ef2345f.png)

#### 创建new-project

![image.png](https://b3logfile.com/file/2021/08/image-6ca2befa.png)

#### 创建项目后进去是这个界面

![image.png](https://b3logfile.com/file/2021/08/image-53bf53f2.png)

#### 打开setting添加C++的编译环境

![image.png](https://b3logfile.com/file/2021/08/image-2034ccd3.png)

#### 下载mingw-w64

![image.png](https://b3logfile.com/file/2021/08/image-7799dc70.png)
或者直接从这里下载[mingww64install.rar](https://b3logfile.com/file/2021/08/mingw-w64-install-c5e7800f.rar)

#### 运行main.cpp

![image.png](https://b3logfile.com/file/2021/08/image-d12d046f.png)

#### 新建一个test.cpp

安装一个可以快速添加新文件到构建环境的一个插件

![image.png](https://b3logfile.com/file/2021/08/image-f716d7a5.png)
将test.cpp构建到当前项目的环境下

![image.png](https://b3logfile.com/file/2021/08/image-b334345d.png)

然后别忘了Reload changed一下
![image.png](https://b3logfile.com/file/2021/08/image-8b8fd54f.png)

然后切换一下运行的文件，运行即可

![image.png](https://b3logfile.com/file/2021/08/image-e12b19e0.png)

成功啦

![image.png](https://b3logfile.com/file/2021/08/image-52190375.png)


[控制台中文乱码问题解决博客参考](https://blog.csdn.net/weixin_43912367/article/details/104886495)

