title: confluence自启动
date: '2022-01-21 23:43:13'
updated: '2022-01-25 21:06:16'
tags: [Linux]
permalink: /articles/2022/01/21/1642779793133.html
---
```bash
[root@system-wiki ~]# cat /usr/lib/systemd/system/wiki.service 
[Unit]
Description=Wiki

[Service]
Type=simple
PIDFile=/usr/local/atlassian/confluence/work/catalina.pid
ExecStartPre=rm -rf /usr/local/atlassian/confluence/work/catalina.pid
ExecStart=/usr/local/atlassian/confluence/bin/startup.sh
ExecStop=/usr/local/atlassian/confluence/bin/shutdown.sh
PrivateTmp=true
Restart=always
User=confluence
Group=confluence
[Install]
WantedBy=multi-user.target
```

pid设置文件：`/usr/local/atlassian/confluence/bin/setenv.sh`

