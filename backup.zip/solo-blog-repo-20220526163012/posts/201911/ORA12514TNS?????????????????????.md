title: 'ORA-12514: TNS:监听程序当前无法识别连接描述符中请求的服务'
date: '2019-11-15 12:24:33'
updated: '2019-11-15 12:24:33'
tags: [oracle]
permalink: /articles/2019/11/15/1573791873098.html
---
![](https://img.hacpai.com/bing/20190614.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

### 艹艹艹艹艹艹艹艹艹艹艹艹艹艹艹艹艹艹艹艹艹艹艹艹艹艹艹艹艹


将这几个ora配置文件替换了即可！

https://xyt.cjzshilong.cn/listener.ora
https://xyt.cjzshilong.cn/tnsnames.ora
https://xyt.cjzshilong.cn/sqlnet.ora

