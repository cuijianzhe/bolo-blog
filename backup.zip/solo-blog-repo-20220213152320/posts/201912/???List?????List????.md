title: 拆分大List为若干个小List的工具类
date: '2019-12-02 09:37:20'
updated: '2019-12-02 09:37:20'
tags: [java]
permalink: /articles/2019/12/02/1575250640223.html
---
### 第一种
```
package com.ulane.spring.job.util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author Xu Yuntong
 * @date 2019/11/30 17:41
 */
public class SubListToMapUtil {

    /**
     * 截取list集合，返回map集合
     * @param tList  (需要截取的集合)
     * @param subNum  (每次截取的数量)
     * @return
     */
    public static<T> Map<Integer, List<T>> subListToMap(List<T> tList, Integer subNum) {
        // 新的截取到的list集合
        //List<List<T>> tNewList = new ArrayList<List<T>>();
        Map<Integer, List<T>> newTlsMap = new HashMap<Integer, List<T>>();
        // 要截取的下标上限
        Integer priIndex = 0;
        // 要截取的下标下限
        Integer lastIndex = 0;
        // 每次插入list的数量
        // Integer subNum = 500;
        // 查询出来list的总数目
        Integer totalNum = tList.size();
        // 总共需要插入的次数
        Integer insertTimes = totalNum / subNum;
        List<T> subNewList = new ArrayList<T>();
        for (int i = 0; i <= insertTimes; i++) {
            // [0--20) [20 --40) [40---60) [60---80) [80---100)
            priIndex = subNum * i;
            lastIndex = priIndex + subNum;
            // 判断是否是最后一次
            if (i == insertTimes) {
                //logger.info(priIndex + "," + tList.size());
                //logger.info("--------------------------------------");
                subNewList = tList.subList(priIndex, tList.size());
            } else {
                // 非最后一次
                //logger.info("最后一次截取："+priIndex + "," + lastIndex);
                //logger.info("***************************************");
                subNewList = tList.subList(priIndex, lastIndex);

            }
            if (subNewList.size() > 0) {
                //logger.info("开始将截取的list放入新的list中");
                newTlsMap.put(i, subNewList);
            }

        }

        return newTlsMap;
    }
}

```



#### 使用方法
```java
    public void addHwAgents(List<HwAgent> list) {
        //一条sql中有9个?变量，最多可一次性插入7182个数据，要拆分list小批量插入
        Map<Integer, List<HwAgent>> integerListMap = SubListToMapUtil.subListToMap(list, 3000);
        Iterator<Map.Entry<Integer, List<HwAgent>>> iterator = integerListMap.entrySet().iterator();
        while(iterator.hasNext()){
            Map.Entry<Integer, List<HwAgent>> next = iterator.next();
            List<HwAgent> value = next.getValue();
            agentQueryDao.addHwAgents(value);
        }
    }
```
