title: SpringBoot线程池和异步任务
date: '2022-02-09 17:00:41'
updated: '2022-02-09 17:01:51'
tags: [java]
permalink: /articles/2022/02/09/1644397241317.html
---
![](https://b3logfile.com/bing/20190204.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

线程池和异步任务,这是两个互不干扰的东西,使用起来需要注意两个点:

* 需要使用线程池管理的的实例方法要增加@Async注解
* 并且Application需要增加@EnableAsync注解


###### demo的java文件层级

└─com
└─example
└─demo
│  DemoApplication.java
│<br />            ├─async
│      AsyncDemo.java
│<br />            ├─config
│      SchedulerConfiguration.java
│      TaskExecutorConfiguration.java
│<br />            └─web
TestController.java

> DemoApplication

```java
package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableAsync;

@SpringBootApplication
@EnableAsync
public class DemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(DemoApplication.class, args);
    }

}
```

> TestController

```java
package com.example.demo.web;

import com.example.demo.async.AsyncDemo;
import com.example.demo.config.SchedulerConfiguration;
import org.springframework.scheduling.TaskScheduler;
import org.springframework.scheduling.support.CronTrigger;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.UUID;
import java.util.concurrent.ScheduledFuture;

/**
 * @author xuy
 * @date 2022/2/9 14:36
 */
@RestController
@RequestMapping("/test")
public class TestController {
    @Resource
    protected SchedulerConfiguration schedulerConfiguration;
    @Resource
    private AsyncDemo asyncExceptionDemo;

    @RequestMapping("/start")
    public String start() {

        for (int i = 0; i < 20; i++) {
            String id = UUID.randomUUID().toString();
            TaskScheduler scheduler = schedulerConfiguration.getTaskRegistrar().getScheduler();
            ScheduledFuture<?> schedule = scheduler.schedule(() -> {
                asyncExceptionDemo.asyncInvokeSimplest();
            }, new CronTrigger("53 * * * * ? "));
            //cron表达式只在特定时间点执行一次
            SchedulerConfiguration.taskMap.put(id, schedule);
        }

        return "ok";
    }

    @RequestMapping("/list")
    public String list() {
        int length = SchedulerConfiguration.taskMap.keySet().size();
        return "有" + length + "个异步任务在执行," + "taskMap为: "+ SchedulerConfiguration.taskMap.entrySet().toString();
    }

    @GetMapping("/{uuid}")
    public String getone(@PathVariable String uuid){
        ScheduledFuture<?> scheduledFuture = SchedulerConfiguration.taskMap.get(uuid);
        String status = scheduledFuture.isCancelled() ? "已取消" : "执行中";
        return "改异步任务的完成情况: " + status;
    }

    @GetMapping("/cancel/{uuid}")
    public String cancel(@PathVariable String uuid){
        ScheduledFuture<?> scheduledFuture = SchedulerConfiguration.taskMap.get(uuid);
        scheduledFuture.cancel(true);
        return "cancel";
    }
}
```

> TaskExecutorConfiguration

```java
package com.example.demo.config;

import org.springframework.aop.interceptor.AsyncUncaughtExceptionHandler;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.AsyncConfigurer;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import java.lang.reflect.Method;
import java.util.concurrent.Executor;
import java.util.concurrent.ThreadPoolExecutor;

/**
 * @author xuyt
 * @date 2022/2/9 14:19
 */
@Configuration
public class TaskExecutorConfiguration implements AsyncConfigurer {

    @Override
    public Executor getAsyncExecutor() {
        return this.taskExecutor();
    }

    @Override
    public AsyncUncaughtExceptionHandler getAsyncUncaughtExceptionHandler() {
        return (Throwable throwable, Method method, Object... objects) -> {
            System.out.println("出错");
            System.out.println(throwable.getMessage());
        };
    }

    @Bean(name = "taskExecutor", destroyMethod = "shutdown")
    public ThreadPoolTaskExecutor taskExecutor() {
        ThreadPoolTaskExecutor taskExecutor = new ThreadPoolTaskExecutor();
        taskExecutor.setCorePoolSize(2);
        taskExecutor.setMaxPoolSize(2);
        taskExecutor.setQueueCapacity(200);
        taskExecutor.setAllowCoreThreadTimeOut(true);
        taskExecutor.setKeepAliveSeconds(60);
        //拒绝策略
        taskExecutor.setRejectedExecutionHandler((Runnable r, ThreadPoolExecutor executor) -> {
            try {
                if (!executor.isShutdown()) {
                    executor.getQueue().put(r);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
        taskExecutor.initialize();
        return taskExecutor;
    }

}
```

> SchedulerConfiguration

```java
package com.example.demo.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.TaskScheduler;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.SchedulingConfigurer;
import org.springframework.scheduling.concurrent.ThreadPoolTaskScheduler;
import org.springframework.scheduling.config.ScheduledTaskRegistrar;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ScheduledFuture;

/**
 * @author xuyt
 * @date 2022/2/9 14:19
 */
@Configuration
@EnableScheduling
public class SchedulerConfiguration implements SchedulingConfigurer {

    private ScheduledTaskRegistrar taskRegistrar;

    public static Map<String, ScheduledFuture<?>> taskMap = new ConcurrentHashMap<>();

    @Override
    public void configureTasks(ScheduledTaskRegistrar scheduledTaskRegistrar) {
        TaskScheduler scheduler = this.scheduler();
        scheduledTaskRegistrar.setTaskScheduler(scheduler);
        this.taskRegistrar = scheduledTaskRegistrar;
    }

    @Bean(name = "scheduler", destroyMethod = "shutdown")
    public ThreadPoolTaskScheduler scheduler() {
        ThreadPoolTaskScheduler scheduler = new ThreadPoolTaskScheduler();
        scheduler.setPoolSize(20);
        scheduler.setThreadNamePrefix("xuytscheduler-");
        scheduler.setAwaitTerminationSeconds(3600);
        scheduler.setWaitForTasksToCompleteOnShutdown(true);
        return scheduler;
    }

    public ScheduledTaskRegistrar getTaskRegistrar() {
        return this.taskRegistrar;
    }
}
```

> AsyncDemo

```java
package com.example.demo.async;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.AsyncResult;
import org.springframework.stereotype.Component;

import java.util.concurrent.Future;

/**
 * @author xuyt
 * @date 2022/2/9 15:43
 */
@Component
public class AsyncDemo {
    private static final Logger log = LoggerFactory.getLogger(AsyncDemo.class);


    /**
     * 最简单的异步调用，返回值为void
     */
    @Async
    public void asyncInvokeSimplest() {
        System.out.println("当前线程ID: " + Thread.currentThread().getId());
        try {
            //拖延时间
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    /**
     * 异常调用返回Future
     *  对于返回值是Future，不会被AsyncUncaughtExceptionHandler处理，需要我们在方法中捕获异常并处理
     *  或者在调用方在调用Futrue.get时捕获异常进行处理
     *
     * @param i
     * @return
     */
    @Async
    public Future<String> asyncInvokeReturnFuture(int i) {
        log.info("asyncInvokeReturnFuture, parementer={}", i);
        Future<String> future;
        try {
            Thread.sleep(1000 * 1);
            future = new AsyncResult<String>("success:" + i);
            throw new IllegalArgumentException("a");
        } catch (InterruptedException e) {
            future = new AsyncResult<String>("error");
        } catch(IllegalArgumentException e){
            future = new AsyncResult<String>("error-IllegalArgumentException");
        }
        return future;
    }

}
```

