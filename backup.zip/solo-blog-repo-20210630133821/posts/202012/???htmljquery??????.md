title: 不错的html-jquery开源标签插件
date: '2020-12-16 16:09:39'
updated: '2020-12-16 16:09:39'
tags: [工作]
permalink: /articles/2020/12/16/1608106179503.html
---
![](https://b3logfile.com/bing/20190114.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

#### 是开源的,在github上的,官网贴在下方

`http://xoxco.com/projects/code/tagsinput/`

#### 效果图

![image.png](https://b3logfile.com/file/2020/12/image-39d8df4f.png)

#### 使用

```
<link rel="stylesheet" type="text/css" href="/jquery.tagsinput.css" />
<script type="text/javascript" src="/jquery.tagsinput.js"></script>
```

```
<input class="tags" id="keyword" type="text" value="肛内混合痔"/>
```

```
$(function(){
$('#keyword').tagsInput({width:'auto', 'defaultText': '添加'});
});
````

