title: JDK8的日期时间操作
date: '2021-11-18 23:10:32'
updated: '2021-11-18 23:10:32'
tags: [java]
permalink: /articles/2021/11/18/1637248232075.html
---
![](https://b3logfile.com/bing/20190421.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

##### 查询当前日期(年月日)

```java
LocalDate localDate = LocalDate.now();
System.out.println(localDate);//2021-11-18
```

##### 查询当前时间(时分秒)

```java
LocalTime localTime = LocalTime.now();
String format = localTime.format(DateTimeFormatter.ofPattern("HH:mm:ss"));
System.out.println(localTime.getHour()+":"+localTime.getMinute()+":"+localTime.getSecond());//11:09:24
System.out.println(format);//11:09:24
```

##### 查询当前日期时间(年月日时分秒)

```java
LocalDateTime localDateTime = LocalDateTime.now();
System.out.println(localDateTime.getYear() + "-" + localDateTime.getMonthValue() +
        "-" + localDateTime.getDayOfMonth() + " " + localDateTime.getHour() + ":" +
        localDateTime.getMinute() + ":" + localDateTime.getSecond());//2021-11-18 11:19:34
System.out.println(localDateTime.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));//2021-11-18 11:19:34
```

##### 查询昨天、明天

```java
LocalDate localDate = LocalDate.now();//2021-11-18
System.out.println(localDate.plusDays(-1));//2021-11-17
System.out.println(localDate.plusDays(1));//2021-11-19
```

##### 查询当天最小、最大时间

```java
LocalDateTime localDateTime = LocalDateTime.now();//2021-11-18
System.out.println(localDateTime.with(LocalTime.MIN));//2021-11-18T00:00
System.out.println(LocalDateTime.of(LocalDate.now(), LocalTime.MIN));//2021-11-18T00:00
System.out.println(localDateTime.with(LocalTime.MAX));//2021-11-18T23:59:59.999999999
System.out.println(LocalDateTime.of(LocalDate.now(), LocalTime.MAX));//2021-11-18T23:59:59.999999999
```

##### 查询本年第66天

```java
LocalDate localDate = LocalDate.now().withDayOfYear(66);
System.out.println(localDate);
```

##### 查询当天是周、月、季度、年第几天

```java
LocalDate nowDate = LocalDate.now();//2021-11-18
System.out.println(nowDate.getDayOfWeek().getValue());//4
System.out.println(nowDate.getDayOfMonth());//18
System.out.println(nowDate.get(IsoFields.DAY_OF_QUARTER));//49
System.out.println(nowDate.getDayOfYear());//322
```

##### 查询本周第一天 offset 0本周，1下周，-1上周，依次类推

```java
LocalDate localDate = LocalDate.now().plusWeeks(0);
System.out.println(localDate.with(DayOfWeek.MONDAY));//2021-11-15
```

##### 查询本周最后一天 offset 0本周，1下周，-1上周，依次类推

```java
LocalDate localDate = LocalDate.now().plusWeeks(0);
System.out.println(localDate.with(DayOfWeek.SUNDAY));//2021-11-21
```

##### 查询当周是月、年的第几周

```java
LocalDate nowDate = LocalDate.now();//2021-11-18
WeekFields of = WeekFields.of(DayOfWeek.MONDAY, 1);//一天就定义为一周，否则2017年1月1日不被纳入第一周
System.out.println(nowDate.get(ChronoField.ALIGNED_WEEK_OF_MONTH));//3
System.out.println(nowDate.get(of.weekOfYear()));//46
```

##### 查询本月第一天

```java
LocalDate firstDayOfMonth = LocalDate.now().with(TemporalAdjusters.firstDayOfMonth());
System.out.println(firstDayOfMonth);//2021-11-01
firstDayOfMonth = LocalDate.now().withDayOfMonth(1);
System.out.println(firstDayOfMonth);//2021-11-01
```

##### 查询本月最后一天

```java
LocalDate lastDayOfMonth = LocalDate.now().with(TemporalAdjusters.lastDayOfMonth());
System.out.println(lastDayOfMonth);//2021-11-30
```

##### 查询当月是季度第几月

```java
LocalDate nowDate = LocalDate.now();//2021-11-18
int firstMonthOfQuarter = nowDate.getMonth().firstMonthOfQuarter().getValue();
System.out.println(nowDate.getMonth().getValue() + 1 - firstMonthOfQuarter);//2
```

##### 查询当前季度

```java
LocalDate nowDate = LocalDate.now();//2021-11-18
System.out.println(nowDate.get(IsoFields.QUARTER_OF_YEAR));//4
```

##### 查询本季度第一天

```java
LocalDate nowDate = LocalDate.now();//2021-11-18
int firstMonthOfQuarter = nowDate.getMonth().firstMonthOfQuarter().getValue();
System.out.println(firstMonthOfQuarter);//10
nowDate = LocalDate.of(nowDate.getYear(), firstMonthOfQuarter, 1);
System.out.println(nowDate);//2021-10-01
```

##### 查询本季度最后一天

```java
LocalDate nowDate = LocalDate.now();//2021-11-18
int firstMonthOfQuarter = nowDate.getMonth().firstMonthOfQuarter().getValue();
System.out.println(firstMonthOfQuarter);//10
Month endMonthOfQuarter = Month.of(firstMonthOfQuarter + 2);
int monthLength = endMonthOfQuarter.length(nowDate.isLeapYear());
System.out.println(monthLength);//31
nowDate = LocalDate.of(nowDate.getYear(), endMonthOfQuarter, monthLength);
System.out.println(nowDate);//2021-12-31
```

##### 查询本年第一天

```java
LocalDate localDate = LocalDate.now().withMonth(1).withDayOfYear(1);
System.out.println(localDate);//2021-01-01
LocalDate firstDayOfYear = LocalDate.now().with(TemporalAdjusters.firstDayOfYear());
System.out.println(firstDayOfYear);//2021-01-01
```

##### 查询本年最后一天

```java
LocalDate localDate = LocalDate.now().with(TemporalAdjusters.lastDayOfYear());
System.out.println(localDate);//2021-12-31
```

##### 判断输入年份是否是闰年

```java
System.out.println(LocalDate.now().isLeapYear());//false
```

##### 计算两个日期之间的年数、月数、周数、天数、小时、分钟、秒数

```java
LocalDate localDate1 = LocalDate.of(2020, 6, 6);
LocalDate localDate2 = LocalDate.of(2021, 11, 18);
System.out.println(localDate1.until(localDate2, ChronoUnit.YEARS));//1
System.out.println(localDate1.until(localDate2, ChronoUnit.MONTHS));//17
System.out.println(localDate1.until(localDate2, ChronoUnit.WEEKS));//75
System.out.println(localDate1.until(localDate2, ChronoUnit.DAYS));//530
LocalDateTime localDateTime1 = LocalDateTime.of(2020, 6, 6, 1, 1, 1);
LocalDateTime localDateTime2 = LocalDateTime.of(2021, 11, 18, 2, 2, 2);
System.out.println(localDateTime1.until(localDateTime2, ChronoUnit.HOURS));//12721
System.out.println(localDateTime1.until(localDateTime2, ChronoUnit.MINUTES));//763261
System.out.println(localDateTime1.until(localDateTime2, ChronoUnit.SECONDS));//45795661
```

##### 比较两个日期的大小

```java
LocalDateTime localDateTime1 = LocalDateTime.of(2021, 11, 18, 15, 29, 00);
LocalDateTime localDateTime2 = LocalDateTime.of(2222, 11, 18, 15, 29, 00);
System.out.println(localDateTime1.toLocalDate().equals(localDateTime2.toLocalDate()));//是否为同一天 false
System.out.println(localDateTime1.isBefore(localDateTime2));//true
System.out.println(localDateTime1.isAfter(localDateTime2));//false
```

##### 日期转字符串

```java
ZonedDateTime zonedDateTime = ZonedDateTime.now();
DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss").format(zonedDateTime);
DateTimeFormatter.ofPattern("yyyy-MM-dd").format(zonedDateTime);//等同于DateTimeFormatter.ISO_LOCAL_DATE.format(zonedDateTime);
DateTimeFormatter.ofPattern("yyyy年MM月dd日 HH时mm分ss秒").format(zonedDateTime);
DateTimeFormatter.ofPattern("yyyy年MM月dd日").format(zonedDateTime);
DateTimeFormatter.ofPattern("yyyy-MM").format(zonedDateTime);
DateTimeFormatter.ofPattern("yyyy年MM月").format(zonedDateTime);
DateTimeFormatter.ofPattern("yyyyMMdd").format(zonedDateTime);
DateTimeFormatter.ofPattern("yyyyMM").format(zonedDateTime);
```

##### 字符串转日期

```java
DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy年MM月dd日");
System.out.println(LocalDate.parse("2020年03月25日", dateTimeFormatter));//2020-03-25
System.out.println(LocalDate.from(dateTimeFormatter.parse("2020年03月25日")));//2020-03-25
System.out.println(dateTimeFormatter.parse("2020年03月25日", LocalDate::from));//2020-03-25
```

##### LocalDate 转 Date

```java
LocalDate localDate = LocalDate.now();
Instant instant = localDate.atStartOfDay(ZoneId.systemDefault()).toInstant();
Date from = Date.from(instant);
System.out.println(from);//Thu Nov 18 00:00:00 GMT+08:00 2021
```

##### LocalDateTime 转 Date

```java
LocalDateTime localDateTime = LocalDateTime.now();
Instant instant = localDateTime.atZone(ZoneId.systemDefault()).toInstant();
Date from = Date.from(instant);
System.out.println(from);//Thu Nov 18 15:34:33 GMT+08:00 2021
```

##### Date 转 LocalDate

```java
Date date = new Date();
LocalDate localDate = date.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
System.out.println(localDate);//2021-11-18
```

##### Date 转 LocalDate

```java
Date date = new Date();
LocalDateTime localDateTime = date.toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime();
System.out.println(localDateTime);//2021-11-18T15:37:16.759
LocalDateTime localDateTime1 = LocalDateTime.ofInstant(date.toInstant(), ZoneId.systemDefault());
System.out.println(localDateTime1);//2021-11-18T15:38:03.267
```

