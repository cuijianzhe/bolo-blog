title: Idea不靠Main方法运行Java代码
date: '2021-02-08 17:06:36'
updated: '2021-02-08 17:16:41'
tags: [java]
permalink: /articles/2021/02/08/1612775196273.html
---
![](https://b3logfile.com/bing/20190808.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

#### 发现问题

这配图吓我一跳

有时候工作当中
我们需要编写一个`正则表达式`
看其是否可以用来校验字符串为邮箱格式
那一般我们会新建一个Test.java,然后在类中新建一个main方法
Such As:

```java
/**
 * @author xuyuntong
 * @date 2021/2/8 16:36
 */
public class Test {
    public static void main(String[] args) {
        String reg="[A-z]+[A-z0-9_-]*\\@[A-z0-9]+\\.[A-z]+";
        System.out.println("wyp5502123@163.com".matches(reg));
    }
}
```

#### 分析问题

相信肯定好多好多人(就你和我)觉得这样子好麻烦
每次有这样的需求难道都创建一个这样的类?,那也太麻烦了吧喂
还要注意不能提交到svn!!!
因为提交上去之后就会有版本记录痕迹
如果项目经理设置的不可以修改版本记录钩子,那么会是很丑陋的一次提交代码
也许会有人想着开发一款idea插件来弹出一个小框框,在其中运行自己的java代码,点击运行,啪,很快啊,出来结果了
**BUT**,开发IdeaPlugin门槛比较高,基本相当于欲练此功必先自宫
那么我们每天CRUD的码农还有没有活路了呢,答案是有的

#### 解决问题

那就是曲线救国,使用java官方指定的脚本语言Groovy
使用Groovy的话,我们上面说的正则表达式校验邮箱的代码就可以缩减为这样:

```groovy
def reg="[A-z]+[A-z0-9_-]*\\@[A-z0-9]+\\.[A-z]+";
System.out.println("wyp5502123@163.com".matches(reg));
```

那么这么好的药哪里能买得到呢?

<details>
  <summary><font color=blue>各大商场均有销售</font></summary>
  <p>没错,Idea已经贴心的内置了,开不开心意不意外,真的太棒了!</p>

![image.png](https://b3logfile.com/file/2021/02/image-ab0bdde2.png)

</details>

#### 残留问题

只使用java自带扩展包,不引入任何第三方jar包的情况下

| ✅ 支持     | ❌ 不支持 |
| ----------- | ----------- |
| stream流方法调用测试      | md5加密字符串|
| 操作日期类生成/校验日期字符串|    获取汉字姓名拼音/首字母    |
|正则表达式校验一段字符串为邮箱格式||
|确认for循环结果准确与否||
|比较两段代码运行时间||

