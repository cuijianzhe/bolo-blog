title: 分析linux的java进程的dump文件
date: '2022-03-15 14:50:44'
updated: '2022-03-18 13:22:34'
tags: [java]
permalink: /articles/2022/03/15/1647327044536.html
---
![](https://b3logfile.com/bing/20210914.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

#先参考我之前的一篇文章在服务器进行一个死锁的情景重现#

[检测死锁的文章](https://cjzshilong.cn/articles/2022/02/03/1643879655765.html)

###### 查看java进程

ps -ef|grep java

###### 针对进程id生成dump文件

jmap -dump:format=b,file=serviceDump.dat 14640

###### 使用jvisualvm.exe对dump进行分析（如果jdk的bin目录下没有，需要自行下载）

`https://visualvm.github.io/index.html`

* 修改visualvm.conf
* 加入JDK 路径 `visualvm_jdkhome="C:/Users/JavaCoder/.jdks/corretto-1.8.0_312"`
* 双击bin目录下的visualvm.exe打开
* 导入dump文件后查看死锁的线程

![image2022031513100795ztxvd.png](https://b3logfile.com/file/2022/03/image-20220315131007-95ztxvd-7a4c8da8.png)

##### 还有另外一种使用方式 jhat :

jhat 用于分析 heapdump 文件，它会建立一个 HTTP/HTML 服务器，让用户可以在浏览器上查看分析结果

```shell
C:\Users\SnailClimb>jhat C:\Users\SnailClimb\Desktop\heap.hprof
Reading from C:\Users\SnailClimb\Desktop\heap.hprof...
Dump file created Sat May 04 12:30:31 CST 2019
Snapshot read, resolving...
Resolving 131419 objects...
Chasing references, expect 26 dots..........................
Eliminating duplicate references..........................
Snapshot resolved.
Started HTTP server on port 7000
Server is ready.
```

访问 http://localhost:7000/

