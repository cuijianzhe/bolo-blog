title: Pgone、孙八一、小青龙、Jony J 剪辑作品展
date: '2019-03-05 23:08:16'
updated: '2019-11-19 11:29:07'
tags: [嘻哈, HIHPOP]
permalink: /articles/2019/03/05/1551798496474.html
---
### Pgone的《H.M.E》谁还记得？小青龙的《Time》何人不知，孙八一诙谐《take it easy》！

---

###       **这个diss了嘻哈大半个娱乐圈的人……我服** :dizzy_face:

https://file.cjzshilong.cn/video_file/pgone.mp4
 
---

###    **小青龙和辉子的精彩battle**  :+1: 
https://file.cjzshilong.cn/video_file/Time.mp4

### 小青龙60s-《Game》

https://file.cjzshilong.cn/video_file/%E5%B0%8F%E9%9D%92%E9%BE%99-Game-60%E7%A7%92.mp4

---
###     **这是我剪辑过的最喜欢的孙八一的作品** :+1: 
https://file.cjzshilong.cn/video_file/sunbayi.mp4

###  孙八一《还钱》

https://file.cjzshilong.cn/video_file/%E8%BF%98%E9%92%B1.mp4

### Jony J的《不用去猜》

https://file.cjzshilong.cn/video_file/%E4%B8%8D%E7%94%A8%E5%8E%BB%E7%8C%9C.mp4


