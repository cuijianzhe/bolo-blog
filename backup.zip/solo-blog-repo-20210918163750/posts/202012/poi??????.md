title: poi创建冻结窗口
date: '2020-12-31 09:15:31'
updated: '2020-12-31 09:15:31'
tags: [java]
permalink: /articles/2020/12/31/1609377331431.html
---
![](https://b3logfile.com/bing/20180414.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

#### office里怎么创建冻结窗格？

举个例子，在office里，如果你想冻结前两行，那么需要在第三行的最左侧单元格处点击冻结窗格，如果你选择了一个范围再点击冻结窗格，是不对的啊，是不对的。

#### poi如何实现冻结窗格的效果？

##### 冻结前两行

`sheet1.createFreezePane( 0, 2, 0, 2);`

##### 冻结第一列

`sheet2.createFreezePane( 1, 0, 1, 0);`

