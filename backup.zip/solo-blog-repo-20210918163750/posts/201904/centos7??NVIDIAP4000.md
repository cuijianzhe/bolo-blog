title: centos7 安装NVIDIA P4000
date: '2019-04-18 16:02:45'
updated: '2019-10-31 20:25:28'
tags: [Linux]
permalink: /articles/2019/04/18/1555574565055.html
---
Quadro P4000显卡在centos7安装

官网下载对应redhat驱动： [https://www.dell.com/support/home/cn/zh/cnbsd1/product-support/servicetag/2xhzrt2/drivers](https://www.dell.com/support/home/cn/zh/cnbsd1/product-support/servicetag/2xhzrt2/drivers)
执行：
`[root@localhost ~]# sh NVIDIA-Linux-x86_64-396.37.run`
出现如下报错：

```                                                                                                                                                                                                                                                                           
  ERROR: The Nouveau kernel driver is currently in use by your system.  This driver is incompatible with the NVIDIA driver, and must be disabled before proceeding.  Please consult the NVIDIA driver README and your Linux distribution's documentation for details on how  
         to correctly disable the Nouveau kernel driver.             
```
解决方法：
```
[root@localhost ~]# cd /etc/modprobe.d/
[root@localhost modprobe.d]# ls
dccp-blacklist.conf  firewalld-sysctls.conf  tuned.conf
[root@localhost modprobe.d]# cp dccp-blacklist.conf blacklist.conf 
[root@localhost modprobe.d]# vim blacklist.conf 

# DCCP is considered a potential security liability: prevent socket layer
# from automatically loading related modules using their aliases

blacklist dccp
blacklist dccp_diag
blacklist dccp_ipv4
blacklist dccp_ipv6
blacklist nouveau
        #添加此配置，把nouveau
 加入黑名单

```

```bash
[root@localhost modprobe.d]# mv /boot/initramfs-$(uname -r).img /boot/initramfs-$(uname -r).img.bak  # #使用dracut重新建立 initramfs image file
[root@localhost modprobe.d]# dracut -v /boot/initramfs-$(uname -r).img $(uname -r)
   #使用dracut重新建立 initramfs image file  #重新建立the initramfs file
```

 reboot
  重启

查看进程是否还有：
`
[root@localhost ~]#  lsmod | grep nouveau
`

执行下一步：
```
 ERROR: Unable to find the development tool `cc` in your path; please make sure that you have the package 'gcc' installed.  If gcc is installed on your system, then please check that `cc` is in your PATH.   

```
出现如上报错，解决方法：

`[root@localhost ~]# yum install -y gcc `

执行驱动文件，再次出现报错如下：
```
 ERROR: Unable to find the kernel source tree for the currently running kernel.  Please make sure you have installed the kernel source files for your kernel and that they are properly configured; on Red Hat Linux systems, for example, be sure you have the             

         'kernel-source' or 'kernel-devel' RPM installed.  If you know the correct kernel source files are installed, you may specify the kernel source path with the '--kernel-source-path' command line option. 

```
解决方法：
`
[root@localhost ~]# yum install  kernel-* -y
`
然后再次执行reboot，&&执行驱动文件：对于nvidia显卡的话可以用nvidia-smi命令来查，查看GPU也是用这个命令


```

[root@localhost ~]# nvidia-smi

Thu Apr 18 16:08:11 2019       
+-----------------------------------------------------------------------------+
| NVIDIA-SMI 396.37                 Driver Version: 396.37                    |
|-------------------------------+----------------------+----------------------+
| GPU  Name        Persistence-M| Bus-Id        Disp.A | Volatile Uncorr. ECC |
| Fan  Temp  Perf  Pwr:Usage/Cap|         Memory-Usage | GPU-Util  Compute M. |
|===============================+======================+======================|
|   0  Quadro P4000        Off  | 00000000:65:00.0 Off |                  N/A |
| 46%   37C    P0    27W / 105W |      0MiB /  8119MiB |      0%      Default |
+-------------------------------+----------------------+----------------------+
                                                                               
+-----------------------------------------------------------------------------+
| Processes:                                                       GPU Memory |
|  GPU       PID   Type   Process name                             Usage      |
|=============================================================================|
|  No running processes found                                                 |
+-----------------------------------------------------------------------------+
[root@localhost ~]# 

```

如上可以看到显卡GPU型号P4000，安装执行成功。
