title: oracle的树形结构使用
date: '2021-05-28 10:13:26'
updated: '2021-05-28 10:13:26'
tags: [java]
permalink: /articles/2021/05/28/1622168006080.html
---
![](https://b3logfile.com/bing/20180609.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

要想使用sql生成树形结构，数据格式需要具备一点：拥有父子关系节点，即code和pcode。

```sql
select * from table
start with code = 'top'
connect by prior code = pcode
```

`其中的prior字段，在code一侧就是查询top节点的子节点，在pcode一侧就是查询top节点的父节点`

今天遇到的问题是，如何在树形结构子节点增加一对多的数据？
使用 `union all` 将暂未构成树形的基础结构和一对多的数据一起查出来，然后再利用`start with`进行树的构建

