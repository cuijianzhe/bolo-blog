title: springboot集成单点登录kisso
date: '2021-08-01 18:43:53'
updated: '2021-08-01 18:49:22'
tags: [kisso]
permalink: /articles/2021/08/01/1627814633848.html
---
![](https://b3logfile.com/bing/20181005.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

* 引入kisso依赖

```xml
<!-- kisso单点登录 -->
<dependency>
    <groupId>com.baomidou</groupId>
    <artifactId>kisso</artifactId>
    <version>3.7.6</version>
</dependency>
```

* 增加首页接口

```java
package com.xyt.sso.web;

import com.baomidou.kisso.annotation.Action;
import com.baomidou.kisso.annotation.Login;
import com.xyt.sso.dao.UserMapper;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * sso单点登录控制器
 *
 * @author xuyuntong
 * @date 2021/7/31 23:28
 */
@Slf4j
@Controller
@RequestMapping("/index")
public class IndexController {

    private static final Logger logger = LoggerFactory.getLogger(Object.class);

    @Resource
    protected HttpServletRequest request;
    @Resource
    protected HttpServletResponse response;

    @Resource
    private UserMapper userMapper;

    /**
     * 跳转到首页
     * @return
     */
    @RequestMapping("")
    public String v1() {
        return "sso/index";
    }

    /**
     * 跳转到联系我们页面
     * @return
     */
    @RequestMapping("/toContact")
    public String toContact() {
        return "sso/Contact";
    }

    /**
     * 测试通过注解设置kisso不拦截
     * @param session
     * @return
     */
    @RequestMapping("/noCheck")
    @Login(action = Action.Skip)
    public String noCheck(HttpSession session) {
        return "sso/Contact";
    }

}
```

* 增加登录接口

```java
package com.xyt.sso.web;

import cn.hutool.core.util.ObjectUtil;
import com.baomidou.kisso.SSOHelper;
import com.baomidou.kisso.security.token.SSOToken;
import com.baomidou.mybatisplus.extension.conditions.query.LambdaQueryChainWrapper;
import com.xyt.sso.dao.UserMapper;
import com.xyt.sso.vo.User;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.HashMap;
import java.util.Map;

/**
 * sso单点登录控制器
 *
 * @author xuyuntong
 * @date 2021/7/31 23:28
 */
@Slf4j
@RestController
@RequestMapping("/auth")
public class LoginController {
    private static final Logger logger = LoggerFactory.getLogger(Object.class);

    @Resource
    protected HttpServletRequest request;
    @Resource
    protected HttpServletResponse response;

    @Resource
    private UserMapper userMapper;

    @RequestMapping("/login")
    @ResponseBody
    public Map<String, Object> check(@RequestParam String userName, @RequestParam String password) {
        logger.info("入参,{},{}", userName, password);
        Map<String, Object> hashMap = new HashMap<>(2);

        User queryUser = new User();
        queryUser.setUserName(userName);
        queryUser.setPassword(password);
        User one = new LambdaQueryChainWrapper<>(userMapper)
                .eq(User::getUserName, userName)
                .eq(User::getPassword, password)
                .one();
        if (ObjectUtil.isNotNull(one)) {
            SSOHelper.setCookie(request, response, SSOToken.create().setIp(request).setId(one.getId()).setIssuer(one.getUserName()), false);
            hashMap.put("success", true);
        } else {
            hashMap.put("success", false);
        }
        return hashMap;
    }
}
```

* 添加kisso的拦截器

```java
package com.xyt.sso.config;

import com.baomidou.kisso.web.interceptor.SSOSpringInterceptor;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

/**
 * @author xuyuntong
 * @date 2021/8/1 17:17
 */
@ControllerAdvice
@Configuration
public class WebConfig implements WebMvcConfigurer {

    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        // SSO 授权拦截器
        SSOSpringInterceptor ssoInterceptor = new SSOSpringInterceptor();
        /**
         * 添加不拦截的接口
         * /index是首页
         * /auth/login/**是登录接口
         */
        registry.addInterceptor(ssoInterceptor).addPathPatterns("/**").excludePathPatterns("/index", "/auth/login/**");
    }
}
```

* 设置kisso的to_login地址

```yml
#单点登录kisso
#更多配置查看 com.baomidou.kisso.starter.KissoProperties.java
kisso:
  config:
    login-url: http://localhost:8080/index
```

/index/noCheck接口配置了`@Login(action = Action.skip)`所以可以直接访问
/index/toContact接口会跳转到配置文件中指定的登录url
访问/auth/login接口登录，成功之后再访问/index/toContact接口即正常访问

至此已经配置完了没有漏掉任何环节，简直是太简单了，总结就是非常好用，不过就是文档真真真太少了。

PS：反复测试的时候不要忘记清除浏览器缓存哦

[附上源码sso.rar](https://b3logfile.com/file/2021/08/sso-79c64cc0.rar)



