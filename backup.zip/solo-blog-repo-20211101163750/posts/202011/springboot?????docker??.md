title: springboot项目部署到docker中去
date: '2020-11-02 20:29:08'
updated: '2021-04-24 13:54:22'
tags: [java]
permalink: /articles/2020/11/02/1604320148485.html
---
![](https://b3logfile.com/bing/20200919.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

1. 打jar包,可以现在本地java -jar 运行一下
2. 将jar包复制到linux虚拟机一份
3. vim Dockerfile,创建一个文件,内容如下:

```
FROM openjdk:8-jdk-alpine
ADD xxxx1.jar xxxx2.jar

ENV JAVA_OPTS="-Xmx200m"

EXPOSE xxxx3

CMD ["sh", "-c", "java $JAVA_OPTS -jar /xxxx2.jar"]
```

`注：xxxx1为打包好的jar包名称；xxxx2为自定义名称，什么都行；xxxx3为项目运行的端口号，自定义`

4.   将jar包编译成docker镜像

命令为：docker build -f Dockerfile -t xxxx5:xxxx6 .
注：xxxx5为自定义docker镜像名称;xxxx6为版本号，一般为1.0或1.0.0；在版本号后还有一个 . 这个点不能少

5. 运行docker镜像

使用命令：docker run -d -p xxxx7:xxxx8 xxxx9:xxxx10

注：xxxx7为映射到你本机的端口，当你要调用改服务时使用这个端口；xxxx8是该服务在docker服务器内的端口，被影射到xxxx7上了；xxxx9是编译docker镜像时自定义的镜像名称；xxxx10是自定义的版本号

6. 可以通过查看日志来查看服务运行状况

命令为：docker logs -f xxxx11

注：-f指查看实时日志；xxxx11指运行该服务的docker容器的名称可通docker ps查看

