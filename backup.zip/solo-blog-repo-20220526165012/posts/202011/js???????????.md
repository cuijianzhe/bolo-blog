title: js通过按钮或链接打开文件
date: '2020-11-11 11:31:42'
updated: '2022-03-30 16:03:13'
tags: [java]
permalink: /articles/2020/11/11/1605065502617.html
---
![](https://b3logfile.com/bing/20190609.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

```js
var url = selected[0].PUBLICMATERIAL;
if(!url){
	console.log("获取公示材料查看路径失败!");
	return false;
}
try {
	var a = document.createElement("a");
	a.setAttribute("href", url);
	a.setAttribute("target", "_blank");
	a.setAttribute("id", "openwin");
	document.body.appendChild(a);
	a.click();
	a.remove();
}
catch(err){
	console.log('打开公示材料出错,尝试使用 window.open() 打开');
	window.open(url);
}
```

