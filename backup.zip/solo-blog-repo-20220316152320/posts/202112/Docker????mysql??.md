title: Docker安装配置mysql镜像
date: '2021-12-03 14:30:21'
updated: '2021-12-03 14:30:21'
tags: [Docker]
permalink: /articles/2021/12/03/1638513021734.html
---
![](https://b3logfile.com/bing/20190619.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

##### 拉取最新镜像

`docker pull mysql:latest`

^也可以去https://hub.docker.com/_/mysql?tab=tags安装指定版本号的镜像^

##### 运行mysql容器

`docker run -itd --name mysql8.0 -p 3306:3306 -e MYSQL_ROOT_PASSWORD=123456 mysql:8.0.27`

> **（注：-p 3306:3306   左边的是容器的端口号，右边的是服务器的端口号。服务器的端口可以直接映射到容器的端口号上）
（注：123456   是数据库的密码可自行修改）
（注：8.0.27   是数据库的版本根据自己的版本进行更改，如何输入错误可能会导致在次拉取镜像）**

##### 查看容器状态

`docker ps`

##### 进入MySQL容器登录MySQL

`docker exec -it mysql8.0 bash`

##### 登录Mysql

`mysql -u root -p`

然后开启mysql的远程连接

`update user set host = '%' where user = 'root';`

`select host, user from user;`

`GRANT ALL PRIVILEGES ON . TO 'root'@'%' IDENTIFIED BY 'mypassword' WITH GRANT OPTION`

`FLUSH PRIVILEGES`

##### 然后开启阿里云服务器的3306端口

连接成功！


