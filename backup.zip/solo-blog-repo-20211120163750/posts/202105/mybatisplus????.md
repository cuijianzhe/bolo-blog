title: mybatis-plus相关设置
date: '2021-05-08 17:34:10'
updated: '2021-05-08 18:02:49'
tags: [java]
permalink: /articles/2021/05/08/1620466450851.html
---
![](https://b3logfile.com/bing/20181113.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

#### 逻辑删除配置

yml配置

```yml
mybatis-plus:
  global-config:
    db-config:
      logic-delete-value: 1 # 逻辑已删除值(默认为 1)
      logic-not-delete-value: 0 # 逻辑未删除值(默认为 0)
```

添加逻辑删除拦截器

```java
import com.baomidou.mybatisplus.core.injector.ISqlInjector;
import com.baomidou.mybatisplus.extension.injector.LogicSqlInjector;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
 
@Configuration
public class MyBatisPlusConfiguration {
 
    @Bean
    public ISqlInjector sqlInjector() {
        return new LogicSqlInjector();
    }
}
```

实体类字段上加上`@TableLogic`注解

```java
@TableLogic
private Integer delState;
```

#### 控制台打印sql

```yml
logging:  
level: 
com.dy.springboot.server.mapper: DEBUG
```

