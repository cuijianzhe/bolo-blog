title: zabbix的systemctl启动管理
date: '2021-10-28 14:53:38'
updated: '2021-10-28 15:00:26'
tags: [zabbix]
permalink: /articles/2021/10/28/1635404018903.html
---
## Server端

```bash
[Unit]
Description=Zabbix Server
After=syslog.target
After=network.target


[Service]
Environment="CONFFILE=/usr/local/zabbix/etc/zabbix_server.conf"
EnvironmentFile=-/usr/local/zabbix
Type=forking
PIDFile=/var/run/zabbix/zabbix_server.pid
ExecStart=/usr/local/zabbix/sbin/zabbix_server -c /usr/local/zabbix/etc/zabbix_server.conf
ExecStop=/usr/bin/kill  $MAINPID
Restart=always
RestartSec=5
User=zabbix
Group=zabbix

[Install]
WantedBy=multi-user.target
```

## agentd端

```bash
[Unit]
Description=Zabbix Agent 
After=syslog.target
After=network.target


[Service]
Environment="CONFFILE=/usr/local/zabbix/etc/zabbix_agentd.conf"
EnvironmentFile=-/usr/local/zabbix
Type=forking
PIDFile=/var/run/zabbix/zabbix_agentd.pid
ExecStart=/usr/local/zabbix/sbin/zabbix_agentd -c /usr/local/zabbix/etc/zabbix_agentd.conf
ExecStop=/usr/bin/kill  $MAINPID
Restart=always
RestartSec=5
User=zabbix
Group=zabbix

[Install]
WantedBy=multi-user.target
```

