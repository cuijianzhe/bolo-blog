title: JDK7的Fork/join，将大任务拆分成小任务，多进程执行
date: '2021-01-14 10:24:00'
updated: '2021-01-14 10:31:59'
tags: [java]
permalink: /articles/2021/01/14/1610591040303.html
---
`如果一个接口执行的很慢，比如说一个List<Map<String, Object>> 类型的对象，要循环展开list中的map，再利用map的key-value去查询数据库或者计算，那么当数据量大的时候，很容易造成数据处理过慢的情况，一般在java代码逻辑方面有两种解决方法，一种是直接将list切成多个小片list，在挨个循环遍历，而另一种，就是利用JDK1.7提供的Fork/join框架了，多个进程来处理会快很多倍。 `
![68747470733a2f2f70312d6a75656a696e2e62797465696d672e636f6d2f746f732d636e2d692d6b3375316662706663702f383233613534386366366436346365646231646435303763353.png](https://b3logfile.com/file/2021/01/68747470733a2f2f70312d6a75656a696e2e62797465696d672e636f6d2f746f732d636e2d692d6b3375316662706663702f383233613534386366366436346365646231646435303763353-31a46460.png)

```
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.ForkJoinTask;
import java.util.concurrent.RecursiveTask;

/**
 * @author xuyuntong
 * @date 2021/1/14 10:05
 */
public class ForkJoinPoolTest {

    private static final Integer DURATION_VALUE = 100;

    static class ForkJoinSubTask extends RecursiveTask<Integer> {

        // 子任务开始计算的值
        private Integer startValue;
        // 子任务结束计算的值
        private Integer endValue;

        private ForkJoinSubTask(Integer startValue , Integer endValue) {
            this.startValue = startValue;
            this.endValue = endValue;
        }

        @Override
        protected Integer compute() {
            //小于一定值DURATION,才开始计算
            if(endValue - startValue < DURATION_VALUE) {
                System.out.println("执行子任务计算：开始值 = " + startValue + ";结束值 = " + endValue + "，线程ID为：" + Thread.currentThread().getId());
                Integer totalValue = 0;
                for (int index = this.startValue; index <= this.endValue; index++) {
                    totalValue += index;
                }
                return totalValue;
            } else {
                // 将任务拆分，拆分成两个任务
                ForkJoinSubTask subTask1 = new ForkJoinSubTask(startValue, (startValue + endValue) / 2);
                subTask1.fork();
                ForkJoinSubTask subTask2 = new ForkJoinSubTask((startValue + endValue) / 2 + 1 , endValue);
                subTask2.fork();
                return subTask1.join() + subTask2.join();
            }
        }
    }

    public static void main(String[] args) throws ExecutionException, InterruptedException {
        // Fork/Join框架的线程池
        ForkJoinPool pool = new ForkJoinPool();
        ForkJoinTask<Integer> taskFuture =  pool.submit(new ForkJoinSubTask(1,1000));

        Integer result = taskFuture.get();
        System.out.println("累加结果是:" + result);

    }
}
```

