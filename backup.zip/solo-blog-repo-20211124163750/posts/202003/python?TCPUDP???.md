title: python的TCP、UDP小程序
date: '2020-03-09 17:08:02'
updated: '2020-08-24 14:15:08'
tags: [Python]
permalink: /articles/2020/03/09/1583744881835.html
---
![](https://img.hacpai.com/bing/20200220.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

# 一、聊天室

## 基于 UDP 的聊天室

* Server 端：

```python
import socket
sk = socket.socket(type=socket.SOCK_DGRAM)  #DGRAM datagram 数据报文
sk.bind(('127.0.0.1',8080))
while True:
    msg,addr = sk.recvfrom(1024)
    print(addr)
    print(msg.decode('utf-8'))
    info = input('>>>').encode('utf-8')
    sk.sendto(info,addr)
sk.close()
```

* Client1:

```python
import socket
sk = socket.socket(type=socket.SOCK_DGRAM)
ip_port = ('127.0.0.1',8080)
while True:
    info = input('cjz:')
    info = ('\033[32m来自Jianzhe的消息：%s\033[0m'%info).encode('utf-8')
    sk.sendto(info,ip_port)
    ret,addr = sk.recvfrom(1024)
    print(ret.decode('utf-8'))
sk.close()
```

* Client2:

```python
import socket
sk = socket.socket(type=socket.SOCK_DGRAM)
ip_port = ('127.0.0.1',8080)
while True:
    info = input('tiger:')
    info = ('\033[34m来自Lijuan的消息:%s\033[0m'%info).encode('utf-8')
    sk.sendto(info,ip_port)
    msg,addr = sk.recvfrom(1024)
    print(msg.decode('utf-8'))
sk.close()
```

* 效果：
  ![image.png](https://img.hacpai.com/file/2020/03/image-be4402fc.png)

## 基于 TCP 的聊天室

* Server 端：

```python
import socket
sk = socket.socket()
sk.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1)
sk.bind(('127.0.0.1',9000))
sk.listen()
while True:
    conn,addr = sk.accept()  # 接收连接 三次握手conn
    while True:
        inp = input('>>>')
        if inp == 'q':
            conn.send(inp.encode('utf-8'))
            break
        conn.send(inp.encode('utf-8'))
        msg = conn.recv(1024)
        if msg == b'q':break
        print(msg.decode('utf-8'))
    conn.close()    # 四次挥手
sk.close()
```

* client 端：

```python
import socket
sk = socket.socket()
sk.connect(('127.0.0.1',9000))
while True:
    msg = sk.recv(1024)
    print(msg.decode('utf-8'))
    if msg == b'q':break
    inp = input('>>>')
    if inp == 'q':
        sk.send(inp.encode('utf-8'))
        break
    sk.send(inp.encode('utf-8'))
sk.close()
```

# 二、远程控制程序

## 2.1 基于 TCP 的远程控制客户端程序

* Server 端：

```python
# 基于TCP实现远程执行命令
import socket
sk = socket.socket()
sk.bind(('127.0.0.1',8090))
sk.listen()
conn, addr = sk.accept()
while True:
    cmd = input('>>>')
    conn.send(cmd.encode('utf-8'))
    ret = conn.recv(1024).decode('utf-8')
    print(ret)
conn.close()
```

* Client 端：

```python
import socket
import subprocess
sk = socket.socket()
sk.connect(('127.0.0.1',8090))
while True:
    cmd = sk.recv(1024).decode('gbk')
    ret = subprocess.Popen(cmd,shell=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    std_out = 'stdout:' + (ret.stdout.read()).decode('gbk')
    std_err = 'stderr:' + (ret.stderr.read()).decode('gbk')
    print(std_out)
    print(std_err)
    sk.send(std_out.encode('utf-8'))
    sk.send(std_err.encode('utf-8'))
sk.close()
```

## 2.2 基于 UDP 实现远程执行命令

* Server 端：

```python
import socket
sk =socket.socket(type=socket.SOCK_DGRAM)
sk.bind(('127.0.0.1',8090))
msg,addr = sk.recvfrom(10240)
while True:
    cmd = input('>>>')
    if cmd == 'q':
        break
    sk.sendto(cmd.encode('utf-8'),addr)
    msg,addr = sk.recvfrom(10240)
    print(msg.decode('utf-8'))

sk.close()
```

* Client 端：

```python
import socket
import subprocess
sk =socket.socket(type=socket.SOCK_DGRAM)
addr = ('127.0.0.1',8090)
sk.sendto('吃了吗'.encode('utf-8'),addr)
while True:
    cmd,addr = sk.recvfrom(1024)
    ret = subprocess.Popen(cmd.decode('gbk'), shell=True,
                           stdout=subprocess.PIPE,
                           stderr=subprocess.PIPE)
    std_out = 'stdout:' + (ret.stdout.read()).decode('gbk')
    std_err = 'stderr:' + (ret.stderr.read()).decode('gbk')
    print(std_out)
    print(std_err)
    sk.sendto(std_out.encode('utf-8'),addr)
    sk.sendto(std_err.encode('utf-8'),addr)
sk.close()
```

