title: Maven版本依赖关系【多图预警!!!】
date: '2020-10-15 22:59:48'
updated: '2020-10-15 23:00:33'
tags: [maven]
permalink: /articles/2020/10/15/1602773988486.html
---
![](https://b3logfile.com/bing/20191026.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

#### `以mongdb为例，在项目中使用mongdb，则免不了引入spring的组件`

```
<!--mongodb-->
    <dependency>
      <groupId>org.springframework.data</groupId>
      <artifactId>spring-data-mongodb</artifactId>
      <version>3.0.4.RELEASE</version>
    </dependency>-mongodb-->
```

`maven仓库搜索 spring-data-mongodb 出现下图`![1.png](https://b3logfile.com/file/2020/10/1-50d67c77.png)

---

`点击进去后发现很多版本如下图,这里我们以最新的版本 3.0.4.RELEASE 为例`![2.png](https://b3logfile.com/file/2020/10/2-375341e4.png)

---

`点击View All`![3.png](https://b3logfile.com/file/2020/10/3-f90c7cb3.png)

---

---

`点击 spring-data-mongdb-3.0.4.RELEASE.pom`![4.png](https://b3logfile.com/file/2020/10/4-0d84e16f.png)

---

`这里可以看到它的父pom是spring-data-mongdb-parent，版本是3.0.4RELEASE`![5.png](https://b3logfile.com/file/2020/10/5-c241b946.png)

---

`键入地址路径 /maven2/org/springframework/data/ ，可以看到spring-data-mongdb-parent`![6.png](https://b3logfile.com/file/2020/10/6-a1da80fb.png)

---

---

`点击进去找到对应的3.0.4.RELEASE版本，再点击进去`![7.png](https://b3logfile.com/file/2020/10/7-b0d1f043.png)

---

`点击.pom文件查看`![8.png](https://b3logfile.com/file/2020/10/8-a102756d.png)

---

`可以看到它的父pom是spring-data-parent，版本是2.3.4.RELEASE`![9.png](https://b3logfile.com/file/2020/10/9-e18062f8.png)

---

`找到它点进去`![10.png](https://b3logfile.com/file/2020/10/10-0fa5470d.png)

---

`再找到2.3.4.RELEASE版本`![11.png](https://b3logfile.com/file/2020/10/11-fd2dc620.png)

---

`再进入它的.pom文件里`![12.png](https://b3logfile.com/file/2020/10/12-a7eefc4d.png)

---

`在它的pom里面，可以发现它依赖的spring的版本是5.3.9.RELEASE`![13.png](https://b3logfile.com/file/2020/10/13-fbe5743a.png)

