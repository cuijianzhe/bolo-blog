title: 如何使用PLSQL Developer 链接远程oracle数据库
date: '2020-09-30 10:06:43'
updated: '2020-09-30 10:06:43'
tags: [oracle]
permalink: /articles/2020/09/30/1601431603443.html
---
![](https://b3logfile.com/bing/20190206.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

### 1.安装PLSQL

PLSQL Developer 13 (64 bit) 使用起来挺好的

### 2.下载oracle_client

### 3.启动PLSQL并配置oracle_client

### 4.输入用户名密码，databasename输入ip:1521/orcl链接

