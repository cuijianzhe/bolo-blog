title: yapi 集成LDAP配置文件
date: '2021-02-28 17:30:34'
updated: '2021-02-28 17:33:06'
tags: [Linux]
permalink: /articles/2021/02/28/1614504634614.html
---
```shell
{
   "port": "3000",
   "adminAccount": "598941324@qq.com",
   "db": {
      "servername": "127.0.0.1",
      "DATABASE": "yapi",
      "port": "27017"
   },
   "mail": {
      "enable": false,
      "host": "smtp.163.com",
      "port": 465,
      "from": "***@163.com",
      "auth": {
         "user": "***@163.com",
         "pass": "*****"
      }
   },
   "ldapLogin": {
      "enable": true,
      "server": "ldap://172.16.16.14:389",
      "baseDn": "CN=root,DC=wenyang,DC=com",
      "bindPassword": "wenyang",
      "searchDn": "OU=manager,DC=wenyang,DC=com",
      "searchStandard": "uid",
      "usernameKey": "displayName"
   }
}
```

