title: Java使用MongDB分页查询数据
date: '2020-10-13 12:19:10'
updated: '2020-10-13 12:19:36'
tags: [mongdb]
permalink: /articles/2020/10/13/1602562750104.html
---
![](https://b3logfile.com/bing/20171206.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

### 导入maven包

```
<dependency>
      <groupId>org.springframework.data</groupId>
      <artifactId>spring-data-mongodb</artifactId>
      <version>1.10.7.RELEASE</version>
</dependency>
```

### 分页实际代码

#### 其中的 LearnMdb 为新建的MongDB实体类

```
import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

/**
 * @author xuyuntong
 * @date 2020/9/25 17:40
 */
@Service
public class PlanLearnServiceImpl extends ServiceImpl<PlanLearnMapper, PlanLearn> implements IPlanLearnService {

    @Resource
    private MongoTemplate mongoTemplate;


    @Override
    public PageImpl<LearnMdb> getMyAssociatedCourseList(Integer pageNow,Integer pageSize, String trainclassId) {

        Query query = new Query();
        query.addCriteria(Criteria.where("trainclassId").is(trainclassId));
        query.with(new Sort(Sort.Direction.DESC, "createTime"));

        if(pageNow<1){
            pageNow = 1;
        }
        long total = mongoTemplate.count(query, LearnMdb.class);

        Pageable pageable = new PageRequest(pageNow-1,pageSize);

        List<LearnMdb> items = mongoTemplate.find(query.with(pageable), LearnMdb.class);

        PageImpl<LearnMdb> page = new PageImpl(items, pageable, total);

        return page;
    }


}
```

