title: POI设置单元格为下拉框数据格式
date: '2021-01-06 09:53:29'
updated: '2021-01-06 09:53:29'
tags: [java]
permalink: /articles/2021/01/06/1609898009691.html
---
![](https://b3logfile.com/bing/20181105.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)


```
/**
	 * 单元格设置下拉框
	 *
	 * @param sheet 要设置下拉框的sheet页
	 * @param str 下拉数据，如String[] str = new String[] { "列1", "列2", "列3"};
	 * @param firstRow 起始行
	 * @param lastRow 中止行
	 * @param firstCol 起始列
	 * @param lastCol 中止列
	 */
	public static void dropDownBox(Sheet sheet, String[] str, int firstRow,
								   int lastRow, int firstCol, int lastCol){
		//为指定范围内的单元格添加下拉框样式
		CellRangeAddressList cas = new CellRangeAddressList(firstRow, lastRow, firstCol, lastCol);
		//创建下拉数据列
		DVConstraint dvConstraint = DVConstraint.createExplicitListConstraint(str);
		//将下拉数据放入下拉框
		HSSFDataValidation dataValidation = new HSSFDataValidation(cas, dvConstraint);
		dataValidation.createErrorBox("错误", "请选择下拉框的值");
		dataValidation.setShowErrorBox(true);
		sheet.addValidationData(dataValidation);
	}
```

