title: Git中文命令[参数]大全
date: '2021-08-11 22:49:41'
updated: '2021-08-12 09:40:40'
tags: [git]
permalink: /articles/2021/07/23/1628691299476.html
---
![](https://b3logfile.com/bing/20180319.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

#### 命令分类

**设置和配置** `git config help`
**获取和创建项目** `init clone`
**基本快照** `add status diff commit reset rm mv`
**分支和合并** `branch checkout merge mergetool log stash tag worktree`
**共享和更新项目** `fetch pull push remote submodule`
**检查和比较** `show log diff shortlog describe`
**修补** `apply cherry-pick diff rebase revert`
**调试** `bisect blame grep`

#### 【git】

```shell
语法：
　　git [--version] [--help] [-C <path>] [-c <name>=<value>]
    　　[--exec-path[=<path>]] [--html-path] [--man-path] [--info-path]
    　　[-p|--paginate|--no-pager] [--no-replace-objects] [--bare]
    　　[--git-dir=<path>] [--work-tree=<path>] [--namespace=<name>]
    　　[--super-prefix=<path>]
    　　<command> [<args>]

选项：
    --version               # 打印git程序的版本号
    --help                  # 打印概要和最常用命令的列表
    -C <path>               # 在<path>而不是当前的工作目录中运行git
    -c <name>=<value>       # 将配置参数传递给命令, 给定的值将覆盖配置文件中的值
    --exec-path[=<path>]    # 安装核心Git程序的路径, 可以通过设置GIT_EXEC_PATH环境变量来控制, 如无路径, git将打印当前设置并退出
    --html-path             # 打印Git的HTML文档安装并退出的路径, 不带斜杠
    --man-path              # 打印man(1)此版本Git的手册页的manpath, 并退出
    --info-path             # 打印记录此版本Git的Info文件的安装路径并退出
    -p, --paginate          # 如果标准输出是终端, 则将所有输出管道更少（或如果设置为$ PAGER）, 这将覆盖pager.<cmd> 配置选项
    --no-pager              # 不要将Git输出管道传输到寻呼机
    --no-replace-objects    # 不要使用替换参考来替换Git对象
    --bare                  # 将存储库视为裸存储库, 如果未设置GIT_DIR环境, 则将其设置为当前工作目录
    --git-dir=<path>        # 设置存储库的路径, 可以通过设置GIT_DIR环境变量来控制, 可以是当前工作目录的绝对或相对路径
    --work-tree=<path>      # 设置工作树的路径, 可以通过设置GIT_WORK_TREE环境变量和core.worktree配置变量来控制, 相对于当前工作目录的绝对或相对路径
    --namespace=<path>      # 设置Git命名空间, 相当于设置GIT_NAMESPACE环境变量
    --super-prefix=<path>   # 目前仅供内部使用, 设置一个前缀, 该前缀从存储库到根的路径, 一个用途是给调用它的超级项目的子模块上下文
    --literal-pathspecs     # 字面上处理pathspecs, 相当于设置GIT_LITERAL_PATHSPECS为1
    --glob-pathspecs        # 添加"glob"到所有pathspec, 相当于设置GIT_GLOB_PATHSPECS为1
    --noglob-pathspecs      # 添加"文字"到所有pathspec, 相当于设置GIT_NOGLOB_PATHSPECS为1
    --icase-pathspecs       # 添加"icase"到所有pathspec, 相当于设置GIT_ICASE_PATHSPECS为1
    --no-optional-locks     # 不要执行需要锁定的可选操作, 相当于设置GIT_OPTIONAL_LOCKS为0
```

#### 【config】

```shell
语法：
　　git config [<file-option>] [type] [--show-origin] [-z|--null] name [value [value_regex]]
　　git config [<file-option>] [type] --add name value
　　git config [<file-option>] [type] --replace-all name value [value_regex]
　　git config [<file-option>] [type] [--show-origin] [-z|--null] --get name [value_regex]
　　git config [<file-option>] [type] [--show-origin] [-z|--null] --get-all name [value_regex]
　　git config [<file-option>] [type] [--show-origin] [-z|--null] [--name-only] --get-regexp name_regex [value_regex]
　　git config [<file-option>] [type] [-z|--null] --get-urlmatch name URL
　　git config [<file-option>] --unset name [value_regex]
　　git config [<file-option>] --unset-all name [value_regex]
　　git config [<file-option>] --rename-section old_name new_name
　　git config [<file-option>] --remove-section name
　　git config [<file-option>] [--show-origin] [-z|--null] [--name-only] -l | --list
　　git config [<file-option>] --get-color name [default]
　　git config [<file-option>] --get-colorbool name [stdout-is-tty]
　　git config [<file-option>] -e | --edit

选项：
    --system                            # 使用系统配置文件
    --global                            # 使用全局配置文件
    --local                             # 使用本地配置文件, 默认
    -f <filename>, --file <filename>    # 使用指定配置文件
    --blob <blob-id>                    # 使用指定blob
    --int                               # 确保输出为简单十进制数
    --bool                              # 确保输出为"true" 或 "false" 的布尔字符串表示
    --bool-or-int                       # 确保输出为--bool或--int的格式
    --path                              # 将扩展~到指定用户的主目录的值 $HOME和~user主目录。
    --replace-all                       # 替换与该键匹配的所有行
    --add                               # 添加配置项
    --get                               # 获取给定键的值（可选用与值匹配的正则表达式进行过滤）
    --get-all                           # 像get一样，但返回多值键的所有值
    --get-regexp                        # 像get-all一样，但将该名称解释为正则表达式并写出键名称
    --get-urlmatch name URL             # 当给定一个由两部分组成的名称section.key时，会返回部分<url>.key的值
    --remove-section                    # 从配置文件中删除给定的部分
    --rename-section                    # 将给定部分重命名为新名称
    --unset                             # 从配置文件中删除与密钥匹配的行
    --unset-all                         # 从配置文件中删除所有与密钥匹配的行
    -l, --list                          # 列出在配置文件中设置的所有变量及其值
    --expiry-date                       # 将确保输出从固定或相对日期字符串转换为时间戳, 设置该值时此选项无效
    -z, --null                          # 对于输出值和/或键的所有选项，始终使用空字符结束值, 使用换行符作为键和值之间的分隔符
    --name-only                         # 输出--listor 的配置变量的名称--get-regexp
    --show-origin                       # 使用原点类型（文件, 标准输入, blob, 命令行）和实际原点（配置文件路径, ref或blob id）扩大所有查询配置选项的输出
    --get-colorbool name [stdout-is-tty]# 找到name（例如color.diff）的颜色设置并输出"true"或"false"
    --get-color name [default]          # 查找name（例如color.diff.new）配置的颜色并将其作为ANSI颜色转义序列输出到标准输出
    -e, --edit                          # 打开一个编辑器来修改指定的配置文件; 或者 --system，--global或者存储库（默认）
    --[no-]includes                     # 查找值, 默认off, on搜索所有配置文件, 当值定文件时（使用：--file，--global等）
```

#### 【help】

```shell
语法：
　　git help [-a|--all] [-g|--guide]
       　　[-i|--info|-m|--man|-w|--web] [COMMAND|GUIDE]

选项：
    -a, --all           # 在标准输出上打印所有可用的命令
    -g, --guide         # 在标准输出上打印有用的指南列表
    -i, --info          # 以信息格式显示命令的手册页
    -m, --man           # 以man格式显示命令的手册页
    -w, --web           # 以Web（HTML）格式显示命令的手册页
```

#### 【init】

```shell
语法：    
    git init [-q | --quiet] [--bare] [--template=<template_directory>]
        [--separate-git-dir <git dir>]
        [--shared[=<permissions>]] [directory]

选项：
    -q, --quiet                         　　　　　　# 仅打印错误和警告消息, 所有其他输出将被抑制
    --bare                              　　　　　　# 创建一个裸仓库, 如果GIT_DIR未设置环境, 则将其设置为当前工作目录
    --template=<template_directory>     　　　　　　# 指定将使用模板的目录
    --separate-git-dir=<git dir>        　　　　　　# 相反, 初始化存储库作为目录之一$GIT_DIR或者./.git/, 创建一个包含路径的实际存储库的文本文件存在, 该文件充当文件系统不可知的Git与存储库的符号链接
    --shared[=(false|true|umask|group|all|world|everybody|0xxx)] # 指定Git存储库在多用户间共享, 允许同一组的用户推入该存储库
        umask (or false)                　　　　　　# 使用由umask(2)报告的权限, --shared未指定时的默认值
        group (or true)                　　　　　　 # 使存储库组可写
        all (or world or everybody)     　　　　　　# 与组相同，但使存储库可供所有用户读取
        0xxx                            　　　　　　# 0xxx是八进制数, 每个文件都有模式0xxx。
　　　　　　　　　　　　　　　　　　　　　　　　 　　　　　　 0640将创建一个组可读的存储库, 但不能对其他组进行写入或访问。0660将创建一个对当前用户和组可读可写的回购, 但其他人无法访问。
```

#### 【clone】

```shell
语法：
    git clone [--template=<template_directory>]
        [-l] [-s] [--no-hardlinks] [-q] [-n] [--bare] [--mirror]
        [-o <name>] [-b <name>] [-u <upload-pack>] [--reference <repository>]
        [--dissociate] [--separate-git-dir <git dir>]
        [--depth <depth>] [--[no-]single-branch] [--no-tags]
        [--recurse-submodules[=<pathspec>]] [--[no-]shallow-submodules]
        [--jobs <n>] [--] <repository> [<directory>]

选项：        
    -l, --local                        # 当克隆的存储库位于本地计算机上时, 此标志绕过正常的“Git aware”传输机制, 并通过复制HEAD以及对象和引用目录下的所有内容来克隆存储库
    --no-hardlinks                     # 强制从本地文件系统的存储库复制进程, 以复制目录下的.git/objects 文件而不是使用硬链接
    -s, --shared                       # 当克隆的存储库位于本地计算机上时, 将自动设置.git/objects/info/alternates为与源存储库共享对象, 而不是使用硬链接, 生成的存储库首先没有任何对象
    --reference[-if-able] <repository> # 如存储库位于本地计算机上, 则自动设置.git/objects/info/alternates为从存储库获取对象将已存在存储库用作备用存储库将需从正在克隆的存储库中复制更少对象, 而降低网络和本地存储成本
    --dissociate                       # 借助--reference仅使用选项指定的引用存储库借用对象, 以减少网络传输, 并通过制作所需的借用对象的本地副本, 在克隆完成后停止借用它们
    -q, --quiet                        # 安静地操作, 进度未报告给标准错误流
    -v, --verbose                      # 运行详细, 不影响向标准错误流报告进度状态
    --progress                         # 当连接到终端时，默认情况下, 标准错误流中会报告进度状态，除非指定-q，即使标准错误流未定向到终端, 此标志也会强制进度状态
    -n, --no-checkout                  # 克隆完成后, 不执行HEAD签出
    --bare                             # 制作一个纯粹的 Git存储库
    --mirror                           # 设置源存储库的镜像
    -o <name>, --origin <name>         # 不要使用远程名称origin来跟踪上游存储库，请使用<name>
    -b <name>, --branch <name>         # 而不是将新创建的HEAD指向克隆存储库HEAD指向的<name>分支，而是指向分支在非裸仓库中, 这是将被检出的分支。 --branch也可以在生成的存储库中提交标签并分离HEAD
    -u <upload-pack>, --upload-pack <upload-pack>  # 当给定时, 通过ssh访问要克隆的存储库, 这将为另一端运行的命令指定非默认路径
    --template=<template_directory>                # 指定将使用模板的目录
    -c <key>=<value>, --config <key>=<value>       # 在新创建的存储库中设置配置变量
    --depth <depth>                                # 创建一个历史截断为指定数目的提交的浅表副本
    --shallow-since=<date>                         # 在指定时间后创建一个具有历史记录的浅表克隆
    --shallow-exclude=<revision>                   # 创建有历史记录的浅层克隆, 但不包括从指定远程分支或标记可访问的提交
    --[no-]single-branch　　　　　　　　　　　　　　　  # 只克隆导致单个分支尖端的历史记录, 无论--branch选项指定还是主分支远程的HEAD指向
    --no-tags 　　　　　　　　　　　　　　　　　　　　　  # 不要克隆任何标签, 并remote.<remote>.tagOpt=--no-tags在配置中设置, 确保将来git pull和git fetch操作不会跟随任何标签
    --recurse-submodules[=<pathspec]               # 创建克隆后, 根据pathspec初始化和克隆子模块。如未提供pathspec, 则初始化并克隆所有子模块
    --[no-]shallow-submodules                      # 所克隆的所有子模块将会变浅, 深度为1
    --separate-git-dir=<git dir>                   # 不要将克隆的存储库放置在它应该存在的位置, 而应将克隆的存储库放置在指定的目录中,然后创建一个与文件系统无关的Git符号链接。结果是Git仓库可以从工作树中分离出来
    -j <n>, --jobs <n>                             # 同时获取的子模块的数量。默认为submodule.fetchJobs选项
    <repository>                                   # 从中克隆的存储库
    <directory>                                    # 要克隆到的新目录的名称
```

#### 【add】

```shell
语法：
    git add [--verbose | -v] [--dry-run | -n] [--force | -f] [--interactive | -i] [--patch | -p]
        [--edit | -e] [--[no-]all | --[no-]ignore-removal | [--update | -u]]
        [--intent-to-add | -N] [--refresh] [--ignore-errors] [--ignore-missing] [--renormalize]
        [--chmod=(+|-)x] [--] [<pathspec>…​]

选项：
    -v, --verbose                   # 详细
    -n, --dry-run                   # 不要实际添加文件, 只显示它们是否存在和/或将被忽略
    -f, --force                     # 允许添加被忽略的文件
    -i, --interactive               # 在工作树中交互添加修改的内容到索引
    -p, --patch                     # 在索引和工作树之间交互地选择补丁块, 并将它们添加到索引中
    -e, --edit                      # 在编辑器中打开差异与索引并让用户编辑它。编辑器关闭后, 调整大块头并将补丁应用到索引
    -u, --update                    # 更新已存在匹配<pathspec>条目的索引。这会删除和修改索引条目以匹配工作树, 但不会添加新文件
    -A, --all, --no-ignore-removal  # 更新索引不仅在工作树具有匹配<pathspec>的文件的位置, 而且索引已经有条目的位置这会添加，修改和删除索引条目以匹配工作树
    --no-all, --ignore-removal      # 通过添加索引未知的新文件和工作树中修改的文件来更新索引, 但忽略已从工作树中删除的文件当没有使用<pathspec>时，该选项是无操作的
    -N, --intent-to-add             # 只记录路径将在稍后添加的事实。路径条目放置在没有内容的索引中
    --refresh                       # 不要添加文件，而只需刷新索引中的stat()信息
    --ignore-errors                 # 如果某些文件因索引错误而无法添加, 请不要中止操作，而是继续添加其他文件
    --ignore-missing                # 该选项只能与--dry-run一起使用。用户可检查是否有给定的文件被忽略, 不管是否已存在于工作树中
    --no-warn-embedded-repo         # 默认情况下, git add向嵌入式存储库添加索引时会发出警告, 而不用git submodule add其中创建条目.gitmodules。该选项将会禁止警告
    --renormalize                   # 将新鲜的"干净"过程应用于所有跟踪的文件, 以强制将其再次添加到索引
    --chmod=(+|-)x                  # 覆盖添加文件的可执行位。可执行位仅在索引中更改, 磁盘上的文件保持不变。
    --                              # 此选项可用于将命令行选项与文件列表分开
    <pathspec>…                     # 要从中添加内容的文件。*.c可以给Fileglobs（例如）添加所有匹配的文件
```

#### 【status】

```shell
语法：
    git status [<options>…​] [--] [<pathspec>…​]

选项：
    -s, --short                               # 以短格式输出输出
    -b, --branch                              # 甚至以短格式显示分支和跟踪信息
    --show-stash                              # 显示当前隐藏的条目数量
    --porcelain[=<version>]                   # 为脚本提供易于解析的格式输出
    --long                                    # 以长格式输出输出, 默认
    -v, --verbose                             # 除了已更改的文件名称之外, 还会显示正在执行的文本更改
    -u[<mode>], --untracked-files[=<mode>]    # 显示未跟踪的文件
    --ignore-submodules[=<when>]              # 查找更改时忽略对子模块的更改。<when>可以是"none", "untracked", "dirty"或"all", 这是默认设置
    --ignored[=<mode>]                        # 也显示忽略的文件。mode参数用于指定忽略文件的处理, 可选的, 默认为传统
        traditional                           # 传统, 显示被忽略的文件和目录, 除非指定--untracked-files = all，这种情况下将显示忽略目录中的单个文件
        no                                    # 否, 不显示任何被忽略的文件
        matching                              # 匹配, 显示与忽略模式匹配的忽略文件和目录
    -z                                        # 用NUL而不是LF终止输入
    --no-column, --column[=<options>]         # 在列中显示未跟踪的文件
    --ahead-behind, --no-ahead-behind         # 显示或不显示分支相对于其上游分支的详细前/后计数。默认为true
    <pathspec>…​                               #
```

#### 【diff】

```shell
语法：
    git diff [options] [<commit>] [--] [<path>…​]
    git diff [options] --cached [<commit>] [--] [<path>…​]
    git diff [options] <commit> <commit> [--] [<path>…​]
    git diff [options] <blob> <blob>
    git diff [options] [--no-index] [--] <path> <path>

选项：
    -p, -u, --patch                                     # 生成补丁, 这是默认设置
    -s, --no-patch                                      # 抑制差异输出。对于像git show这样的命令很有用，默认显示补丁，或取消效果--patch
    -U<n>, --unified=<n>                                # 使用<n>行上下文生成差异，而不是通常的三行。意味着-p
    --raw                                               # 以原始格式生成差异
    --patch-with-raw                                    # 原始的同义词-p --raw
    --indent-heuristic, --no-indent-heuristic           # 为了帮助调试和调整实验启发式, 改变差异边界以使修补程序更易于阅读, 默认关闭
    --minimal                                           # 花费额外的时间来确保生成最小可能的差异
    --patience                                          # 使用"耐心差异"算法生成差异
    --histogram                                         # 使用"直方图差异"算法生成差异
    --diff-algorithm={patience|minimal|histogram|myers} # 选择一种差异算法
        default, myers                                  # 基本的贪婪diff算法, 默认设置
        minimal                                         # 花费额外的时间来确保生成最小可能的差异
        patience                                        # 生成补丁时使用"耐心差异"算法
        histogram                                       # 该算法将耐心算法扩展为"支持低出现率的通用元素"
    --stat[=<width>[,<name-width>[,<count>]]]           # 生成一个diffstat
    --numstat                                           # 类似--stat，但显示十进制表示法中添加和删除的行数以及不带缩写的路径名。 对于二进制文件，输出两个-而不是说 0 0
    --shortstat                                         # 只输出--stat包含修改文件总数的格式的最后一行, 以及添加和删除行的数量
    --dirstat[=<param1,param2,…​>]                       # 输出每个子目录的相对变化量分布。--dirstat可以通过传递逗号分隔的参数列表来定制行为
        changes                                         # 通过计算已从源中删除或添加到目标的行来计算dirstat数字
        lines                                           # 通过执行常规基于行的差异分析来计算dirstat数字，并将删除/添加的行数相加
        files                                           # 通过计算更改的文件数量来计算dirstat数字
        cumulative                                      # 计数父目录的子目录中的更改
        <limit>                                         # 整数参数指定截断百分比（默认为3％）。输出中不显示贡献小于此百分比的目录
    --summary                                           # 输出扩展头信息的精简摘要，如创建，重命名和模式更改
    --patch-with-stat                                   # 同义词- p - stat
    -z                                                  # 当--raw，--numstat，--name-only或--name-status已给出，不Munge时间路径名，并使用完全无效的输出字段终止符
    --name-only                                         # 仅显示已更改文件的名称
    --name-status                                       # 仅显示已更改文件的名称和状态
    --submodule[=<format>]                              # 指定如何显示子模块中的差异
    --color[=<when>]                                    # 显示有色差异
    --no-color                                          # 关闭有色差异
    --word-diff[=<mode>]                                # 显示一个单词diff，使用<mode>分隔已更改的单词。默认: 空格分隔
    color                                               # 仅使用颜色突出显示更改的词
    plain                                               # 将单词显示为[-removed-]和{+added+}。如果输入中出现分隔符，则不会尝试跳过分隔符，因此输出可能不明确
    porcelain                                           # 使用专门用于脚本消费的基于行的格式
    none                                                # 再次禁用字差异
    --word-diff-regex=<regex>                           # 使用<regex>来决定一个单词是什么，而不是将非空白的运行视为一个单词
    --color-words[=<regex>]                             # 相当于--word-diff=color加号
    --no-renames                                        # 关闭重命名检测，即使配置文件提供了默认设置
    --check                                             # 警告如果更改引入冲突标记或空白错误。认为空白错误由core.whitespace 配置控制。
    --ws-error-highlight=<kind>                         # 按<颜色>指定的颜色突出显示由<颜色>指定的行上的空白错误color.diff.whitespace
    --full-index                                        # 在生成补丁格式输出时，在“索引”行上显示完整的映像前和映像后blob对象名称，而不是第一批字符
    --binary                                            # 除了--full-index输出可以应用的二进制差异git-apply
    --abbrev[=<n>]                                      # 不是在diff-raw格式输出和diff-tree标题行中显示完整的40字节十六进制对象名称，只显示部分前缀
    -B[<n>][/<m>], --break-rewrites[=[<n>][/<m>]]       # 将完全重写更改分解为删除和创建对
    -M[<n>], --find-renames[=<n>]                       # 检测重命名
    -C[<n>], --find-copies[=<n>]                        # 检测副本以及重命名
    --find-copies-harder                                # 出于性能原因，默认情况下，-C只有当副本的原始文件在相同的变更集中被修改时，选项才会查找副本
    -D, --irreversible-delete                           # 省略原图像进行删除，即仅打印标题，但不打印原像和之间的差异/dev/null
    -l<num>                                             # 在-M和-C选项需要为O（n ^ 2）的处理时间，其中n是/复制目标潜在的重命名的数目如果重命名/复制目标的数量超过指定的数量，则此选项可防止重命名/复制检测运行
    --diff-filter=[(A|C|D|M|R|T|U|X|B)…​[*]]             # 选择仅添加(A), 复制(C), 删除(D), 修改(M), 重命名(R), 其类型(即常规文件, 符号链接, 子模块, ...)更改(T), Unmerged(U), 未知(X)或已配对Broken(B)
                                                          可以使用任何过滤字符的组合(包括无)当*（全部或无）添加到组合中时，如果有任何文件与比较中的其他条件匹配，则选择所有路径; 如果没有与其他标准匹配的文件，则不会选择任何内容
    -S<string>                                          # 查找改变文件中指定字符串出现次数（即添加/删除）的差异
    -G<regex>                                           # 寻找补丁文本包含与<regex>匹配的添加/删除行的差异
    --pickaxe-all                                       # 当-S或-G发现更改时，显示该更改集中的所有更改，而不仅仅是包含<string>中的更改的文件
    --pickaxe-regex                                     # 将给定的<string> -S视为扩展的POSIX正则表达式进行匹配
    -O<orderfile>                                       # 控制文件在输出中出现的顺序
    -R                                                  # 交换两个输入; 即显示索引或磁盘文件与树内容的差异
    --relative[=<path>]                                 # 从项目的子目录运行时，可以通过此选项告知排除目录外的更改并显示与其相关的路径名
    -a, --text                                          # 将所有文件视为文本
    --ignore-space-at-eol                               # 忽略EOL中的空白变化
    -b, --ignore-space-change                           # 忽略空白量的变化。这会忽略行结束处的空白，并认为一个或多个空白字符的所有其他序列是等价的
    -w, --ignore-all-space                              # 比较行时忽略空格。即使一行有空白，而另一行没有空白，这也会忽略差异
    --ignore-blank-lines                                # 忽略其行全部空白的更改
    --inter-hunk-context=<lines>                        # 显示差异hunk之间的上下文，直到指定的行数，从而融合彼此接近的hunk
    -W, --function-context                              # 显示整个周围的变化功能
    --exit-code                                         # 用类似于diff（1）的代码退出程序。也就是说，如果存在差异，则1退出，0表示没有差异
    --quiet                                             # 禁用程序的所有输出。意味着--exit-code
    --ext-diff                                          # 允许执行一个外部比较助手
    --no-ext-diff                                       # 禁止外部差异驱动程序
    --textconv, --no-textconv                           # 在比较二进制文件时，允许（或不允许）运行外部文本转换过滤器
    --ignore-submodules[=<when>]                        # 忽略差异代中子模块的更改。<when>可以是“none”，“untracked”，“dirty”或“all”，这是默认设置
    --src-prefix=<prefix>                               # 显示给定的源前缀而不是“a /”
    --dst-prefix=<prefix>                               # 显示给定的目的地前缀而不是“b /”
    --no-prefix                                         # 不要显示任何来源或目的地前缀
    --line-prefix=<prefix>                              # 为每行输出预留一个额外的前缀
    --ita-invisible-in-index                            # 默认情况下，由“git add -N”添加的条目显示为“git diff”中的现有空文件和“git diff --cached”中的新文件
    -1 --base, -2 --ours, -3 --theirs                   # 比较工作树与“基本”版本（阶段＃1），“我们的分支”（阶段＃2）或“他们的分支”（阶段＃3）
    -0                                                  # 忽略差异输出未合并的条目并只显示“未合并”。仅在将工作树与索引进行比较时才能使用
    <path>…​                                             # 给出的<paths>参数用于将diff限制为指定的路径
```

#### 【commit】

```shell
语法：
    git commit [-a | --interactive | --patch] [-s] [-v] [-u<mode>] [--amend]
       [--dry-run] [(-c | -C | --fixup | --squash) <commit>]
       [-F <file> | -m <msg>] [--reset-author] [--allow-empty]
       [--allow-empty-message] [--no-verify] [-e] [--author=<author>]
       [--date=<date>] [--cleanup=<mode>] [--[no-]status]
       [-i | -o] [-S[<keyid>]] [--] [<file>…​]

选项：
    -a, --all                               # 告诉命令自动对已被修改和删除的文件进行分段处理，但没有告知Git的新文件不受影响
    -p, --patch                             # 使用交互式补丁选择界面来选择要提交的更改
    -C <commit>, --reuse-message=<commit>   # 取一个现有的提交对象，并在创建提交时重用日志消息和作者信息（包括时间戳）
    -c <commit>, --reedit-message=<commit>  # 像-C一样，但-c调用了编辑器，以便用户可以进一步编辑提交消息
    --fixup=<commit>                        # 构建一个提交消息以供使用rebase --autosquash。提交消息将成为指定提交的主题行，其前缀为“fixup！”
    --squash=<commit>                       # 构建一个提交消息以供使用rebase --autosquash。提交消息主题行取自指定的提交，前缀为“squash！”
    --reset-author                          # 当与-C / -c / - 修改选项一起使用时，或者在冲突樱桃挑选后提交时，声明结果提交的作者现在属于提交者
    --short                                 # 进行干运行时，请以短格式输出
    --branch                                # 甚至以短格式显示分支和跟踪信息
    --porcelain                             # 进行干式运行时，请将输出信号以瓷器准备好的格式输出
    --long                                  # 进行干式运行时，请以长格式输出
    -z, --null                              # 显示short或porcelain状态输出时，逐字打印文件名并用NUL而不是LF结束输入。如果没有给出格式，则表示--porcelain输出格式
    -F <file>, --file=<file>                # 从给定的文件中获取提交消息。使用-从标准输入中读取消息
    --author=<author>                       # 覆盖提交作者。使用标准A U Thor <author@example.com>格式指定明确的作者
    --date=<date>                           # 覆盖提交中使用的作者日期
    -m <msg>, --message=<msg>               # 使用给定的<msg>作为提交消息
    -t <file>, --template=<file>            # 编辑提交消息时，使用给定文件中的内容启动编辑器
    -s, --signoff                           # 提交日志消息结尾处的提交者添加Signed-off-by行
    -n, --no-verify                         # 该选项绕过预先提交和提交msg钩子
    --allow-empty                           # 通常记录具有与其唯一父提交完全相同的树的提交是个错误，并且该命令阻止您提交此类提交
    --allow-empty-message                   # 像--allow-empty这个命令主要供外国SCM接口脚本使用。它允许你使用空的提交消息创建一个提交，而不使用像git-commit-tree [1]命令 
    --cleanup=<mode>                        # 这个选项决定了在提交之前应该如何清理提供的提交消息。所述<模式>可以是strip， whitespace，verbatim，scissors或default
    strip                                   # 删除前导和尾随空行，尾随空白，评论和折叠连续的空行
    whitespace                              # 同strip除#commentary不会被删除
    verbatim                                # 根本不要改变信息
    scissors                                # 相同whitespace，除了一切从（并包括）下面找到的行被截短，如果消息是要被编辑
    default                                 # 就strip好像要编辑的消息一样。否则whitespace
    -e, --edit                              # 从文件提取的消息-F，命令行 -m和从提交对象中取出的消息-C通常用作未修改的提交日志消息
    --no-edit                               # 使用选定的提交消息而不启动编辑器。例如，git commit --amend --no-edit修改提交而不更改其提交消息
    --amend                                 # 通过创建一个新的提交来替换当前分支的提示
    --no-post-rewrite                       # 绕过重写挂钩
    -i, --include                           # 在到目前为止的阶段性内容提交之前，请在命令行上指定路径的内容。这通常不是你想要的，除非你正在完成一个冲突的合并。
    -o, --only                              # 通过获取命令行中指定路径的更新工作树内容来进行提交，而忽略已为其他路径执行的任何内容
    -u[<mode>], --untracked-files[=<mode>]  # 显示未跟踪的文件。模式可选的(默认为全部), 并用于指定未跟踪文件的处理; 
　　　　　　　　　　　　　　　　　　　　　　　　　　　 当-u未被使用时，默认是正常的，即显示未跟踪的文件和目录。所述<模式>可以是no， normal，all
    -v, --verbose                           # 显示HEAD提交与提交消息模板底部提交的内容之间的统一差异，以帮助用户通过提醒提交具有哪些更改来描述提交
    -q, --quiet                             # 禁止提交摘要消息
    --dry-run                               # 不要创建提交,而是显示要提交的路径列表,包含将保留未提交的本地更改的路径以及未跟踪的路径
    --status                                # 使用编辑器准备提交消息时，在提交消息模板中包含git-status [1]的输出。默认为打开，但可用于覆盖配置变量commit.status。
    --no-status                             # 使用编辑器准备默认提交消息时，不要在提交消息模板中包含git-status [1]的输出。
    -S[<keyid>], --gpg-sign[=<keyid>]       # GPG标志提交。该keyid参数是可选的，并且默认为提交者身份
    --no-gpg-sign                           # commit.gpgSign设置为强制每个提交进行签名的计数器配置变量
    --                                      # 不要将更多的参数解释为选项
    <file>…​                                 # 当在命令行上给出文件时，该命令将提交指定文件的内容，而不记录已经执行的更改
```

#### 【rest】

```shell
语法：
    git reset [-q] [<tree-ish>] [--] <paths>…​
    git reset (--patch | -p) [<tree-ish>] [--] [<paths>…​]
    git reset [--soft | --mixed [-N] | --hard | --merge | --keep] [-q] [<commit>]

选项：
    -q, --quiet      # 保持安静，只报告错误
    --soft           # 根本不触摸索引文件或工作树（但将头重置为<commit>，就像所有模式一样）
    --mixed          # 重置索引而不是工作树（即，保存更改的文件但未标记为提交）并报告尚未更新的内容。这是默认操作
    --hard           # 重置索引和工作树。放弃自<commit>以来对工作树中跟踪文件所做的任何更改
    --merge          # 重置索引并更新工作树中<commit>和HEAD之间不同的文件，但保留索引和工作树之间不同的文件（即没有添加更改的文件）如果<commit>和索引之间的文件有不同的变化，则重置会中止
    --keep           # 重置索引条目并更新工作树中<commit>和HEAD之间不同的文件。如果<commit>和HEAD之间的文件有本地更改，则重置会中止
```

#### 【rm】

```shell
语法：
    git rm [-f | --force] [-n] [-r] [--cached] [--ignore-unmatch] [--quiet] [--] <file>…​

选项：
    <file>…​                 # 要删除的文件
    -f, --force             # 覆盖最新的检查
    -n, --dry-run           # 切勿删除任何文件。相反，只需显示它们是否存在于索引中，否则将被命令删除
    -r                      # 当给出主目录名时允许递归删除
    --                      # 此选项可用于将命令行选项与文件列表分开，（当文件名可能被误认为是命令行选项时很有用）
    --cached                # 使用此选项可以取消仅从索引中删除路径的情况。工作树文件，无论是否修改，都将被单独保留
    --ignore-unmatch        # 即使没有匹配的文件，也可以用零状态退出
    -q, --quiet             # 该选项禁止输出
```

#### 【mv】

```shell
语法：
    git mv <options>…​ <args>…​

选项：
    -f, --force             # 即使目标存在，也要强制重命名或移动文件
    -k                      # 跳过移动或重命名会导致错误情况的操作
    -n, --dry-run           # 没做什么; 只显示会发生什么
    -v, --verbose           # 报告移动文件的名称
```

#### 【branch】

```shell
语法：
    git branch [--color[=<when>] | --no-color] [-r | -a]
        [--list] [-v [--abbrev=<length> | --no-abbrev]]
        [--column[=<options>] | --no-column] [--sort=<key>]
        [(--merged | --no-merged) [<commit>]]
        [--contains [<commit]] [--no-contains [<commit>]]
        [--points-at <object>] [--format=<format>] [<pattern>…​]
    git branch [--track | --no-track] [-l] [-f] <branchname> [<start-point>]
    git branch (--set-upstream-to=<upstream> | -u <upstream>) [<branchname>]
    git branch --unset-upstream [<branchname>]
    git branch (-m | -M) [<oldbranch>] <newbranch>
    git branch (-c | -C) [<oldbranch>] <newbranch>
    git branch (-d | -D) [-r] <branchname>…​
    git branch --edit-description [<branchname>]

选项：
    -d, --delete                                 # 删除分支
    -D                                           # 快捷键--delete --force
    -l, --create-reflog                          # 创建分支的reflog
    -f, --force                                  # 将<branchname>重置为<startpoint>，即使<branchname>已存在
    -m, --move                                   # 移动/重命名分支和相应的reflog
    -M                                           # 快捷键--move --force
    -c, --copy                                   # 复制分支和相应的reflog
    -C                                           # 快捷键--copy --force
    --color[=<when>]                             # 颜色分支突出显示当前，本地和远程跟踪分支。该值必须始终（默认），永不，或自动
    --no-color                                   # 关闭分支颜色，即使配置文件将默认设置为颜色输出。和...一样--color=never
    -i, --ignore-case                            # 排序和过滤分支不区分大小写
    --column[=<options>], --no-column            # 在列中显示分支列表
    -r, --remotes                                # 列出或删除（如果与-d一起使用）远程跟踪分支
    -a, --all                                    # 列出远程追踪分行和当地分行
    --list                                       # 列出分支
    -v, -vv, --verbose                           # 在列表模式下，显示sha1并为每个头提交主题行，以及与上游分支（如果有）的关系
    -q, --quiet                                  # 创建或删除分支时更安静，抑制非错误消息
    --abbrev=<length>                            # 改变输出列表中sha1的最小显示长度。默认值是7
    --no-abbrev                                  # 在输出列表中显示完整的sha1，而不是缩写它们
    -t, --track                                  # 创建新分支时，设置branch.<name>.remote和 branch.<name>.merge配置条目以将起点分支标记为新分支的“上游”
    --no-track                                   # 即使branch.autoSetupMerge配置变量为true，也不要设置“上游”配置
    --set-upstream                               # 由于此选项具有混淆语法，因此不再支持。请使用--track或--set-upstream-to替代
    -u <upstream>, --set-upstream-to=<upstream>  # 设置<branchname>的跟踪信息，以便<upstream>被视为<branchname>的上游分支。如果未指定<branchname>，则默认为当前分支。
    --unset-upstream                             # 删除<branchname>的上游信息。如果未指定分支，则默认为当前分支
    --edit-description                           # 打开一个编辑器，编辑文本解释分支是干什么用的，通过其他各种命令使用（例如format-patch， request-pull和merge（如果启用））
    --contains [<commit>]                        # 只列出包含指定提交的分支（如果未指定，则为HEAD）。意味着--list
    --no-contains [<commit>]                     # 只列出不包含指定提交的分支（如果未指定，则为HEAD）。意味着--list
    --merged [<commit>]                          # 仅列出可从指定提交中获得提示的分支（如果未指定，则为HEAD）。暗示--list，不符合--no-merged
    --no-merged [<commit>]                       # 只列出提示无法从指定提交中获得的分支（如果未指定，则为HEAD）。暗示--list，不符合--merged
    <branchname>                                 # 要创建或删除的分支的名称
    <start-point>                                # 新的分支头将指向这个提交
    <oldbranch>                                  # 要重命名的现有分支的名称    
    <newbranch>                                  # 现有分支的新名称
    --sort=<key>                                 # 根据给定的关键字进行排序
    --points-at <object>                         # 只列出给定对象的分支
    --format <format>                            # 从显示的分支ref 中插入的字符串以及它指向的对象。格式与git-for-each-ref [1]的格式相同
```

#### 【checkout】

```shell
语法：
    git checkout [-q] [-f] [-m] [<branch>]
    git checkout [-q] [-f] [-m] --detach [<branch>]
    git checkout [-q] [-f] [-m] [--detach] <commit>
    git checkout [-q] [-f] [-m] [[-b|-B|--orphan] <new_branch>] [<start_point>]
    git checkout [-f|--ours|--theirs|-m|--conflict=<style>] [<tree-ish>] [--] <paths>…​
    git checkout [<tree-ish>] [--] <pathspec>…​
    git checkout (-p|--patch) [<tree-ish>] [--] [<paths>…​]

选项：
    -q, --quiet                     # 抑制反馈信息
    --[no-]progress                 # 除非--quiet 已指定，否则标准错误流默认情况下会将其连接到终端时报告进度状态
    -f, --force                     # 切换分支时，即使索引或工作树与HEAD不同，也要继续。这用于丢弃本地更改
    --ours, --theirs                # 当从索引中检出路径时，请检查第2阶段(ours)或第3阶段(theirs)是否有未合并的路径
    -b <new_branch>                 # 创建一个名为<new_branch>的新分支并在<start_point>处启动它
    -B <new_branch>                 # 创建分支<new_branch>并在<start_point>处启动它
    -t, --track                     # 创建新分支时，设置“上游”配置
    --no-track                      # 即使branch.autoSetupMerge配置变量为true，也不要设置“上游”配置
    -l                              # 创建新分支的reflog
    --detach                        # 而不是检查一个分支来处理它，检查提交检查和可废弃的实验
    --orphan <new_branch>           # 创建一个名为<new_branch> 的新孤立分支，从<start_point>开始并切换到该分支
    --ignore-skip-worktree-bits     # 在稀疏结帐模式下，git checkout -- <paths>只会更新$GIT_DIR/info/sparse-checkout中由<路径>和稀疏模式匹配的条目
    -m, --merge                     # 在切换分支时，如果对当前分支与切换到的分支之间的一个或多个文件进行本地修改，则该命令将拒绝切换分支以便在上下文中保留修改
    --conflict=<style>              # 与上面的--merge选项相同，但改变了冲突的区块显示方式，覆盖merge.conflictStyle配置变量
    -p, --patch                     # 在<tree-ish>（或索引，如果未指定）和工作树之间的区别中交互地选择hunk。然后将选定的区块反向应用于工作树（并且如果指定了<tree-ish>，则索引）
    --ignore-other-worktrees        # git checkout当被通缉的裁判已经被另一个工作树签出时拒绝。这个选项使它无论如何检查裁判
    --[no-]recurse-submodules       # 使用--recurse子模块将根据超级项目中记录的提交更新所有已初始化的子模块的内容
    <branch>                        # 分支, 如果它引用了一个分支（即，前缀为“refs/heads/”的名称是有效的ref），那么该分支将被签出
    <new_branch>                    # 新分支的名称
    <start_point>                   # 要开始新分支的提交的名称
    <tree-ish>                      # 要检出的树（当有路径时）。如果未指定，则会使用索引
```

#### 【merge】

```shell
语法：
    git merge [-n] [--stat] [--no-commit] [--squash] [--[no-]edit]
        [-s <strategy>] [-X <strategy-option>] [-S[<keyid>]]
        [--[no-]allow-unrelated-histories]
        [--[no-]rerere-autoupdate] [-m <msg>] [<commit>…​]
    git merge --abort
    git merge --continue

选项：
    --commit, --no-commit                       # 执行合并并提交结果。这个选项可以用来覆盖--no-commit
    -e, --edit, --no-edit                       # 在提交成功的机械合并之前调用编辑器来进一步编辑自动生成的合并消息，以便用户可以解释并验证合并
    --ff                                        # 当合并解析为快进时，只更新分支指针，而不创建合并提交。这是默认行为
    --no-ff                                     # 即使合并解析为快进，也可以创建合并提交。这是合并注释标记时的默认行为
    --ff-only                                   # 拒绝合并并以非零状态退出，除非当前HEAD已更新或合并可以解决为快进
    -S[<keyid>], --gpg-sign[=<keyid>]           # GPG-签署合并提交
    --log[=<n>], --no-log                       # 除了分支名称之外，还可以用来自至多<n>实际提交的单行描述来填充日志消息
    --signoff, --no-signoff                     # 提交日志消息结尾处的提交者添加Signed-off-by行
    --stat, -n, --no-stat                       # 在合并结束时显示diffstat。diffstat也由配置选项merge.stat控制
    --squash, --no-squash                       # 生成工作树和索引状态，就像发生真正的合并一样，但实际上并未进行提交，移动HEAD或记录$GIT_DIR/MERGE_HEAD 
    -s <strategy>, --strategy=<strategy>        # 使用给定的合并策略; 可以多次提供，以按照他们应该尝试的顺序指定它们
    -X <option>, --strategy-option=<option>     # 将合并策略特定选项传递给合并策略
    --verify-signatures, --no-verify-signatures # 验证被合并的分支的提示提交是否使用有效密钥进行签名，即具有有效uid的密钥：在默认信任模型中，
                                                  这意味着签名密钥已由可信密钥签名。如果侧分支的提示提交未使用有效密钥进行签名，则会中止合并
    --summary, --no-summary                     # 同义词--stat和--no-stat; 这些已被弃用，并将在未来被删除
    -q, --quiet                                 # 安静地操作。意味着 - 没有进步
    -v, --verbose                               # 详细
    --progress, --no-progress                   # 明确地打开/关闭进度。如果没有指定，如果标准错误连接到终端，则显示进度
    --allow-unrelated-histories                 # 默认情况下，git merge命令拒绝合并不共享祖先的历史记录
    -m <msg>                                    # 设置要用于合并提交的提交消息（以防创建）
    --[no-]rerere-autoupdate                    # 如果可能的话，允许rerere机制用自动冲突解决的结果更新索引
    --abort                                     # 中止当前的冲突解决过程，并尝试重新构建预合并状态
    --continue                                  # 经过git的合并，由于停止冲突，那么可以得出结论：通过运行合并混帐合并--continue
    <commit>…​                                   # 提交, 通常其他分支, 合并到我们的分支
```

#### 【mergetool】

```shell
语法：
    git mergetool [--tool=<tool>] [-y | --[no-]prompt] [<file>…​]
    
选项：
    -t <tool>, --tool=<tool>  # 使用<tool>指定的合并解析程序。有效值包括emerge，gvimdiff，kdiff3，meld，vimdiff和tortoisemerge。 运行git mergetool --tool-help 有效的<工具>设置列表
    --tool-help               # 打印可能使用的合并工具列表--tool
    -y, --no-prompt           # 在每次调用合并解析程序之前不要提示。如果通过--tool或 merge.tool配置变量显式指定合并解析程序(默认值)
    --prompt                  # 在每次调用合并解决方案之前提示，以使用户有机会跳过该路径
    -O<orderfile>             # 按照<orderfile>中指定的顺序处理文件，每行有一个shell glob模式
```

#### 【log】

```shell
语法：
    git log [<options>] [<revision range>] [[\--] <path>…​]
    
选项：
    --follow                                                     # 继续列出除重命名之外的文件历史记录（仅适用于单个文件）
    --no-decorate, --decorate[=short|full|auto|no]               # 打印出任何提交的ref名称
    --decorate-refs=<pattern>, --decorate-refs-exclude=<pattern> # 如果没有--decorate-refs给出，假装所有参考文献都包含在内
    --source                                                     # 打印在每个提交到达的命令行上给出的ref名称
    --use-mailmap                                                # 使用邮件地图文件将作者和提交者姓名和电子邮件地址映射到规范的实名和电子邮件地址
    --full-diff                                                  # 没有此标志，git log -p <path>...显示提交触摸指定的路径，并且差异关于相同指定的路径
    --log-size                                                   # 在每个提交的输出中包含一行“log size <number>”，其中<number>是该提交消息的长度（以字节为单位）
    -L <start>,<end>:<file>, -L :<funcname>:<file>               # 跟踪<file>中由“<start>，<end>”（或函数名称regex <funcname>）给出的行范围的演变
    <revision range>                                             # 仅显示指定修订范围内的提交
    [\--] <path>…​                                                # 仅显示足以解释如何匹配指定路径的文件的提交
    
提交限制：                                        
    -<number>, -n <number>, --max-count=<number>         # 限制提交输出的数量
    --skip=<number>                                      # 在开始显示提交输出之前跳过数字提交
    --since=<date>, --after=<date>                       # 显示比特定日期更近的提交
    --until=<date>, --before=<date>                      # 显示比特定日期更早的提交
    --author=<pattern>, --committer=<pattern>            # 将提交输出限制为与指定模式（正则表达式）匹配的作者/提交者标题行
    --grep-reflog=<pattern>                              # 将提交输出限制为具有与指定模式（正则表达式）匹配的reflog条目的提交输出
    --grep=<pattern>                                     # 将提交输出限制为符合指定模式（正则表达式）的日志消息
    --all-match                                          # 将提交输出限制为匹配所有给定的提交--grep，而不是至少匹配一个提交
    --invert-grep                                        # 将提交输出限制为与日志消息不匹配的模式--grep=<pattern>
    -i, --regexp-ignore-case                             # 匹配正则表达式限制模式而不考虑字母大小写
    --basic-regexp                                       # 考虑限制模式是基本的正则表达式; 这是默认值
    -E, --extended-regexp                                # 考虑限制模式是扩展正则表达式而不是默认的基本正则表达式
    -F, --fixed-strings                                  # 考虑限制模式为固定字符串（不要将模式解释为正则表达式）
    -P, --perl-regexp                                    # 考虑限制模式是与Perl兼容的正则表达式
    --remove-empty                                       # 当给定的路径从树上消失时停止
    --merges                                             # 仅打印合并提交。这完全一样--min-parents=2
    --no-merges                                          # 不要打印与多个父代的提交。这完全一样--max-parents=1
    --min-parents=<number>, --max-parents=<number>       # 仅显示至少（或至多）多次父级提交的提交
    --no-min-parents, --no-max-parents                   # --no-min-parents并--no-max-parents重新设置这些限制（无限制）
    --first-parent                                       # 在查看合并提交后，只跟踪第一个父提交
    --not                                                # 反转的意思^前缀（或缺乏）的所有后续修订说明符，到下一个--not
    --all                                                # 假设所有的参考文件refs/，以及HEAD命令行都列为<commit>
    --branches[=<pattern>]                               # 假设所有的参数refs/heads都在命令行上列为<commit>。如果给定<pattern>，则将分支限制为与给定shell glob匹配的分支
    --tags[=<pattern>]                                   # 假设所有的参数refs/tags都在命令行上列为<commit>。如果给出<pattern>，则将标记限制为与给定shell glob相匹配的标记
    --remotes[=<pattern>]                                # 假设所有的参数refs/remotes都在命令行上列为<commit>。如果给出<pattern>，则将远程跟踪分支限制为与给定shell glob匹配的分支
    --glob=<glob-pattern>                                # 假设所有与shell glob <glob-pattern>匹配的ref 在命令行中都以<commit>列出。前导refs /，如果缺失，将自动添加前缀
    --exclude=<glob-pattern>                             # 不包括裁判匹配<水珠图案>，未来--all， --branches，--tags，--remotes，或--glob原本考虑
    --reflog                                             # 假设所有reflog提到的对象都在命令行中列为<commit>
    --single-worktree                                    # 默认情况下，所有工作的树木将被下面的选项时，有一个以上--all，--reflog和 --indexed-objects。该选项强制他们仅检查当前工作树
    --ignore-missing                                     # 在输入中看到一个无效的对象名称时，假装没有给出错误的输入
    --bisect                                             # 假装好坏的二等分参考文献refs/bisect/bad 被列出，并且仿佛它被跟随，--not并且良好的平分参考refs/bisect/good-*命令行
    --stdin                                              # 除了命令行上列出的<commit>之外，还可以从标准输入中读取它们。如果--看到分隔符，请停止读取提交并开始读取路径以限制结果
    --cherry-mark                                        # 像--cherry-pick（见下面）但标记等价提交=而不是省略它们，而不等价的提交+
    --cherry-pick                                        # 当提交集合受到对称差异限制时，省略任何提交引入与“另一侧”上的另一个提交相同的更改的提交
    --left-only, --right-only                            # 列表仅在对称差异的相应侧提交，即只有那些将被标记<为resp的列表。>通过 --left-right
    --cherry                                             # 的代名词--right-only --cherry-mark --no-merges; 有用的是将输出限制在我们这边的提交中，并将那些已经应用到
                                                           分叉历史的另一边的标记标记为 git log --cherry upstream...mybranch类似于 git cherry upstream mybranch
    -g, --walk-reflogs                                   # 而不是走提交祖先链，将reflog条目从最近的一条走到更旧的条目
    --merge                                              # 合并失败后，显示引用文件有冲突并且不存在于所有合并头上
    --boundary                                           # 输出排除边界提交。边界提交以前缀-
    
历史简化：
    <paths>                                              # 提交修改给定的<路径>被选中
    --simplify-by-decoration                             # 由某个分支或标签引用的提交被选中
        Default mode                                     # 将历史简化为解释树的最终状态的最简单历史记录
        --full-history                                   # 与默认模式相同，但不修剪某些历史记录
        --dense                                          # 只显示选定的提交，另外一些提供有意义的历史记录
        --sparse                                         # 显示简化历史记录中的所有提交
        --simplify-merges                                # 附加选项可--full-history从结果历史记录中删除一些不必要的合并，因为没有选定的提交对此合并作出贡献
        --ancestry-path                                  # 当给定一个范围提交的显示（例如commit1..commit2 或commit2 ^ commit1），
                                                           只直接存在于之间的祖先链显示提交commit1和 commit2，即提交属于的两个后代commit1，和祖先commit2

提交订单：                                                
    --date-order                                         # 在显示所有孩子之前不显示父母，但在提交时间戳顺序中显示提交
    --author-date-order                                  # 在显示所有孩子之前不显示父母，但以作者时间戳顺序显示提交
    --topo-order                                         # 在显示所有孩子之前不要显示父母，并且避免在多行历史记录中混合显示提交
    --reverse                                            # 以相反顺序输出选择显示的提交。不能与之结合 --walk-reflogs

对象遍历：                                                    
    --no-walk[=(sorted|unsorted)]                        # 只显示给定的提交，但不要遍历其祖先。如果指定了范围，则这不起作用。如果提供了参数 unsorted，
　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　 则提交按照它们在命令行上的顺序显示。否则（如sorted没有给参数），提交按提交时间以反向时间顺序显示。不能与之结合--graph
    --do-walk                                            # 覆盖以前--no-walk

提交格式：                                                
    --pretty[=<format>], --format=<format>               # 漂亮地打印在提交日志的内容在给定的格式，其中<格式>可以是一个ONELINE，短，中等，充分，更全面的，电子邮件，原料，格式：<字符串> 和tformat：<字符串>        
    --abbrev-commit                                      # 不显示完整的40字节十六进制提交对象名称，只显示部分前缀
    --no-abbrev-commit                                   # 显示完整的40字节十六进制提交对象名称。这种否定 --abbrev-commit和暗示它的选项如“--oneline”
    --oneline                                            # 这是一起使用的“--pretty = oneline --abbrev-commit”的缩写
    --encoding=<encoding>                                # 提交对象在其编码头中记录用于日志消息的编码; 这个选项可以用来告诉命令在用户首选的编码中重新编写提交日志消息
    --expand-tabs=<n>, --expand-tabs, --no-expand-tabs   # 在输出中显示日志消息之前，执行一个选项卡扩展（将每个选项卡用足够的空格替换，以填充日志消息中的倍数为<n>的下一个显示列）
    --notes[=<treeish>]                                  # 在显示提交日志消息时，显示注释提交的注释
    --no-notes                                           # 不要显示笔记
    --show-signature                                     # 通过签名传递gpg --verify并显示输出来检查签名提交对象的有效性
    --relative-date                                      # 的同义词--date=relative
    --date=<format>                                      # 仅对以人可读格式显示的日期生效，例如在使用时--pretty。log.dateconfig变量为log命令的--date选项设置一个默认值
    --parents                                            # 也打印提交的父母（以“commit parent ...”的形式）
    --children                                           # 也打印提交的子代（以“commit child ...”的形式）
    --left-right                                         # 标记可以从中提交提交的对称差异的哪一侧。来自左侧的提交将以前面的<和前面的提交>。如果合并--boundary，那些提交前缀为-
    --graph                                              # 在输出的左侧绘制提交历史记录的基于文本的图形表示
    --show-linear-break[=<barrier>]                      # 当不使用--graph时，所有历史分支都会变平，这使得很难看到两个连续的提交不属于线性分支

区分格式：                                                
    -c                                                   # 使用此选项，合并提交的差异输出会同时显示每个父级与合并结果的差异，而不是显示父级与每次结果之间的pairwise差异
    --cc                                                 # 这个标志意味着这个-c选项，并通过省略父母内容只有两个变体的无趣hunk来进一步压缩补丁输出，并且合并结果不加修改地选择其中的一个
    -m                                                   # 这个标志使得合并提交显示了像常规提交一样的完整差异; 对于每个合并父项，会生成一个单独的日志条目和diff
    -r                                                   # 显示递归差异
    -t                                                   # 在diff输出中显示树对象。这意味着-r
```

#### 【stash】

```shell
语法：
    git stash list [<options>]
    git stash show [<stash>]
    git stash drop [-q|--quiet] [<stash>]
    git stash ( pop | apply ) [--index] [-q|--quiet] [<stash>]
    git stash branch <branchname> [<stash>]
    git stash [push [-p|--patch] [-k|--[no-]keep-index] [-q|--quiet]
             [-u|--include-untracked] [-a|--all] [-m|--message <message>]
             [--] [<pathspec>…​]]
    git stash clear
    git stash create [<message>]
    git stash store [-m|--message <message>] [-q|--quiet] <commit>

选项：
    push [-p|--patch] [-k|--[no-]keep-index] [-q|--quiet]        
        [-u|--include-untracked] [-a|--all] [-m|--message <message>]
        [--] [<pathspec>…​]                 # 将您的本地修改保存到新的存储条目中，并将它们回滚到HEAD（在工作树和索引中）
    list [<options>]                       # 列出您当前拥有的存储条目
    show [<stash>]                         # 显示存储条目中记录的更改，作为隐藏内容和提交首次创建存储条目时的提交之间的差异
    pop [--index] [-q|--quiet] [<stash>]   # 从存储列表中删除一个单独的存储状态并将其应用于当前工作树状态的顶部，即进行反操作git stash push。工作目录必须与索引匹配
    apply [--index] [-q|--quiet] [<stash>] # 喜欢pop，但不要从存储列表中删除状态。不像pop， <stash>可能是任何看起来像由stash pushor 创建的提交 stash create
    branch <branchname> [<stash>]          # 创建并检出<branchname>从<stash>最初创建的提交开始的新分支，将记录的更改应用<stash>到新的工作树和索引
    clear                                  # 删除所有的存储条目
    drop [-q|--quiet] [<stash>]            # 从存储条目列表中删除单个存储条目。如果没有<stash>给出，它将删除最新的一个
    create                                 # 创建一个存储条目（这是一个常规的提交对象）并返回它的对象名称，而不将它存储在ref命名空间的任何位置
    store                                  # 在存储引用中存储通过git stash create（这是一个悬挂的合并提交）创建的给定存储，更新存储引用日志
```

#### 【tag】

```shell
语法：
    git tag [-a | -s | -u <keyid>] [-f] [-m <msg> | -F <file>] [-e]
        <tagname> [<commit> | <object>]
    git tag -d <tagname>…​
    git tag [-n[<num>]] -l [--contains <commit>] [--no-contains <commit>]
        [--points-at <object>] [--column[=<options>] | --no-column]
        [--create-reflog] [--sort=<key>] [--format=<format>]
        [--[no-]merged [<commit>]] [<pattern>…​]
    git tag -v [--format=<format>] <tagname>…​

选项：
    -a, --annotate                          # 制作一个未签名的带注释的标签对象
    -s, --sign                              # 使用默认的电子邮件地址密钥创建一个GPG签名的标签
    -u <keyid>, --local-user=<keyid>        # 使用给定的密钥创建一个GPG签名的标签
    -f, --force                             # 用给定名称替换现有标签（而不是失败）
    -d, --delete                            # 用给定名称删除现有标签
    -v, --verify                            # 验证给定标签名称的GPG签名
    -n<num>                                 # <num>指定在使用-l时打印多少行（如果有）。意味着--list
    -l, --list                              # 列表标签
    --sort=<key>                            # 根据给定的关键字进行排序。前缀-按值的降序进行排序
    -i, --ignore-case                       # 排序和过滤标签不区分大小写
    --column[=<options>], --no-column       # 在列中显示标签列表
    --contains [<commit>]                   # 只列出包含指定提交的标签（如果未指定，则为HEAD）。意味着--list
    --no-contains [<commit>]                # 只列出不包含指定提交的标签（如果未指定，则为HEAD）。意味着--list
    --merged [<commit>]                     # 仅列出可从提交的提交（HEAD如果未指定）可访问的列表标记，与之不兼容--no-merged
    --no-merged [<commit>]                  # 仅列出其提交无法从指定提交（HEAD如果未指定）到达的标记，与之不兼容--merged
    --points-at <object>                    # 只列出给定对象的标签（HEAD，如果未指定）。意味着--list
    -m <msg>, --message=<msg>               # 使用给定的标签消息（而不是提示）
    -F <file>, --file=<file>                # 从给定的文件中获取标签消息。使用-从标准输入中读取消息。
    -e, --edit                              # 从带有-F和命令行的 文件中获取的消息-m通常用作未经修改的标记消息
    --cleanup=<mode>                        # 该选项设置标签消息的清理方式
    --create-reflog                         # 为标签创建一个reflog
    <tagname>                               # 要创建，删除或描述的标记的名称
    <commit>, <object>                      # 新标签将引用的对象，通常是提交。默认为HEAD
    <format>                                # %(fieldname)从显示的标记ref和指向的对象中插入一个字符串
```

#### 【worktree】

```shell
语法：
    git worktree add [-f] [--detach] [--checkout] [--lock] [-b <new-branch>] <path> [<commit-ish>]
    git worktree list [--porcelain]
    git worktree lock [--reason <string>] <worktree>
    git worktree move <worktree> <new-path>
    git worktree prune [-n] [-v] [--expire <expire>]
    git worktree remove [--force] <worktree>
    git worktree unlock <worktree>

选项：
    add <path> [<commit-ish>]          # 创建<path>并签<commit-ish>出
    list                               # 列出每个工作树的详细信息
    lock                               # 如果工作树位于便携式设备或网络共享上，且该共享并非始终挂载，请将其锁定以防止其管理文件被自动修剪
    move                               # 将工作树移到新位置
    prune                              # 修剪$ GIT_DIR / worktrees中的修剪树信息
    remove                             # 删除一棵工作树。只有干净的工作树（没有未跟踪的文件，并且没有修改跟踪的文件）可以被删除
    unlock                             # 解锁一个工作树，允许它被修剪，移动或删除
    -f, --force                        # 默认情况下，add拒绝创建一个新的工作树，当它 <commit-ish>是一个分支名称并且已经被另一个工作树签出并remove拒绝删除不干净的工作树时
    -b <new-branch>, -B <new-branch>   # 用add，创建一个名为<new-branch>起始处 的新分支<commit-ish>，并检查<new-branch>新的工作树
    --detach                           # 随着add，在新的工作树中分离HEAD
    --[no-]checkout                    # 默认情况下，add检查出来<commit-ish>，但--no-checkout可以用来抑制，以进行自定义，如配置稀疏结帐结帐
    --[no-]guess-remote                # 与worktree add <path>没有，<commit-ish>而不是创建从HEAD一个新的分支，如果存在在恰好一个远程匹配的
                                         基本名称的跟踪分支<path>，立足于远程跟踪分支的新分支，并标记远程跟踪分支为“上游”来自新的分支
    --[no-]track                       # 创建新分支时，如果<commit-ish>是分支，则将其标记为新分支中的“上游”
    --lock                             # 创建后保持工作树锁定
    -n, --dry-run                      # 随着prune，不要删除任何东西; 只是报告它会删除什么
    --porcelain                        # 使用list，输出脚本的易于解析的格式
    -v, --verbose                      # 随着prune，报告所有清除
    --expire <time>                    # 使用时prune，只会使<age>以前的未使用的工作树过期
    --reason <string>                  # 随着lock，为什么工作树被锁定的解释
    <worktree>                         # 工作树可以通过相对路径或绝对路径来标识
```

#### 【fetch】

```shell
语法：
    git fetch [<options>] [<repository> [<refspec>…​]]
    git fetch [<options>] <group>
    git fetch --multiple [<options>] [(<repository> | <group>)…​]
    git fetch --all [<options>]

选项：
    --all                                    # 取回所有遥控器
    -a, --append                             # 追加refs的ref名称和对象名称到现有的内容.git/FETCH_HEAD。
    --depth=<depth>                          # 将提取限制为从每个远程分支历史记录的提示中指定的提交数量
    --deepen=<depth>                         # 与--depth相似，只是它指定了来自当前浅边界而不是每个远程分支历史记录的提示的提交数
    --shallow-since=<date>                   # 加深或缩短浅储存库的历史记录，以便在<date>之后包含所有可访问的提交
    --shallow-exclude=<revision>             # 加深或缩短浅储存库的历史记录，以排除可从指定的远程分支或标记访问的提交
    --unshallow                              # 如果源存储库已完成，请将浅层存储库转换为完整存储库，以消除浅存储库施加的所有限制
    --update-shallow                         # 默认情况下，从浅仓库中获取时， git fetch拒绝需要更新.git/shallow的引用
    --dry-run                                # 显示将做什么，不做任何改变
    -f, --force                              # 当git fetch与<rbranch>:<lbranch> refspec一起使用时，它拒绝更新本地分支， 
                                               <lbranch>除非<rbranch>它获取的远程分支是子孙的后代<lbranch>
    -k, --keep                               # 保持下载的包
    --multiple                               # 允许指定多个<repository>和<group>参数
    -p, --prune                              # 在提取之前，请删除远程不再存在的所有远程跟踪参考
    -P, --prune-tags                         # 在获取之前，删除--prune已启用的远程不再存在的所有本地标记
    -n, --no-tags                            # 默认情况下，指向从远程存储库下载的对象的标签将在本地​​获取并存储
    --refmap=<refspec>                       # 在获取命令行中列出的ref时，使用指定的refspec（可以多次提供）将ref映射到远程跟踪分支，而不是remote.*.fetch远程存储库的配置变量的值 
    -t, --tags                               # 从远程获取所有标签（即，将远程标签获取 refs/tags/*到具有相同名称的本地标签中），除此之外的任何其他内容都将被提取
    --recurse-submodules[=yes|on-demand|no]  # 此选项控制是否以及在什么条件下也应提取填充的子模块的新提交
    -j, --jobs=<n>                           # 用于提取子模块的并行子项的数量
    --no-recurse-submodules                  # 禁用递归获取子模块（这与使用该--recurse-submodules=no选项具有相同的效果）
    --submodule-prefix=<path>                # 在信息消息（如“获取子模块foo”）中打印路径前加上<path>
    --recurse-submodules-default=[yes|on-demand] # 此选项在内部用于为--recurse-submodules选项临时提供非负的默认值
    -u, --update-head-ok                         # 默认情况下，git fetch拒绝更新与当前分支对应的头部
    --upload-pack <upload-pack>                  # 当给定时，并且从git fetch-pack处理要从中获取的存储库，--exec=<upload-pack>将传递给该命令以指定在另一端运行的命令的非默认路径
    -q, --quiet                                  # 通过 - 安静的git-fetch-pack和沉默任何其他内部使用的git命令
    -v, --verbose                                # 详细
    --progress                                   # 当连接到终端时，默认情况下，标准错误流中会报告进度状态，除非指定-q
    -4, --ipv4                                   # 仅使用IPv4地址，忽略IPv6地址
    -6, --ipv6                                   # 仅使用IPv6地址，忽略IPv4地址
    <repository>                                 # 作为提取或拉取操作源的“远程”存储库
    <group>                                      # 名称指的是存储库列表，作为配置文件中的远程数据<group>的值
    <refspec>                                    # 指定要获取哪些引用以及哪些本地引用要更新
```

#### 【pull】

```shell
语法：
    git pull [options] [<repository> [<refspec>…​]]

选项：
    -q, --quiet                                    # 这被传递给底层的git-fetch，以便在传输过程中压制报告，并在合并过程中将潜在的git-merge压制成静噪输出
    -v, --verbose                                  # 通过--verbose git-fetch和git-merge
    --[no-]recurse-submodules[=yes|on-demand|no]   # 该选项控制是否应该提取和更新所有已填充子模块的新提交

与合并有关的选项：
    --commit， --no-commit      　　　　　　　　      # 执行合并并提交结果
    -e, --edit, --no-edit                          # 在提交成功的机械合并之前调用编辑器来进一步编辑自动生成的合并消息，以便用户可以解释并验证合并
    --ff                                           # 当合并解析为快进时，只更新分支指针，而不创建合并提交。这是默认行为
    --no-ff                                        # 即使合并解析为快进，也可以创建合并提交
    --ff-only                                      # 拒绝合并并以非零状态退出，除非电流HEAD已经是最新的或合并可以解决为快进
    --log[=<n>], --no-log                          # 除了分支名称之外，还可以用来自至多<n>实际提交的单行描述来填充日志消息
    --stat, -n, --no-stat                          # 在合并结束时显示diffstat。diffstat也由配置选项merge.stat控制
    --squash, --no-squash                          # 生成工作树和索引状态，就像发生真正的合并（合并信息除外）一样，但实际上并未进行提交，
                                                     移动HEAD或记录$GIT_DIR/MERGE_HEAD （以导致下一个git commit命令创建合并提交）
    -s <strategy>, --strategy=<strategy>           # 使用给定的合并策略; 可以多次提供，以按照他们应该尝试的顺序指定它们
    -X <option>, --strategy-option=<option>        # 将合并策略特定选项传递给合并策略
    --verify-signatures, --no-verify-signatures    # 验证被合并的分支的提示提交是否使用有效密钥进行签名，即具有有效uid的密钥：在默认信任模型中，这意味着签名密钥已由可信密钥签名
    --allow-unrelated-histories                    # 默认情况下，git merge命令拒绝合并不共享祖先的历史记录
    -r, --rebase[=false|true|preserve|interactive] # 如果为true，则在获取后重新绑定上游分支顶部的当前分支
    --no-rebase                                    # 早先覆盖--rebase
    --autostash, --no-autostash                    # 在开始rebase之前，如果需要，将局部修改隐藏起来，并在完成时应用存储条目

与抓取相关的选项:
    --all                                          # 取回所有遥控器
    -a, --append                                   # 追加refs的ref名称和对象名称到现有的内容.git/FETCH_HEAD
    --depth=<depth>                                # 将提取限制为从每个远程分支历史记录的提示中指定的提交数量
    --deepen=<depth>                               # 与--depth相似，只是它指定了来自当前浅边界而不是每个远程分支历史记录的提示的提交数
    --shallow-since=<date>                         # 加深或缩短浅储存库的历史记录，以便在<date>之后包含所有可访问的提交
    --shallow-exclude=<revision>                   # 加深或缩短浅储存库的历史记录，以排除可从指定的远程分支或标记访问的提交
    --unshallow                                    # 如果源存储库已完成，请将浅层存储库转换为完整存储库，以消除浅存储库施加的所有限制
    --update-shallow                               # 默认情况下，从浅仓库中获取时， git fetch拒绝需要更新.git/shallow的引用
    -f, --force                                    # 当git fetch与<rbranch>:<lbranch> refspec一起使用时，它拒绝更新本地分支，<lbranch>除非<rbranch>它获取的远程分支是子孙的后代<lbranch>
    -k, --keep                                     # 保持下载的包
    --no-tags                                      # 默认情况下，指向从远程存储库下载的对象的标签将在本地​​获取并存储
    -u, --update-head-ok                           # 默认情况下，git fetch拒绝更新与当前分支对应的头部
    --upload-pack <upload-pack>                    # 当给定时，并且从git fetch-pack处理要从中获取的存储库，--exec=<upload-pack>将传递给该命令以指定在另一端运行的命令的非默认路径
    --progress                                     # 当连接到终端时，默认情况下，标准错误流中会报告进度状态，除非指定-q
    -4, --ipv4                                     # 仅使用IPv4地址，忽略IPv6地址
    -6, --ipv6                                     # 仅使用IPv6地址，忽略IPv4地址
    <repository>                                   # 作为提取或拉取操作源的“远程”存储库
    <refspec>                                      # 指定要获取哪些引用以及哪些本地引用要更新
```

#### 【push】

```shell
语法：
    git push [--all | --mirror | --tags] [--follow-tags] [--atomic] [-n | --dry-run] [--receive-pack=<git-receive-pack>]
           [--repo=<repository>] [-f | --force] [-d | --delete] [--prune] [-v | --verbose]
           [-u | --set-upstream] [--push-option=<string>]
           [--[no-]signed|--signed=(true|false|if-asked)]
           [--force-with-lease[=<refname>[:<expect>]]]
           [--no-verify] [<repository> [<refspec>…​]]

选项：
    <repository>                                    # 作为推送操作目标的“远程”存储库
    <refspec>…​                                      # 用什么源对象指定要更新的目标引用
    --all                                           # 推送所有分支（即参考下refs/heads/）; 不能与其他<refspec>一起使用
    --prune                                         # 删除没有本地副本的远程分支
    --mirror                                        # 代替命名每个裁判推的，指定了下的所有参考文献refs/（包括但不限于refs/heads/，refs/remotes/和refs/tags/）被镜像到远程存储库
    -n, --dry-run                                   # 除了实际发送更新之外，请做其他事
    --porcelain                                     # 生成机器可读的输出
    --delete                                        # 所有列出的ref都从远程存储库中删除
    --tags                                          # refs/tags除了在命令行中明确列出的refspecs之外，所有refs 都将被推送
    --follow-tags                                   # 推送所有没有此选项时将被推送的引用，并且推送refs/tags远程引用中缺少的带注释的标签，但指向可从所推送的引用访问的提交标识
    --[no-]signed, --signed=(true|false|if-asked)   # GPG-签署推送请求以更新接收端的refs，以便通过钩子检查和/或记录
    --[no-]atomic                                   # 如果可用，请在远程端使用原子事务
    -o <option>, --push-option=<option>             # 将给定的字符串传送给服务器，服务器将它们传递给预接收以及接收后挂接
    --receive-pack=<git-receive-pack>, --exec=<git-receive-pack>          # 远程端上git-receive-pack程序的路径
    --[no-]force-with-lease, --force-with-lease=<refname>,      
    --force-with-lease=<refname>:<expect>                                 # 如果远程ref的当前值是期望值，则此选项将覆盖此限制
    -f, --force                                                           # 通常，该命令拒绝更新远程ref，该远程ref不是用于覆盖它的本地ref的祖先
    --repo=<repository>                                                   # 该选项等同于<repository>参数。如果两者都指定，则命令行参数优先
    -u, --set-upstream                                                    # 对于最新或成功推送的每个分支，添加无参数git-pull [1]和其他命令使用的上游（跟踪）引用
    --[no-]thin                                                           # 这些选项被传递给git-send-pack [1]
    -q, --quiet                                                           # 抑制所有输出，包括更新的引用列表，除非发生错误
    -v, --verbose                                                         # 运行详细
    --progress                                                            # 当连接到终端时，默认情况下，标准错误流中会报告进度状态，除非指定-q
    --no-recurse-submodules, --recurse-submodules=check|on-demand|only|no # 可用于所有子模块提交的修改被推到远程跟踪分支上
    --[no-]verify                                                         # 切换预推钩。默认值：验证，使钩子有机会阻止推送
    -4, --ipv4                                                            # 仅使用IPv4地址，忽略IPv6地址
    -6, --ipv6                                                            # 仅使用IPv6地址，忽略IPv4地址
```

#### 【remote】

```shell
语法：
    git remote [-v | --verbose]
    git remote add [-t <branch>] [-m <master>] [-f] [--[no-]tags] [--mirror=<fetch|push>] <name> <url>
    git remote rename <old> <new>
    git remote remove <name>
    git remote set-head <name> (-a | --auto | -d | --delete | <branch>)
    git remote set-branches [--add] <name> <branch>…​
    git remote get-url [--push] [--all] <name>
    git remote set-url [--push] <name> <newurl> [<oldurl>]
    git remote set-url --add [--push] <name> <newurl>
    git remote set-url --delete [--push] <name> <url>
    git remote [-v | --verbose] show [-n] <name>…​
    git remote prune [-n | --dry-run] <name>…​
    git remote [-v | --verbose] update [-p | --prune] [(<group> | <remote>)…​]

选项：
    -v, --verbose       # 稍微详细一点，并在名称后显示远程URL
    add                 # 在<url>处添加一个名为<名称>的存储库
    rename              # 将名为<old>的远程重命名为<new>。远程的所有远程跟踪分支和配置设置都会更新
    rm,    remove       # 删除名为<名称>的远程。远程的所有远程跟踪分支和配置设置均被删除
    set-head            # 设置或删除refs/remotes/<name>/HEAD指定远程的默认分支（即symbolic-ref的目标）
    set-branches        # 更改已命名远程所跟踪分支的列表
    get-url             # 检索远程的URL
    set-url             # 更改远程的URL
    show                # 给出关于远程<名称>的一些信息
    prune               # 删除与<名称>关联的陈旧引用
    update              # 按遥控器<group>的定义，获取存储库中一组指定遥控器的更新
```

#### 【submodule】

```shell
语法：
    git submodule [--quiet] add [<options>] [--] <repository> [<path>]
    git submodule [--quiet] status [--cached] [--recursive] [--] [<path>…​]
    git submodule [--quiet] init [--] [<path>…​]
    git submodule [--quiet] deinit [-f|--force] (--all|[--] <path>…​)
    git submodule [--quiet] update [<options>] [--] [<path>…​]
    git submodule [--quiet] summary [<options>] [--] [<path>…​]
    git submodule [--quiet] foreach [--recursive] <command>
    git submodule [--quiet] sync [--recursive] [--] [<path>…​]
    git submodule [--quiet] absorbgitdirs [--] [<path>…​]

选项：
    -q, --quiet                # 只打印错误消息
    --all                      # 该选项仅对deinit命令有效。取消注册工作树中的所有子模块
    -b, --branch               # 将存储库的分支添加为子模块
    -f, --force                # 该选项仅适用于添加，删除和更新命令。在运行add时，允许添加一个否则忽略的子模块路径。
    --cached                   # 该选项仅对状态和汇总命令有效。些命令通常使用在子模块HEAD中找到的提交，但使用此选项时，将使用存储在索引中的提交。
    --files                    # 该选项仅对汇总命令有效。当使用此选项时，此命令会将索引中的提交与子模块HEAD中的提交进行比较。
    -n, --summary-limit        # 该选项仅对汇总命令有效。限制摘要大小（总共显示的提交数量）
    --remote                   # 该选项仅对更新命令有效。使用子模块的远程跟踪分支的状态，而不是使用超级项目的已记录的SHA-1来更新子模块
    -N, --no-fetch             # 该选项仅对更新命令有效。不要从远程站点获取新的对象。
    --checkout                 # 该选项仅对更新命令有效。检查子模块中分离的HEAD上超级项目中记录的提交。
    --merge                    # 该选项仅对更新命令有效。将超级项目中记录的提交合并到子模块的当前分支中。
    --rebase                   # 该选项仅对更新命令有效。将当前分支重新映射到超级项目中记录的提交。
    --init                     # 该选项仅对更新命令有效。在更新之前，初始化尚未调用“git子模块初始化”的所有子模块。
    --name                     # 该选项仅对add命令有效。它将子模块的名称设置为给定字符串，而不是默认其路径。
    --reference <repository>   # 该选项仅适用于添加和更新命令。这些命令有时需要克隆远程存储库。
    --recursive                # 此选项仅适用于foreach，更新，状态和同步命令。递归地遍历子模块。
    --depth                    # 该选项对添加和更新命令有效。创建一个 历史记录截断为指定修订版数的浅表副本。
    --[no-]recommend-shallow   # 该选项仅对更新命令有效。默认情况下，子模块的初始克隆将使用submodule.<name>.shallow由.gitmodules文件提供的建议 。
    -j <n>, --jobs <n>         # 该选项仅对更新命令有效。与多个作业并行克隆新子模块。默认为submodule.fetchJobs选项。
    <path>…​                    # 子模块的路径。指定时，将限制该命令仅对在指定路径中找到的子模块进行操作。
```

#### 【show】

```shell
语法：
    git show [options] [<object>…​]

选项：
    <object>…​                                           # 要显示的对象的名称（默认为HEAD）
    --pretty[=<format>], --format=<format>              # 漂亮地打印在提交日志的内容在给定的格式
    --abbrev-commit                                     # 不显示完整的40字节十六进制提交对象名称，只显示部分前缀
    --no-abbrev-commit                                  # 显示完整的40字节十六进制提交对象名称
    --oneline                                           # 这是一起使用的“--pretty = oneline --abbrev-commit”的缩写
    --encoding=<encoding>                               # 提交对象在其编码头中记录用于日志消息的编码; 这个选项可以用来告诉命令在用户首选的编码中重新编写提交日志消息
    --expand-tabs=<n>, --expand-tabs, --no-expand-tabs  # 在输出中显示日志消息之前，执行一个选项卡扩展（将每个选项卡用足够的空格替换，以填充日志消息中的倍数为<n>的下一个显示列）
    --notes[=<treeish>]                                 # 在显示提交日志消息时，显示注释提交的注释（请参阅git-notes [1]）
    --no-notes                                          # 不要显示笔记
    --show-signature                                    # 通过签名传递gpg --verify并显示输出来检查签名提交对象的有效性
```

#### 【shortlog】

```shell
语法：
    git log --pretty=short | git shortlog [<options>]
    git shortlog [<options>] [<revision range>] [[\--] <path>…​]

选项：
    -n, --numbered                         # 根据每个作者的提交数量而不是作者字母顺序对输出进行排序
    -s, --summary                          # 禁止提交描述并仅提供提交计数摘要
    -e, --email                            # 显示每位作者的电子邮件地址
    --format[=<format>]                    # 使用一些其他信息来描述每个提交，而不是提交主题
    -c, --committer                        # 收集并显示提交者身份而不是作者
    -w[<width>[,<indent1>[,<indent2>]]]    # 通过包装每行的输入线来包装输出width
    <revision range>                       # 仅显示指定修订范围内的提交
    [\--] <path>…​                          # 只考虑足以解释如何匹配指定路径的文件的提交
```

#### 【describe】

```shell
语法：
    git describe [--all] [--tags] [--contains] [--abbrev=<n>] [<commit-ish>…​]
    git describe [--all] [--tags] [--contains] [--abbrev=<n>] --dirty[=<mark>]
    git describe <blob>

选项：
    <commit-ish>…​                        # 提交对象名称来描述。如果省略，则默认为HEAD
    --dirty[=<mark>], --broken[=<mark>]  # 描述工作树的状态。当工作树与HEAD匹配时，输出与“git describe HEAD”相同
    --all                                # 不要只使用带注释的标签，而应使用refs/名称空间中的任何参考
    --tags                               # 不要只使用带注释的标签，而要使用refs/tags名称空间中的任何标签
    --contains                           # 不是找到提交之前的标签，而是找到提交之后的标签，因此包含它。自动暗示 - 标签
    --abbrev=<n>                         # 使用默认的7位十六进制数字作为缩写对象名称，而不是使用<n>数字或根据需要的数字来组成一个唯一的对象名称
    --candidates=<n>                     # 而不是只考虑最近的10个标签作为描述输入提交的候选者，而是考虑到候选者
    --exact-match                        # 只输出完全匹配（一个标签直接引用提供的提交）。这是--candidates = 0的同义词。
    --debug                              # 精确地显示正在使用的搜索策略的信息以标准错误。标签名称仍将打印到标准输出。
    --long                               # 即使与标签匹配，始终输出长格式（标签，提交数量和缩写提交名称）
    --match <pattern>                    # 只考虑与给定glob(7)模式匹配的标签，不包括“refs/tags/”前缀
    --exclude <pattern>                  # 不要考虑与给定glob(7)模式匹配的标签，不包括“refs/tags/”前缀
    --always                             # 显示唯一缩写的提交对象作为后备
    --first-parent                       # 在查看合并提交后，只跟踪第一个父提交
```

#### 【apply】

```shell
语法：
    git apply [--stat] [--numstat] [--summary] [--check] [--index] [--3way]
          [--apply] [--no-add] [--build-fake-ancestor=<file>] [-R | --reverse]
          [--allow-binary-replacement | --binary] [--reject] [-z]
          [-p<n>] [-C<n>] [--inaccurate-eof] [--recount] [--cached]
          [--ignore-space-change | --ignore-whitespace]
          [--whitespace=(nowarn|warn|fix|error|error-all)]
          [--exclude=<path>] [--include=<path>] [--directory=<root>]
          [--verbose] [--unsafe-paths] [<patch>…​]

选项：
    <patch>…​                                    # 从中读取补丁的文件。 -可用于从标准输入读取
    --stat                                      # 输出diffstat代替输入补丁。关闭“适用”。
    --numstat                                   # --stat与之类似，但显示十进制表示法中添加和删除的行数以及不带缩写的路径名，以使其更加机器友好
    --summary                                   # 输出从git diff扩展头获取的信息的精简摘要，而不是应用该修补程序。关闭“适用”。
    --check                                     # 而不是应用修补程序，查看修补程序是否适用于当前工作树和/或索引文件并检测错误。关闭“适用”。
    --index                                     # 何时--check生效或应用修补程序，请确保修补程序适用于当前索引文件记录的内容
    --cached                                    # 在不接触工作树的情况下应用补丁
    -3, --3way                                  # 如果修补程序不能干净地应用，如果修补程序记录它应该应用的斑点的标识，则回退到3路合并，
                                                  并且我们在本地可以使用这些斑点，可能会在工作树中的文件中留下冲突标记供用户解决
    --build-fake-ancestor=<file>                # 较新的git diff输出已经 为每个blob 嵌入了索引信息，以帮助识别修补程序适用的原始版本
    -R, --reverse                               # 反向应用补丁
    --reject                                    # 对于原子性，git默认应用会失败整个修补程序，并且在某些不适用的情况下不会触及工作树
    -z                                          # 何时--numstat给出，请勿使用路径名，但使用NUL终止的机器可读格式
    -p<n>                                       # 从传统差异路径中删除<n>引导斜杠。默认值是1。
    -C<n>                                       # 确保每次更改之前和之后至少有<n>行周围环境匹配
    --unidiff-zero                              # 默认情况下，git apply期望所应用的修补程序是一个至少包含一行上下文的统一差异
    --apply                                     # 如果您使用上面标记为“关闭应用 ”的任何选项 ，则git应用读取并输出所请求的信息，而不实际应用修补程序
    --no-add                                    # 应用修补程序时，忽略修补程序添加的内容
    --allow-binary-replacement, --binary        # 从历史上看，我们不允许在未经用户明确许可的情况下应用二进制补丁，并且此标志是实现此目的的方式
    --exclude=<path-pattern>                    # 不要将更改应用于与给定路径模式匹配的文件
    --include=<path-pattern>                    # 将更改应用于与给定路径模式匹配的文件
    --ignore-space-change, --ignore-whitespace  # 应用修补程序时，如果需要，请忽略上下文行中空白的更改
    --whitespace=<action>                       # 应用修补程序时，检测具有空白错误的新行或修改过的行
    --inaccurate-eof                            # 在某些情况下，diff的某些版本不能在文件末尾正确检测到缺失的新行
    -v, --verbose                               # 将进展报告给stderr。默认情况下，只会打印有关当前正在应用的修补程序的消息
    --recount                                   # 不要相信大块头中的行数，但通过检查补丁来推断它们
    --directory=<root>                          # 将<root>加入所有文件名。如果还传递了“-p”参数，则在应用新根之前应用该参数
    --unsafe-paths                              # 默认情况下，影响工作区域以外的补丁被拒绝为错误
```

#### 【cherry-pick】

```shell
语法：
    git cherry-pick [--edit] [-n] [-m parent-number] [-s] [-x] [--ff]
              [-S[<keyid>]] <commit>…​
    git cherry-pick --continue
    git cherry-pick --quit
    git cherry-pick --abort

选项：
    <commit>…​                                    # 要获得一个更完整的拼写方法列表
    -e, --edit                                   # 使用这个选项，git cherry-pick会让你在提交之前编辑提交信息
    -x                                           # 在记录提交时，附加一条线，该行表示“(cherry从提交…)”到原始的提交消息，以指示该更改是从哪个提交的
    -r                                           # 它曾经是命令默认做-x 了上面描述，并且-r是禁用它
    -m parent-number, --mainline parent-number   # 通常你不能选择合并，因为你不知道合并的哪一边应该被认为是主线
    -n, --no-commit                              # 通常，该命令会自动创建一系列提交
    -s, --signoff                                # 在提交消息的末尾添加Signed-off-by行
    -S[<keyid>], --gpg-sign[=<keyid>]            # GPG标志提交
    --ff                                         # 如果当前的HEAD与樱桃挑选的提交的父对象相同，则将执行快速转发此提交
    --allow-empty                                # 默认情况下，樱桃选择一个空的提交将失败，表明需要显式调用git commit --allow-empty
    --allow-empty-message                        # 默认情况下，用空信息挑选提交将失败
    --keep-redundant-commits                     # 如果在当前的历史中，如果提交的是cherry选择了重复提交，那么它将变为空的
    --strategy=<strategy>                        # 使用给定的合并策略。只能使用一次
    -X<option>, --strategy-option=<option>       # 将合并策略特定选项传递给合并策略
    --continue                                   # 继续使用.git/sequencer中的信息进行操作
    --quit                                       # 忘记当前正在进行的操作
    --abort                                      # 取消操作并返回到预序列状态
```

#### 【rebase】

```shell
语法：
    git rebase [-i | --interactive] [options] [--exec <cmd>] [--onto <newbase>]
        [<upstream> [<branch>]]
    git rebase [-i | --interactive] [options] [--exec <cmd>] [--onto <newbase>]
        --root [<branch>]
    git rebase --continue | --skip | --abort | --quit | --edit-todo | --show-current-patch  

选项：
    --onto <newbase>                      # 创建新提交的起点
    <upstream>                            # 上游分支进行比较。可以是任何有效的提交，而不仅仅是现有的分支名称。默认为当前分支的配置上游
    <branch>                              # 工作分部; 默认为HEAD
    --continue                            # 解决了合并冲突后重新启动重新绑定过程
    --abort                               # 中止rebase操作并将HEAD重置为原始分支
    --quit                                # 放弃rebase操作，但HEAD不会重置回原始分支。索引和工作树也因此保持不变
    --keep-empty                          # 在结果中保留不改变父项的任何提交
    --allow-empty-message                 # 默认情况下，重新绑定提交空信息将失败
    --skip                                # 通过跳过当前补丁重新启动重新绑定过程
    --edit-todo                           # 在交互式重新绑定期间编辑待办事项列表
    --show-current-patch                  # 在交互式底图中显示当前的补丁，或者由于冲突而停止底牌。这相当于 git show REBASE_HEAD
    -m, --merge                           # 使用合并策略来重新分配
    -s <strategy>, --strategy=<strategy>  # 使用给定的合并策略
    -X <strategy-option>, --strategy-option=<strategy-option>    # 将<strategy-option>传递给合并策略
    -S[<keyid>], --gpg-sign[=<keyid>]               # GPG标志提交
    -q, --quiet                                     # 安静。意味着 - 无统计
    -v, --verbose                                   # 详细。意味着--stat
    -stat                                           # 显示自上次rebase以来上游变化的差异。diffstat也由配置选项rebase.stat控制
    -n, --no-stat                                   # 不要将diffstat显示为rebase过程的一部分
    --no-verify                                     # 此选项绕过预先重新绑定钩子
    --verify                                        # 允许预重贴挂钩运行，这是默认设置
    -C<n>                                           # 确保每次更改之前和之后至少有<n>行周围环境匹配
    -f, --force-rebase                              # 即使当前分支是最新的，并且--force没有做任何事情的命令也不会返回，强制重新分配
    --fork-point, --no-fork-point                   # 计算<branch>引入的提交时，使用reflog可以在<upstream>和<branch>之间找到更好的共同祖先
    --ignore-whitespace, --whitespace=<option>      # 这些标志被传递给应用该补丁的git apply程序。与--interactive选项不兼容
    --committer-date-is-author-date, --ignore-date  # 这些标志被传递给git am以轻松地改变重新发布的提交的日期。与--interactive选项不兼容。
    --signoff                                       # 这个标志被传递给git am签署所有重新提交的提交。与--interactive选项不兼容。
    -i, --interactive                               # 列出将要重新分配的提交列表。让用户在重新绑定之前编辑该列表
    -p, --preserve-merges                           # 重新创建合并提交，而不是通过重播合并提交引入的提交来平坦化历史
    -x <cmd>, --exec <cmd>                          # 在每行在最终历史记录中创建提交后附加“exec <cmd>”。<cmd>将被解释为一个或多个shell命令
    --root                                          # 重新规划从<branch>可访问的所有提交，而不是用<upstream>限制它们
    --autosquash, --no-autosquash                   # 当提交日志消息以“squash！...”（或“fixup！...”）开始时，并且在待办事项列表中已经有一个与之相匹配的提交时...，
                                                      会自动修改rebase -i的待办事项列表，以便被标记为压扁的提交在提交被修改后立即出现，并将被提交的提交的操作从（或）pick改为
    --autostash, --no-autostash                     # 在操作开始之前自动创建临时存储条目，并在操作结束后应用它
    --no-ff                                         # 与-interactive，cherry-pick所有基于rebased的提交，而不是快速转发到未更改的
```

#### 【revert】

```shell
语法：
    git revert [--[no-]edit] [-n] [-m parent-number] [-s] [-S[<keyid>]] <commit>…​
    git revert --continue
    git revert --quit
    git revert --abort

选项：
    <commit>…​                                    # 承诺恢复。有关拼写提交名称的更完整列表
    -e, --edit                                   # 使用这个选项，git revert可以让你在提交恢复之前编辑提交信息
    -m parent-number, --mainline parent-number   # 通常您无法恢复合并，因为您不知道合并的哪一方应被视为主线
    --no-edit                                    # 使用这个选项，git revert不会启动提交消息编辑器
    -n, --no-commit                              # 通常，该命令会自动创建一些提交日志消息，提交哪些提交已恢复
    -S[<keyid>], --gpg-sign[=<keyid>]            # GPG标志提交。该keyid参数是可选的，并且默认为提交者身份; 如果指定，它必须粘贴到选项没有空格。
    -s, --signoff                                # 在提交消息的末尾添加Signed-off-by行
    --strategy=<strategy>                        # 使用给定的合并策略
    -X<option>, --strategy-option=<option>       # 将合并策略特定选项传递给合并策略
    --continue                                   # 继续使用.git/sequencer中的信息进行操作
    --quit                                       # 忘记当前正在进行的操作。可用于在失败的cherry-pick或还原后清除排序器状态
    --abort                                      # 取消操作并返回到预序列状态
```

#### 【bisect】

```shell
语法：
    git bisect <subcommand> <options>
    git bisect start [--term-{old,good}=<term> --term-{new,bad}=<term>]
        [--no-checkout] [<bad> [<good>...]] [--] [<paths>...]
    git bisect (bad|new|<term-new>) [<rev>]
    git bisect (good|old|<term-old>) [<rev>...]
    git bisect terms [--term-good | --term-bad]
    git bisect skip [(<rev>|<range>)...]
    git bisect reset [<commit>]
    git bisect (visualize|view)
    git bisect replay <logfile>
    git bisect log
    git bisect run <cmd>...
    git bisect help

选项：
    --no-checkout                      # 在平分过程的每次迭代中，不要签出新的工作树
```

#### 【blame】

```shell
语法：
    git blame [-c] [-b] [-l] [--root] [-t] [-f] [-n] [-s] [-e] [-p] [-w] [--incremental]
            [-L <range>] [-S <revs-file>] [-M] [-C] [-C] [-C] [--since=<date>]
            [--progress] [--abbrev=<n>] [<rev> | --contents <file> | --reverse <rev>..<rev>]
            [--] <file>

选项：
    -b                                  # 显示边界提交的空白SHA-1。这也可以通过blame.blankboundary配置选项来控制
    --root                              # 不要将根提交视为边界。这也可以通过blame.showRoot配置选项来控制
    --show-stats                        # 在责备输出结尾包含更多统计数据
    -L <start>, <end>, -L :<funcname>   # 仅注释给定的线范围。可以多次指定。重叠范围是允许的
    -l                                  # 显示长时间（默认：关闭）
    -t                                  # 显示原始时间戳（默认值：关闭）
    -S <revs-file>                      # 使用revs-file中的修订版而不是调用git-rev-list [1]
    --reverse <rev>..<rev>              # 前进而不是后退。它不是显示一行出现的修订，而是显示一行存在的最后修订
    -p, --porcelain                     # 以设计用于机器消耗的格式显示
    --line-porcelain                    # 显示porcelain格式，但输出每行的提交信息，而不仅仅是第一次引用提交
    --incremental                       # 以设计用于机器消耗的格式逐步显示结果
    --encoding=<encoding>               # 指定用于输出作者姓名和提交摘要的编码。将其设置为none使责备输出未转换的数据
    --contents <file>                   # 当未指定<rev>时，该命令注释从工作树副本向后开始的更改
    --date <format>                     # 指定用于输出日期的格式
    --[no-]progress                     # 当连接到终端时，默认情况下标准错误流会报告进度状态
    -M[<num>]                           # 检测文件中移动或复制的行
    -C[<num>]                           # 除了-M检测从同一提交中修改的其他文件移动或复制的行之外
    -h                                  # 显示帮助信息
    -c                                  # 使用与git-annotate [1]相同的输出模式（默认值：关闭）
    --score-debug                       # 包含与文件之间的行移动有关的调试信息和文件中移动的行
    -f, --show-name                     # 在原始提交中显示文件名
    -n, --show-number                   # 在原始提交中显示行号（默认值：关闭）
    -s                                  # 从输出中抑制作者姓名和时间戳
    -e, --show-email                    # 显示作者电子邮件而不是作者姓名（默认：关闭）
    -w                                  # 在比较父版本和子版本时，忽略空白，并找出这些行来自哪里
    --abbrev=<n>                        # 使用默认的7 + 1十六进制数字作为缩写对象名称，而不是使用<n> +1个数字
```

#### 【grep】

```shell
语法：
    git grep [-a | --text] [-I] [--textconv] [-i | --ignore-case] [-w | --word-regexp]
           [-v | --invert-match] [-h|-H] [--full-name]
           [-E | --extended-regexp] [-G | --basic-regexp]
           [-P | --perl-regexp]
           [-F | --fixed-strings] [-n | --line-number]
           [-l | --files-with-matches] [-L | --files-without-match]
           [(-O | --open-files-in-pager) [<pager>]]
           [-z | --null]
           [-c | --count] [--all-match] [-q | --quiet]
           [--max-depth <depth>]
           [--color[=<when>] | --no-color]
           [--break] [--heading] [-p | --show-function]
           [-A <post-context>] [-B <pre-context>] [-C <context>]
           [-W | --function-context]
           [--threads <num>]
           [-f <file>] [-e] <pattern>
           [--and|--or|--not|(|)|-e <pattern>…​]
           [--recurse-submodules] [--parent-basename <basename>]
           [ [--[no-]exclude-standard] [--cached | --no-index | --untracked] | <tree>…​]
           [--] [<pathspec>…​]

选项：
    --cached                                     # 在平分过程的每次迭代中，不要签出新的工作树
    --no-index                                   # 搜索当前目录中不受Git管理的文件
    --untracked                                  # 除了在工作树中跟踪文件中搜索外，还可以在未跟踪文件中搜索
    --no-exclude-standard                        # 通过不尊重.gitignore 机制来搜索被忽略的文件。只用于--untracked
    --exclude-standard                           # 不要关注通过.gitignore 机制指定的忽略文件，仅在使用当前目录搜索文件时有用--no-index
    --recurse-submodules                         # 递归搜索已在存储库中初始化并检出的每个子模块
    -a, --text                                   # 像处理文本一样处理二进制文件
    --textconv                                   # 尊重textconv过滤器设置
    --no-textconv                                # 不要兑现textconv过滤器设置。这是默认设置
    -i, --ignore-case                            # 忽略模式和文件之间的大小写区别
    -I                                           # 不匹配二进制文件中的模式
    --max-depth <depth>                          # 对于命令行中给出的每个<pathspec>，最多下降<depth>级别的目录
    -w, --word-regexp                            # 仅在字边界处匹配模式
    -v, --invert-match                           # 选择不匹配的行
    -h, -H                                       # 默认情况下，该命令显示每个匹配的文件名
    --full-name                                  # 从子目录运行时，该命令通常会输出相对于当前目录的路径    
    -E, --extended-regexp, -G, --basic-regexp    # 对于模式使用POSIX扩展/基本正则表达式。默认是使用基本的正则表达式
    -P, --perl-regexp                            # 为模式使用Perl兼容的正则表达式
    -F, --fixed-strings                          # 使用固定字符串模式
    -n, --line-number                            # 在行号前加上匹配的行
    -l, --files-with-matches, --name-only, -L, --files-without-match    # 不显示每条匹配的行，只显示包含（或不包含）匹配的文件的名称
    -O[<pager>], --open-files-in-pager[=<pager>] # 打开寻呼机中的匹配文件（不是grep的输出）
    -z, --null                                   # 输出\ 0而不是通常跟在文件名后的字符    
    -c, --count                                  # 显示匹配的行数，而不是显示每条匹配的行
    --color[=<when>]                             # 显示彩色的比赛。该值必须始终（默认），永不，或自动
    --no-color                                   # 关闭匹配突出显示，即使配置文件将默认设置为彩色输出。和...一样--color=never
    --break                                      # 在不同文件的匹配之间打印空行
    --heading                                    # 在文件的上方显示文件名，而不是在每个显示的行的开头
    -p, --show-function                          # 显示包含匹配函数名称的上一行，除非匹配行是函数名称本身    
    -<num>, -C <num>, --context <num>            # 显示<num>前导和尾部线条，并放置包含--连续的匹配组之间的线条
    -A <num>, --after-context <num>              # 显示<num>尾随线，并--在连续的匹配组之间放置一行 
    -B <num>, --before-context <num>             # 显示<num>引出线，并--在相邻的匹配组之间放置一行 
    -W, --function-context                       # 显示前一行中包含函数名称的周围文本，直到下一个函数名称之前的文本，从而有效地显示找到匹配的整个函数
    --threads <num>                              # 要使用的grep工作线程数
    -f <file>                                    # 从<file>中读取模式，每行一个
    -e                                           # 下一个参数是模式
    --and, --or, --not, ( …​ )                    # 指定如何使用布尔表达式组合多个模式
    --all-match                                  # 将多个模式表达式结合使用时--or，会指定此标志以将匹配限制为具有与其匹配的所有行的文件
    -q, --quiet                                  # 不输出匹配的行
    <tree>…​                                      # 而不是在工作树中搜索跟踪文件，搜索给定树中的斑点
    --                                           # 表示选项结束; 其余的参数是<pathspec>限制器
    <pathspec>…​                                  # 如果给定，则将搜索限制为至少匹配一个模式的路径
```

##### 鸣谢博客

[Git_命令大全-Catnip - 博客园](https://www.cnblogs.com/Small-music/p/9075681.html#git)


[https://git-scm.com/docs](https://git-scm.com/docs)

[https://git-scm.com/book/zh](https://git-scm.com/book/zh)

[http://git.oschina.net/progit](http://git.oschina.net/progit/)

[http://gitbook.liuhui998.com/index.html](http://gitbook.liuhui998.com/index.html)

