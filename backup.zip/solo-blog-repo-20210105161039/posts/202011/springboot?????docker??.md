title: springboot项目部署到docker中去
date: '2020-11-02 20:29:08'
updated: '2020-11-02 20:29:08'
tags: [java]
permalink: /articles/2020/11/02/1604320148485.html
---
![](https://b3logfile.com/bing/20200919.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

第一步，将springboot打jar包
测试jar包可用 java -jar love-1.0.0.jar

第二步，在linux的docker环境中新建dockerfile文件
FROM java:8
VOLUME /tmp
ADD love-0.0.1-SNAPSHOT.jar /love.jar
ENTRYPOINT ["java","-Djava.security.egd=file:/dev/./urandom","-jar","/love.jar"]
将jar包拷贝到linux系统上。放在和docker同文件夹下

第三步，使用命令根据dockerfile创建镜像
docker build -f /usr/local/lovecaining/Dockerfile -t lovecaining .

docker run -d -p 8088:8088 --name lovecaining lovecaining

