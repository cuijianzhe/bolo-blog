title: Springboot的配置文件加载顺序及覆盖问题
date: '2020-10-10 17:37:26'
updated: '2022-03-30 15:58:53'
tags: [java]
permalink: /articles/2020/10/10/1602322646495.html
---
![](https://b3logfile.com/bing/20200120.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

SpringBoot启动会扫描以下位置的application.yml或者 application.properties文件作为SpringBoot的默认配置文件。

**-file:./config/**

**-file:./**

**-classpath:/config/**

**-classpath:/**

**即根目录下的config目录下，然后是 根目录下，然后是classpath路径下的config目录下，最后是classpath路径下。**

优先级由高到低，高优先级的配置会覆盖低优先级的配置。

eg.假如：根目录下的config目录下定义端口为8084，  根目录下定义端口为8083 ，classpath路径下的config目录定义端口为8082，classpath路径下定义端口为8081，最后启动，启动的端口为8084 **，高优先级会覆盖低优先级。**

***注意： 并不是高优先级的被加载了，低优先级的就不会再加载，实际上是SpringBoot会从这四个位置全部加载主配置文件，并且还能产生互相配置的效果。***

写在最后:

当同一个目录下同时存在properties和yml文件时，会优先加载properties文件里的内容，两个文件中的内容会进行互补操作，即SpringBoot会读取两份文件中的所有内容，会加载所有不同的配置项，汇成一个总的配置，如果同一个配置两个文件中都存在，那么properties中的配置会被加载，而忽略yml文件中的配置。

eg: 在springBoot的resources目录下同时存在application.properties和application.yml，并且文件内容分别如下:

具体完整的顺序参考Springboot官方链接。[传送门](https://docs.spring.io/spring-boot/docs/2.0.4.RELEASE/reference/htmlsingle/#boot-features-external-config)

