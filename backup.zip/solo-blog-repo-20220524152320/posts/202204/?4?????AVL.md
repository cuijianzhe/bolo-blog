title: 树(4)平衡二叉树AVL
date: '2022-04-08 14:38:55'
updated: '2022-04-08 14:46:13'
tags: [java]
permalink: /articles/2022/04/08/1649399935384.html
---
![](https://b3logfile.com/bing/20201130.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

在AVL树中，任一节点对应的两棵子树的最大高度差为1，因此它也被称为**高度平衡树**

例如图 2.1 不是平衡二叉树，因为结点 60 的左子树不是平衡二叉树。
![image20220406165447k5ki5o6.png](https://b3logfile.com/file/2022/04/image-20220406165447-k5ki5o6-77fed19b.png "2.1")

图 2.2 也不是平衡二叉树，因为虽然任何一个结点的左子树与右子树都是平衡二叉树，但高度之差已经超过 1 。
![image20220406165506s27lpqd.png](https://b3logfile.com/file/2022/04/image-20220406165506-s27lpqd-6cd66e18.png "2.2")


##### 平衡因子

**定义：** 某节点的左子树与右子树的高度(深度)差即为该节点的平衡因子（BF,Balance Factor），平衡二叉树中不存在平衡因子大于 1 的节点。在一棵平衡二叉树中，节点的平衡因子只能取 0 、1 或者 -1 ，分别对应着左右子树等高，左子树比较高，右子树比较高。
![image20220406165640d7m1zs5.png](https://b3logfile.com/file/2022/04/image-20220406165640-d7m1zs5-84b1efc5.png)

![image20220406165646rsc2w8a.png](https://b3logfile.com/file/2022/04/image-20220406165646-rsc2w8a-fd3c5df6.png)

![image20220406165650hxwyjik.png](https://b3logfile.com/file/2022/04/image-20220406165650-hxwyjik-d74952fd.png)



##### AVL树的四种插入节点方式

###### A的左孩子的左子树插入节点

![A的左孩子的左子树插入节点20220406165934omtx9r0.gif](https://b3logfile.com/file/2022/04/A的左孩子的左子树插入节点-20220406165934-omtx9r0-0b054d19.gif)



###### A的右孩子的右子树插入节点

![A的右孩子的右子树插入节点20220406170005oebiqjr.gif](https://b3logfile.com/file/2022/04/A的右孩子的右子树插入节点-20220406170005-oebiqjr-06385014.gif)

###### A的左孩子的右子树插入节点

若 A 的左孩子节点 B 的右子树 E 插入节点 F ，导致节点 A 失衡，如2.3图：
![image20220406170350h1necga.png](https://b3logfile.com/file/2022/04/image-20220406170350-h1necga-5cbdd8ed.png "2.3")
先左旋再右旋
![image202204061703173kbzwdo.png](https://b3logfile.com/file/2022/04/image-20220406170317-3kbzwdo-be37dfc6.png)
![image202204061703208guq3j9.png](https://b3logfile.com/file/2022/04/image-20220406170320-8guq3j9-ac9b4c81.png)



###### A的右孩子的左子树插入节点

如图2.4所示
![image20220406170441e9iz9ms.png](https://b3logfile.com/file/2022/04/image-20220406170441-e9iz9ms-0f2f307d.png "2.4")

先右旋再左旋
![image20220406170516voohsxo.png](https://b3logfile.com/file/2022/04/image-20220406170516-voohsxo-7df5160a.png)
![image20220406170520it98wja.png](https://b3logfile.com/file/2022/04/image-20220406170520-it98wja-2ecff16d.png)



##### AVL树的四种删除节点方式

跟二叉搜索树的删除方式一样，也分为四种情况

（1）删除叶子节点 （2）删除的节点只有左子树 （3）删除的节点只有右子树 （4）删除的节点既有左子树又有右子树

在上篇文章有写，这里不再赘述

