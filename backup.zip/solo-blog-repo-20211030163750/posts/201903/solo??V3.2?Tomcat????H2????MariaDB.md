title: solo博客V3.2在Tomcat部署+更改H2数据库为MariaDB
date: '2019-03-05 19:01:17'
updated: '2019-03-15 18:55:57'
tags: [博客搭建]
permalink: /articles/2019/03/05/1551783677422.html
---
![](https://img.hacpai.com/bing/20171127.jpg?imageView2/1/w/960/h/540/interlace/1/q/10) 




先大致说一下部署的环境吧，坑不多，但嗯呣呣是痛点。
## 部署环境介绍
#### **阿里云2折服务器**

![](https://img.hacpai.com/file/2019/03/aliyunCentos7-87b4045f.png?imageView2/1/w/960/h/540/interlace/1/q/10)


当时是1004，马云好像又亏了￥86呢，买的越多马云亏的越多抓紧买啊。哦，对了，买了之后才知道原来这是活动中的积分服务器，什么意思呢？就是CPU高于临界值消耗积分，积分用完，系统崩盘，CPU低于临界值，增加积分，积分充裕则满血复活。太棒了不是吗？

#### **MariaDB5.5**

```bash
[root@blog_server ~]# mysql --version 
mysql  Ver 15.1 Distrib 5.5.60-MariaDB, for Linux (x86_64) using readline 5.1
```

原以为数据库连接工具类必须使用`com.mysql.jdbc.Driver`,没想到`com.mysql.cj.jdbc.Driver`也可以正常使用。

#### **TOMCAT** 8.5.38.0
真是不用不知道，原来windows上的tomcat和linux的tomcat不是一个妈生的，我为啥知道？

1. 你比如在windows上可以将webapps下的ROOT目录直接删掉，然后将war包重命名为ROOT.war后启动tomcat即可。但是这些在linux上行不通，记得以前的linux是支持的，莫不是tomcat的linux发行版做了暗改？
2. linux版本tomcat启动的时候，竟然会再次解压war包文件，导致之前解压的内容被覆盖，这一点我记得在2018年还不是这样子的，变化之大令人咂舌。

## 更改数据库配置
起初用war包默认的local.properties文件，只是更改了ip和用户名密码，发现登陆博客的时候，会卡死在登陆的地方，原因不明。日志无错误记录。
后来我在windows上的tomcat运行项目，发现运行中原来有提示信息不过日志没记录下来，提示没有可用连接，于是我考虑到可能是购买的阿里云积分服务器的原因，所以我从新定义了一下数据库的最大连接和最小连接数，以及等待时间和是否回收超时连接，问题终于得到了解决。三克斯嘎的
```
jdbc.minConncnt=2
jdbc.maxConncnt=4
jdbc.maxWait=1000
jdbc.removeAbandoned=false
```

项目运行起来了，主题+界面+小姐姐真漂亮，但是糟心的是文件上传地址并不是服务器本地，只能有一个管理员账户（好像是），写文章竟然不能粘贴这一点也是比较坑的。好就这么多，期待新版本的solo，真香