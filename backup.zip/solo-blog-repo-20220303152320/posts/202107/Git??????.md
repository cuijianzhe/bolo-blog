title: Git操作指令收集
date: '2021-07-23 22:49:41'
updated: '2021-08-11 21:44:00'
tags: [git]
permalink: /articles/2021/07/23/1627051781843.html
---
![](https://b3logfile.com/bing/20200203.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

##### 查看git安装位置

`where git`

---

##### 查看git版本

`git version`

---

##### 检查 Git 的某一项配置

`git config user.name`

---

##### 查看所有配置以及他们所在的文件

`git config --list --show-origin`

---

##### 由于 Git 会从多个文件中读取同一配置变量的不同值，因此你可能会在其中看到意料之外的值而不知道为什么。 此时，你可以查询 Git 中该变量的 原始 值，它会告诉你哪一个配置文件最后设置了该值：

`git config --show-origin user.name`

---

##### 设置用户名和邮件地址

`git config --global user.name "John Doe" `
`git config --global user.email johndoe@example.com`

---

##### 配置git的默认编辑器为NotePad++

`git config --global core.editor "'C:/Program Files (x86)/Notepad++/notepad++.exe' -multiInst -notabbar -nosession -noPlugin"`

---

##### 获取完整git命令帮助

`git config --help 或 git help config 或 git config -h`

---

##### 克隆仓库

`git clone https://github.com/libgit2/libgit2`

---

##### 检查当前文件状态

`git status 或 git status --short`

---

##### 跟踪新文件

`git add <file>`

---

##### git提交

`git commit -o <file1> <file2> -m '提交特定两个文件'`
`git commit -a -m '提交所有文件'`

---

##### 忽略文件

`创建gitignore.txt`
`ren gitignore.txt .gitignore`
`忽略所有的 .a 文件 *.a `
`但跟踪所有的 lib.a，即便你在前面忽略了 .a 文件 !lib.a`
`只忽略当前目录下的 TODO 文件，而不忽略 subdir/TODO /TODO`
`忽略任何目录下名为 build 的文件夹 build/`
`忽略 doc/notes.txt，但不忽略 doc/server/arch.txt  doc/*.txt`
`忽略 doc/ 目录及其所有子目录下的 .pdf 文件 doc/**/*.pdf`

---

##### 比较文件

`git diff 只显示尚未暂存的改动`
`git diff --staged 或 git diff --cached 比对已暂存文件与最后一次提交的文件差异`

---

##### 提交文件

`git commit -a -m '注释'`
`git commit --amend 有时候我们提交完了才发现漏掉了几个文件没有添加，或者提交信息写错了。 此时，可以运行带有 --amend 选项的提交命令来重新提交`

---

##### 删除文件

`git rm --cached README 从暂存区删除文件，但仍在工作目录中`
`git rm log/\*.log 此命令删除 log/ 目录下扩展名为 .log 的所有文件`

---

##### 移动文件

`git mv from.txt to.txt`
`运行 git mv 就相当于运行了下面三条命令 mv README.md README git rm README.md git add README`

---

##### 查看提交历史

`git log 显示所有提交记录`
`git log -p -2  显示最近两次提交，并显示提交的补丁差异`
`git log --stat 查看简短版的提交差异`
`git log --pretty=oneline 美化显示日志，一次提交放在一行`
`git log --pretty=format:"%h - %an, %ar : %s" 按指定格式输出日志`
`git log --pretty=format:"%h %s" --graph 这个选项添加了一些 ASCII 字符串来形象地展示你的分支、合并历史`
`git log --since=2.weeks 打印近两周的日志，可以是类似 "2008-01-15" 的具体的某一天，也可以是类似 "2 years 1 day 3 minutes ago" 的相对日期。`
`还可以过滤出匹配指定条件的提交。 用 --author 选项显示指定作者的提交，用 --grep 选项搜索提交说明中的关键字。`
`git log -S function_name 根据修改内容查找日志`
`git log --pretty="%h - %s" --author='Junio C Hamano' --since="2008-10-01" \ --before="2008-11-01" --no-merges -- t/ --no-merges不显示合并的提交记录`

---

##### 撤销提交

`git reset HEAD CONTRIBUTING.md 取消暂存的文件，但不会撤消对文件的修改`
`git checkout -- CONTRIBUTING.md 撤消对文件的修改,还原到最近提交的版本`

---

##### 打标签

`git tag 查看所有标签`
`git tag -a v1.4 -m "my version 1.4" 如果只写了git tag -a v1.4 则会调用你配置的默认编辑器去输入附注`
`git show v1.4 显示标签信息`
`git tag v1.4-lw 创建轻量标签，不需要输入附注信息`
`git log --pretty=oneline`
`git tag -a v1.2 9fceb02 后期打标签`
`git tag -d v1.2 删除标签`
`git push origin --delete <tagname> 删除远程标签`
`git checkout v1.1 根据标签检出代码`

---

##### 设置别名

`git config --global alias.ci commit 当要输入 git commit 时，只需要输入 git ci`

---

##### 分支创建

`git branch testing `

---

##### 查看各个分支的指针所指的对象

`git log --oneline --decorate `

---

##### 切换分支

`git checkout testing`

---

##### 创建新分支的同时切换过去

`git checkout -b <newbranchname> `

---

##### 合并分支

`git merge hotfix`

---

##### 删除分支

`git branch -d hotfix`

---

##### 强制删除分支，并丢掉那些工作

`git branch -D hotfix`

---

##### 遇到冲突时的分支合并

`git merge testing`
`git status`
`git commit -a -m '修改冲突后提交'`

---

##### 管理分支

`git branch 获取分支列表`

---

##### 查看每一个分支的最后一次提交

`git branch -v`

---

##### 查看哪些分支已经合并到当前分支

`git branch --merged`

---

##### 查看哪些分支没有合并到当前分支

`git branch --no-merged`

---

##### git变基

`git checkout experiment`
`git rebase master`
`检出 experiment 分支，然后将它变基到 master 分支上 它的原理是首先找到这两个分支（即当前分支 experiment、变基操作的目标基底分支 master） 的最近共同祖先 C2， 然后对比当前分支相对于该祖先的历次提交，提取相应的修改并存为临时文件， 然后将当前分支指向目标基底 C3, 最后以此将之前另存为临时文件的修改依序应用。 变基与merge达到的效果一样，但变基是将一系列提交按照原有次序依次应用到另一分支上，而合并是把最终结果合在一起。`

---

##### 交互式暂存与取消暂存文件

`git add -i`

---

##### 贮藏与清理

`有时，当你在项目的一部分上已经工作一段时间后，所有东西都进入了混乱的状态，  而这时你想要切换到另一个分支做一点别的事情。 问题是，你不想仅仅因为过会儿回到这一点而为做了一半的工作创建一次提交。  针对这个问题的答案是 git stash 命令。`

---

##### 查看贮藏列表

`git stash list`

---

##### 应用最近的一次贮藏

`git stash apply`

---

##### 应用某一个版本的贮藏

`git stash apply stash@{2}`

---

##### 移除贮藏

`git stash drop stash@{0}`

---

##### 贮藏的同时还保持文件为已改动状态

`git stash --keep-index`

---

##### 同时贮藏未跟踪文件

`git stash --include-untracked`

---

##### 同时贮藏忽略文件

`git stash -all`

---

##### 根据贮藏创建一个分支

`git stash branch <new branchname> `

---

##### 强制移除工作目录中所有未追踪的文件以及空的子目录

`git clean -f -d -n (-f强制，-d删除，-n输出内容)`

---

##### 交互式移除

`git clean -x -i (-x移除未跟踪忽略的文件，-i交互)`

---

##### 重写历史

`git commit --amend 修改最近的一次提交`

---

##### 交互式变基

`git rebase -i HEAD~3 列出之前三次提交让你更改，可以修改/删除/压缩/拆分提交，`

---

##### 核武器级选项

`git filter-branch --tree-filter 'rm -f passwords.txt' HEAD 全局修改你的邮箱地址或从每一个提交中移除一个文件`

```shell
全局修改邮箱地址，可以修改之前提交记录里的邮箱地址
git filter-branch --commit-filter '
        if [ "$GIT_AUTHOR_EMAIL" = "schacon@localhost" ];
        then
                GIT_AUTHOR_NAME="Scott Chacon";
                GIT_AUTHOR_EMAIL="schacon@example.com";
                git commit-tree "$@";
        else
                git commit-tree "$@";
        fi' HEAD
```

---

##### 回到上一次提交的状态

`git reset --hard HEAD`

---

##### 设置提交时的默认注释信息

`git config --global commit.template ~/.gitmessage.txt`

---

##### 查看分支branch_A的创建者信息

`git for-each-ref --format='%(committerdate) %09 %(authorname) %09 %(refname)' | sort -k5n -k2M -k3n -k4n|grep branch_A`

---

##### 查看分支创建时间

`git reflog show --date=iso master`

---

##### 查看已合并到当前分支的分支

`git branch --merged`

---

##### 查看未合并到当前分支的分支

`git branch --no-merged`

---



###### 参考网址

[https://git-scm.com/book/zh/v2](https://git-scm.com/book/zh/v2)

---

###### git聊天室（外国友人）

[https://freenode.net](https://freenode.net)

