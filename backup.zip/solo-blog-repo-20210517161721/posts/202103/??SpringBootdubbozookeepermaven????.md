title: 搭建SpringBoot+dubbo+zookeeper+maven框架(转载)
date: '2021-03-09 17:42:36'
updated: '2021-03-09 18:17:59'
tags: [java]
permalink: /articles/2021/03/09/1615282956766.html
---
![](https://b3logfile.com/bing/20190924.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

### zookeeper下载&启动

1. 下载[zookeeper-3.5.9](https://xyt.cjzshilong.cn/apache-zookeeper-3.5.9-bin.tar.gz)
2. 重命名/conf/下的`zoo-sample.cfg`为`zoo.cfg`
3. 编辑zoo.cfg内容,增加两行内容
   `dataDir=D:\DevelopmentSoftware\apache-zookeeper-3.5.9-bin\data`
   `dataLogDir=D:\DevelopmentSoftware\apache-zookeeper-3.5.9-bin\log`
4. 在与bin目录同级文件夹即主目录下创建data和log文件夹
5. 点击bin中的zkServer.cmd运行启动
6. 运行成功会出现`Started AdminServer on address 0.0.0.0, port 8080`和`binding to port 0.0.0.0/0.0.0.0:2181`,从结果可以看出,zookeeper默认占用8080端口和2181端口

### dubbo下载&运行

1. 下载[dubbo-2.5.10](https://xyt.cjzshilong.cn/dubbo-2.5.x.zip)
2. 解压并进入dubbo-admin文件夹,cmd运行`mvn package -Dmaven.test.skip=true`,将此运维监控项目打成war包
3. 将war包拷贝进入[tomcat8.5.63](https://xyt.cjzshilong.cn/apache-tomcat-8.5.63-windows-x64.zip)并运行(在此之前必须先启动zookeeper),tomcat端口不能为默认的8080
4. 访问`http://localhost:8081/dubbo-admin-2.5.10/`,用户为root/root
5. 出现如下界面就算运行成功![dubbo.png](https://b3logfile.com/file/2021/03/dubbo-de8dcff7.png)

#### 启动生产者服务&消费者服务

1. 下载源码[springbootmybatisdubbozookeeper.rar](https://xyt.cjzshilong.cn/springboot-mybatis-dubbo-zookeeper.rar)
2. 启动provider子服务
3. 再启动customer子服务
4. 刷新dubbo-admin,查看会发现服务数+1

