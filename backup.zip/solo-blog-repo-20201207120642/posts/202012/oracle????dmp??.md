title: oracle导入导出dmp文件
date: '2020-12-02 16:27:09'
updated: '2020-12-02 16:32:40'
tags: [oracle]
permalink: /articles/2020/12/02/1606897629822.html
---
![](https://b3logfile.com/bing/20180404.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

#### 导入dmp

//fromuser是dmp文件里的源用户 touser是要更新的用户

`imp targetuser/password@orcl file=C:\test.dmp fromuser=sourceuser touser=targetuser`

#### 导出dmp

`exp username/password@orcl file=test.dmp`

#### 也可以使用PL/SQL来进行导出

##### 选择导出用户

![image.png](https://b3logfile.com/file/2020/12/image-aec6a7a2.png)

##### 选择需要导出的表

![image.png](https://b3logfile.com/file/2020/12/image-ae60fd09.png)



