title: redis查询key
date: '2021-04-03 12:47:39'
updated: '2021-04-03 12:48:03'
tags: [redis]
permalink: /articles/2021/04/03/1617425259423.html
---
* 查询所有的keys
  `keys teacher_sso_username*`
* 查询key的TTL
  `ttl teacher_sso_username:13444444416`
* 批量修改key的TTL时间
  编写脚本expireAll.sh
  `redis-cli -h 127.0.0.1 -p 6379 -a Cg44uwsgsgsg1 expire $1 1296000`
  执行命令
  `redis-cli -h 127.0.0.1 -p 6379 -a Cg44uwsgsgsg1 keys "support_sso_userinfo*" | xargs -I {} ./expireAll.sh {} `

