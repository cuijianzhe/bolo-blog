title: Spring的30个关键类
date: '2022-01-20 17:48:21'
updated: '2022-01-20 17:48:21'
tags: [java]
permalink: /articles/2022/01/20/1642672101433.html
---
![](https://b3logfile.com/bing/20210213.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

```
D:.
│  pom.xml    
└─src
    └─main
        ├─java
        │  └─com
        │      └─gupaoedu
        │          └─vip  
        │              └─spring
        │                  └─framework
        │                      ├─annotation
        │                      │      GPAutowired.java
        │                      │      GPController.java
        │                      │      GPRequestMapping.java
        │                      │      GPRequestParam.java
        │                      │      GPService.java
        │                      │      
        │                      ├─aop
        │                      │  │  GPAopProxy.java #Aop顶层接口
        │                      │  │  GPCglibAopPorxy.java #CglibAop实现类
        │                      │  │  GPDefaultAopProxyFactory.java #策略选择Cglib还是Jdk
        │                      │  │  GPJdkDynamicAopProxy.java #JdkAop实现类
        │                      │  │  
        │                      │  ├─aspect
        │                      │  │      GPAbstractAspectJAdvice.java #切面通知的抽象父类
        │                      │  │      GPAdvice.java #通知接口
        │                      │  │      GPAfterReturningAdviceInterceptor.java #后切面通知拦截器
        │                      │  │      GPAspectJAfterThrowingAdvice.java #异常通知拦截器
        │                      │  │      GPJoinPoint.java #本次操作的方法的元信息接口
        │                      │  │      GPMethodBeforeAdviceInterceptor.java #前切面通知拦截器
        │                      │  │      
        │                      │  ├─config
        │                      │  │      GPAopConfig.java #切面信息类，根据切点用于判断需不需要代理bean
        │                      │  │      
        │                      │  ├─intercept
        │                      │  │      GPMethodInterceptor.java #切面拦截器接口
        │                      │  │      GPMethodInvocation.java #包含拦截器链，负责按顺序执行所有的切面
        │                      │  │      
        │                      │  └─support
        │                      │          GPAdvisedSupport.java #解析AOP配置的工具类
        │                      │          
        │                      ├─beans
        │                      │  │  GPBeanWrapper.java #封装Bean对象，此处的bean是代理后的bean
        │                      │  │  
        │                      │  ├─config
        │                      │  │      GPBeanDefinition.java #bean的一些原生信息，包含beanName和bean的原生类名，和是否懒加载等属性
        │                      │  │      
        │                      │  └─support
        │                      │          GPBeanDefinitionReader.java #保存用户配置好的配置文件,扫描指定包名下的类
        │                      │          GPDefaultListableBeanFactory.java #注册bean，放入ioc容器
        │                      │          
        │                      ├─context
        │                      │      GPApplicationContext.java #加载配置文件，ioc，di，getBean
        │                      │      
        │                      ├─core
        │                      │      GPBeanFactory.java #工厂接口
        │                      │      
        │                      └─webmvc
        │                          └─servlet
        │                                  GPDispatcherServlet.java #容器初始化，doGet，doPost
        │                                  GPHandlerAdapter.java #将request中的形参反射到要执行的方法中的形参中
        │                                  GPHandlerMapping.java #把url和Method做一个映射
        │                                  GPModelAndView.java #页面和数据
        │                                  GPView.java #通过正则将特殊格式的字符替换为model中的对应名字的变量值，再渲染进response
        │                                  GPViewResolver.java #解析对应的模板，比如自动将controller中的返回值后缀加上.html，并且找到对应的html文件
 

```

