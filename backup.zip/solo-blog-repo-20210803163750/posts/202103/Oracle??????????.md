title: Oracle将远程库复制到本地库
date: '2021-03-17 14:56:03'
updated: '2021-03-17 14:56:03'
tags: [oracle]
permalink: /articles/2021/03/17/1615964163396.html
---
![](https://b3logfile.com/bing/20200316.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

#### 1.将远程地址某用户下的数据库导出一份dmp文件

`exp username/password@192.168.1.1:1521/orcl file=C:/database.dmp`

#### 2.查询表空间的物理地址路径

```sql
select
tablespace_name, 
	file_id, file_name, 
	round(bytes/(1024*1024),0) total_space 
from 
	dba_data_files 
order by tablespace_name;
```

#### 3.如果发现要导入的表空间和用户在之前存在,先删除之前的,一般来说用户和表空间名称一样

`drop user user_name cascade;`

`drop tablespace tablespace_name including contents and datafiles cascade constraint;`

#### 4.创建数据表空间

```sql
create tablespace tablespace_name

logging  
 
datafile 'C:\oracle\product\10.2.0\oradata\orcl\tablespace_name.dbf' 
 
size 200m  
 
autoextend on  
 
next 200m maxsize 30480m  
 
extent management local;
```

#### 5.创建用户并指定表空间

`create user username_here identified by password_here default tablespace tablespace_here;`

#### 6.给用户授予权限

`grant connect,resource,dba to username_here;`

#### 7.导入dmp到数据库

`//imp 用户名密码ip端口服务名 要导入的dmp文件地址 fromuser是源dmp文件里的用户 touser是要更新的用户`
`imp username/password@orcl file=C:/database.dmp fromuser=fromusername touser=tousername`

