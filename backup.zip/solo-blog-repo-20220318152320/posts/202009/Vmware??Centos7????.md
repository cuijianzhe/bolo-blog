title: Vmware里的Centos7连接外网
date: '2020-09-02 11:08:56'
updated: '2020-09-02 11:50:02'
tags: [Linux]
permalink: /articles/2020/09/02/1599016136565.html
---
![](https://b3logfile.com/bing/20180601.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

1. 选择网络适配器NET模式。
2. 将ONBOOT=no 改为 ONBOOT=yes,即 vi  /etc/sysconfig/network-scripts/ifcfg-ens55(文件名可能不同，找到相似的文件，打开)
3. service network restart (重启网卡)
4. 联网成功
5. 安装sudo yum install net-tools (用来执行常用命令)，

