title: Junit4单元测试web接口和service方法
date: '2021-12-17 16:15:39'
updated: '2021-12-17 16:15:39'
tags: [java]
permalink: /articles/2021/12/17/1639728939461.html
---
![](https://b3logfile.com/bing/20191005.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

###### 引入junit包依赖

```xml
<!-- https://mvnrepository.com/artifact/junit/junit -->
        <dependency>
            <groupId>junit</groupId>
            <artifactId>junit</artifactId>
            <version>4.13.2</version>
            <scope>test</scope>
        </dependency>
```

###### 直接贴代码不bb

`测试接口的代码`

```java
package com.example.merrychristmas.web;

import com.example.merrychristmas.controller.IndexController;
import com.example.merrychristmas.entity.User;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

@RunWith(SpringRunner.class)
@SpringBootTest
public class IndexControllerTest {

    @Autowired
    protected WebApplicationContext wac;

    private MockMvc mockMvc;
    @Autowired
    private IndexController indexController;

    @Before
    public void setUp() {
        this.mockMvc = MockMvcBuilders.webAppContextSetup(this.wac).build();
    }

    @Test
    public void login() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.post("/index/login").accept(MediaType.ALL)
                        .param("userName", "xuyt")
                        .param("password", "123456")).
                andExpect(MockMvcResultMatchers.handler().handlerType(IndexController.class)).
                andExpect(MockMvcResultMatchers.handler().methodName("login")).
                andReturn();
    }

    //传json对象的方式
    @Test
    public void login2() throws Exception {
        User user = new User();
        final String jsonString = user.toString();

        mockMvc.perform(MockMvcRequestBuilders.post("/index/login").accept(MediaType.ALL).contentType(MediaType.APPLICATION_JSON_VALUE)
                        .content(jsonString)).
                andExpect(MockMvcResultMatchers.handler().handlerType(IndexController.class)).
                andExpect(MockMvcResultMatchers.handler().methodName("login")).
                andReturn();
    }
}
```

`测试service的代码`

```java
package com.example.merrychristmas.service;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class IndexServiceTest {

    @Autowired
    private UserService userService;

    @Test
    public void selectUser() {
        userService.selectUser("xuyt", "123456");
    }
}
```



