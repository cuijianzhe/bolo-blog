title: 【福利】python3爬取妹子图
date: '2019-08-20 19:50:38'
updated: '2020-08-24 14:17:13'
tags: [Python]
permalink: /articles/2019/08/20/1566301838555.html
---
![image.png](https://img.hacpai.com/file/2019/09/image-7c3952c9.png)

妹子图官方网址：[https://www.mzitu.com/](https://www.mzitu.com/)

刚接触到BeautifulSoup，所以拿来试下效果，起伏跌宕出来效果。
具体思路？官网首页链接-->获取分页面链接-->通过分页面获取图片链接
看下步骤：

# 一、分析下页面

## 1.1 先确保访问正常：

头部信息：

```python
url = "https://www.mzitu.com"  
headers = {  
 'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36',  
 "Referer": "https://www.mzitu.com/101553"  
}
```

```python
def load_page(url):
    try:
        res = requests.get(url,headers=headers)
        if res.status_code == 200:
            print('页面请求完毕')
            return res.text
    except:
        print('网络访问错误')
```

## 1.2 把当前页面所有page的url相关信息抓取出来

![image.png](https://img.hacpai.com/file/2019/08/image-03f6cd33.png)

把如上页面可以抓取到当前页面所有女神合集page。

```python
def get_page(url):
    html = requests.get(url,headers=headers)
    soup = BeautifulSoup(html.text,'lxml')
    #获取首页所有妹子页面
    all_url = soup.find("ul",{"id":"pins"}).find_all("a")
    # print(all_url)
```

## 1.3 获取详细页面url

```python
count = 1
    for href in all_url:
        count=count+1
        # print(href)
        if count %2 != 0:
            href1 = href['href']  #查找匹配出分页面中的page链接
```

因为通过for循环得到的href链接是一样的，所以只取一个：取奇偶
![image.png](https://img.hacpai.com/file/2019/08/image-6bc86c60.png)

结果如下：
![image.png](https://img.hacpai.com/file/2019/08/image-b8e5c04b.png)

## 1.4 得到页面链接后，即可抓页面下图片的url。创建目录

```python
for href2 in href:
                res2 = requests.get(href1,headers=headers)
                soup2 = BeautifulSoup(res2.text,'lxml')
                # pict_url = soup2.find("div",{"class":"main-image"}).find("img")['src']  #图片链接
                # print(pict_url)
                next_pic = soup2.find_all("span")[9]
                max_url = next_pic.get_text()
                # print(max_url)
                name = soup2.find("div",{"class":"main-image"}).find("img")['alt'] #分页面名称
                os.mkdir(name)
                os.chdir(name)
```

通过如下图的当前page中图片最后一张对应的span标签为第9个。
![image.png](https://img.hacpai.com/file/2019/08/image-bec90c6e.png)

## 1.5 下载图片

标题获取：
![image.png](https://img.hacpai.com/file/2019/08/image-f8d58b4d.png)
**图片的对应链接如下：**
![image.png](https://img.hacpai.com/file/2019/08/image-27479ca1.png)
**图片链接获取如：**
![image.png](https://img.hacpai.com/file/2019/08/image-ee7fd602.png)

```python
for i in range(1,int(max_url)+1):
                    next_url = href1+'/'+str(i)
                    res3 = requests.get(next_url,headers=headers)
                    soup3 = BeautifulSoup(res3.text,'lxml')
                    pic_address = soup3.find("div",{"class":"main-image"}).find('img')['src']
                    title = soup3.find('h2')
                    name1 = title.get_text()
                    img = requests.get(pic_address,headers=headers)
                    with open(name1+'.jpg','wb') as f:
                        f.write(img.content)
```

大功告成：
![image.png](https://img.hacpai.com/file/2019/08/image-4ce177cd.png)

# 完整代码：

```python
#!/usr/bin/python3
# -*- coding: utf-8 -*-
# @Time  : 2019/8/20 15:39
# @Author : cuijianzhe
# @File  : meizitu.py
# @Software: PyCharm
import requests
from bs4 import BeautifulSoup
from fake_useragent import UserAgent
import time
import os

url = "https://www.mzitu.com"
headers = {
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36',
    "Referer": "https://www.mzitu.com/101553"
}
def load_page(url):
    try:
        res = requests.get(url,headers=headers)
        if res.status_code == 200:
            print('页面请求完毕')
            return res.text
    except:
        print('网络访问错误')
#获取整个页面
def get_page(url):
    html = requests.get(url,headers=headers)
    soup = BeautifulSoup(html.text,'lxml')
    #获取首页所有妹子页面
    all_url = soup.find("ul",{"id":"pins"}).find_all("a")
    # print(all_url)
    count = 1
    for href in all_url:
        count=count+1
        # print(href)
        if count %2 != 0:
            href1 = href['href']  #查找匹配出分页面中的page链接
            # print(href1)
            for href2 in href:
                res2 = requests.get(href1,headers=headers)
                soup2 = BeautifulSoup(res2.text,'lxml')
                # pict_url = soup2.find("div",{"class":"main-image"}).find("img")['src']  #图片链接
                # print(pict_url)
                next_pic = soup2.find_all("span")[9]
                max_url = next_pic.get_text()
                name = soup2.find("div",{"class":"main-image"}).find("img")['alt']
                os.mkdir(name) #第一张图名称作为目录
                os.chdir(name)
                for i in range(1,int(max_url)+1):
                    next_url = href1+'/'+str(i)
                    res3 = requests.get(next_url,headers=headers)
                    soup3 = BeautifulSoup(res3.text,'lxml')
                    pic_address = soup3.find("div",{"class":"main-image"}).find('img')['src']
                    title = soup3.find('h2')
                    name1 = title.get_text()
                    img = requests.get(pic_address,headers=headers)
                    with open(name1+'.jpg','wb') as f:
                        f.write(img.content)

if __name__ == '__main__':
    load_page(url)
    get_page(url)
```

参考文档：
[BeautifulSoup中文文档](https://beautifulsoup.readthedocs.io/zh_CN/v4.4.0/)
[Requests文档](http://2.python-requests.org/zh_CN/latest/user/quickstart.html)

