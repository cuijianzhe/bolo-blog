title: Springboot通过Util类加载指定配置文件
date: '2020-10-10 17:46:15'
updated: '2020-10-10 17:49:13'
tags: [java]
permalink: /articles/2020/10/10/1602323175442.html
---
![](https://b3logfile.com/bing/20190816.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

### 创建 PropertiesUtil.java工具类

```
import com.alibaba.fastjson.util.IOUtils;
import org.apache.commons.lang.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.config.YamlPropertiesFactoryBean;
import org.springframework.core.io.Resource;

import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Properties工具类， 可载入多个properties、yml文件， 相同的属性在最后载入的文件中的值将会覆盖之前的值，
 * 取不到从System.getProperty()获取。
 *
 */
public class PropertiesUtils {

    /**
     * 默认加载的文件，可通过继承覆盖（若有相同Key，优先加载后面的）
     */
    public static final String[] DEFAULT_CONFIG_FILE = new String[]{
            "file:config/project1.yml",
            "file:config/project2.yml",
            "file:config/project3.yml",
            "file:config/project4.yml",
            "file:config/project5.yml"
    };

    private static Logger logger = LoggerFactory.getLogger(PropertiesUtils.class);

    /**
     * 正则表达式预编译
     */
    private static Pattern p1 = Pattern.compile("\\$\\{.*?\\}");
    private final Properties properties = new Properties();

    /**
     * 载入多个文件，路径使用Spring Resource格式，相同的属性在最后载入的文件中的值将会覆盖之前的值。
     */
    public PropertiesUtils(String... configFiles) {
        for (String location : configFiles) {
            try {
                Resource resource = ResourceUtils.getResource(location);
                if (resource.exists()) {
                    String ext = FileUtil.getFileExtension(location);
                    if ("properties".equals(ext)) {
                        InputStreamReader is = null;
                        try {
                            is = new InputStreamReader(resource.getInputStream(), "UTF-8");
                            properties.load(is);
                        } catch (IOException ex) {
                            logger.error("Load " + location + " failure. ", ex);
                        } finally {
                            IOUtils.close(is);
                        }
                    } else if ("yml".equals(ext)) {
                        YamlPropertiesFactoryBean bean = new YamlPropertiesFactoryBean();
                        bean.setResources(resource);
                        for (Map.Entry<Object, Object> entry : bean.getObject().entrySet()) {
                            properties.put(ObjectUtils.toString(entry.getKey()),
                                    ObjectUtils.toString(entry.getValue()));
                        }
                    }
                }
            } catch (Exception e) {
                logger.error("Load " + location + " failure. ", e);
            }
        }
    }

    /**
     * 当前类实例
     */
    public static PropertiesUtils getInstance() {
        return PropertiesLoaderHolder.INSTANCE;
    }

    /**
     * 重新加载实例（重新实例化，以重新加载属性文件数据）
     */
    public static void releadInstance() {
        PropertiesLoaderHolder.releadInstance();
    }

    /**
     * 获取当前加载的属性
     */
    public Properties getProperties() {
        return properties;
    }

    /**
     * 获取属性值，取不到从System.getProperty()获取，都取不到返回null
     */
    public String getProperty(String key) {
        String value = properties.getProperty(key);
        if (value != null) {
            // 支持嵌套取值的问题 key=${xx}/yy
            Matcher m = p1.matcher(value);
            while (m.find()) {
                String g = m.group();
                String keyChild = g.replaceAll("\\$\\{", "").replaceAll("\\}", "");
                value = value.replace(g, getProperty(keyChild));
            }
            return value;
        } else {
            String systemProperty = System.getProperty(key);
            if (systemProperty != null) {
                return systemProperty;
            }
        }
        return null;
    }

    /**
     * 取出String类型的Property，但以System的Property优先，如果都为null则返回defaultValue值
     */
    public String getProperty(String key, String defaultValue) {
        String value = getProperty(key);
        return value != null ? value : defaultValue;
    }

    /**
     * 当前类的实例持有者（静态内部类，延迟加载，懒汉式，线程安全的单例模式）
     */
    private static final class PropertiesLoaderHolder {
        private static PropertiesUtils INSTANCE;

        static {
            releadInstance();
        }

        public static void releadInstance() {
            Set<String> configFiles = SetUtils.newLinkedHashSet();
            for (String configFile : DEFAULT_CONFIG_FILE) {
                configFiles.add(configFile);
            }
            String customConfig = System.getProperty("spring.config.location");
            if (StringUtils.isNotBlank(customConfig)) {
                if (!customConfig.contains("$")) {
                    customConfig = org.springframework.util.StringUtils.cleanPath(customConfig);
                    if (!ResourceUtils.isUrl(customConfig)) {
                        customConfig = ResourceUtils.FILE_URL_PREFIX + customConfig;
                    }
                }
                configFiles.add(customConfig);
            }
            logger.debug("Loading scTrain config: {}", configFiles);
            INSTANCE = new PropertiesUtils(configFiles.toArray(new String[configFiles.size()]));
        }
    }

}
```

### 在SpringBootApplication启动类里调用此工具类

```
@SpringBootApplication
public class XXXApplication {

	private final static Logger logger =	LoggerFactory.getLogger(XXXApplication.class);

	public static void main(String[] args) {
    		SpringApplication app = new SpringApplication(XXXApplication.class);
    		app.setDefaultProperties(PropertiesUtils.getInstance().getProperties());
    		app.run(args);
    		logger.info("XXXApplication is success!");
	}
}
```

