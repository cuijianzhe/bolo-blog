title: Neo4j（一）介绍与下载与安装
date: '2020-07-04 08:18:53'
updated: '2020-07-04 09:12:07'
tags: [neo4j]
permalink: /articles/2020/07/04/1593821933784.html
---
![](https://b3logfile.com/bing/20190213.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

## Neo4j介绍

**举个例子**：如果有一个电影资料数据库，要查询《战狼2》里的哪一个演员成为了好莱坞评委，这在传统数据库里可能需要关联好几张表（电影表，演员表，电影与演员关联表，好莱坞评委表，好莱坞与评委关联表，甚至因为演员表和电影表单表信息量过大还需要分表存储，这就已经好多张表了）进行查询，但是Neo4j是由于没有表的概念，而且通过一条语句区分一下标签和关联关系再加上where条件就可以查询出来。

而且你用sql查询出来给谁看呀，db工程师还是开发人员啊？Neo4j查询出来之后是有一张图的，有图的，谁都能看懂这几个节点只有有联系，有什么联系。

https://xyt.cjzshilong.cn/neo4j%E4%BB%8B%E7%BB%8D_2020748400.mp4

## 下载Neo4j数据库

[Neo4j下载](https://neo4j.com/download/)

注册完后会有一个key要保存下来，然后安装完软件后会要输入，跟idea一个道理。???

![image.png](https://b3logfile.com/file/2020/07/image-59aedf5d.png)

### 下载完成后安装打开是类似于这样的画面就ok了???

![image.png](https://b3logfile.com/file/2020/07/image-2086dec5.png)

### 点击start启动其中一个数据库，注意只能同时启动一个数据库???

![image.png](https://b3logfile.com/file/2020/07/image-b01187ee.png)

### 点击open就可以进入数据库的操作窗口???

![image.png](https://b3logfile.com/file/2020/07/image-d99199ad.png)

### 输入命令查看返回结果图???

![image.png](https://b3logfile.com/file/2020/07/image-d309453a.png)

#### 刚安装完没有出现open按钮的同学不要着急，等一会儿它自己就下载安装插件了就可以点击open了

#### 同时也可以通过访问浏览器路径打开一样的操作台???

http://localhost:7474/browser/

下篇会讲到neo4j的查询语句使用方法，敬请期待
