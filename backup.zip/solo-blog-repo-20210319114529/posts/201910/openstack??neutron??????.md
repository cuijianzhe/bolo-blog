title: openstack系列-neutron系列安装部署
date: '2019-10-15 10:01:16'
updated: '2020-08-24 18:48:15'
tags: [Linux, openstack]
permalink: /articles/2019/10/15/1571104876779.html
---
# [neutron 部署](https://docs.openstack.org/neutron/rocky/install/controller-install-rdo.html)

## mysql 库创建

```
CREATE DATABASE neutron;
 GRANT ALL PRIVILEGES ON neutron.* TO 'neutron'@'localhost' \
  IDENTIFIED BY 'neutron';
GRANT ALL PRIVILEGES ON neutron.* TO 'neutron'@'%' \
  IDENTIFIED BY 'neutron';
```

## 创建服务凭据

* 创建 neutron 用户

```bash
[root@linux-node1 ~]# . admin-openrc 
[root@linux-node1 ~]# openstack user create --domain default --password-prompt neutron
User Password:
Repeat User Password:
+---------------------+----------------------------------+
| Field               | Value                            |
+---------------------+----------------------------------+
| domain_id           | default                          |
| enabled             | True                             |
| id                  | c0ce9b3d5a134ad08ce402c7528b1e91 |
| name                | neutron                          |
| options             | {}                               |
| password_expires_at | None                             |
+---------------------+----------------------------------+
```

* 向 neutron 用户添加管理员角色

```
openstack role add --project service --user neutron admin
```

* 创建neutron服务实体

```bash
[root@linux-node1 ~]# openstack service create --name neutron \
>   --description "OpenStack Networking" network
+-------------+----------------------------------+
| Field       | Value                            |
+-------------+----------------------------------+
| description | OpenStack Networking             |
| enabled     | True                             |
| id          | bf1996ceb1d846deb8af3b208f2ff4e1 |
| name        | neutron                          |
| type        | network                          |
+-------------+----------------------------------+
```

## 创建网络服务API endpoint

```bash
[root@linux-node1 ~]#   openstack endpoint create --region RegionOne \
>   network public http://10.200.51.100:9696
+--------------+----------------------------------+
| Field        | Value                            |
+--------------+----------------------------------+
| enabled      | True                             |
| id           | 5ef730844dab4c4c9c348a003b1cb8f7 |
| interface    | public                           |
| region       | RegionOne                        |
| region_id    | RegionOne                        |
| service_id   | bf1996ceb1d846deb8af3b208f2ff4e1 |
| service_name | neutron                          |
| service_type | network                          |
| url          | http://10.200.51.100:9696        |
+--------------+----------------------------------+
[root@linux-node1 ~]#   openstack endpoint create --region RegionOne \
>   network internal http://10.200.51.100:9696

+--------------+----------------------------------+
| Field        | Value                            |
+--------------+----------------------------------+
| enabled      | True                             |
| id           | 89e583655b7c4446892cb58dcc40152a |
| interface    | internal                         |
| region       | RegionOne                        |
| region_id    | RegionOne                        |
| service_id   | bf1996ceb1d846deb8af3b208f2ff4e1 |
| service_name | neutron                          |
| service_type | network                          |
| url          | http://10.200.51.100:9696        |
+--------------+----------------------------------+
[root@linux-node1 ~]#   
[root@linux-node1 ~]#    openstack endpoint create --region RegionOne \
>   network admin http://10.200.51.100:9696
+--------------+----------------------------------+
| Field        | Value                            |
+--------------+----------------------------------+
| enabled      | True                             |
| id           | 9abfbfb1288f40c7a92845ffcb6c3d8e |
| interface    | admin                            |
| region       | RegionOne                        |
| region_id    | RegionOne                        |
| service_id   | bf1996ceb1d846deb8af3b208f2ff4e1 |
| service_name | neutron                          |
| service_type | network                          |
| url          | http://10.200.51.100:9696        |
+--------------+----------------------------------+
```

## 配置网络选项

> Choose one of the following networking options to configure services specific to it. Afterwards, return here and proceed to [Configure the metadata agent](https://docs.openstack.org/neutron/rocky/install/controller-install-rdo.html#neutron-controller-metadata-agent-rdo).

* [Networking Option 1: Provider networks](https://docs.openstack.org/neutron/rocky/install/controller-install-option1-rdo.html)
* [Networking Option 2: Self-service networks](https://docs.openstack.org/neutron/rocky/install/controller-install-option2-rdo.html)

选项1部署了最简单的架构，该架构仅支持将实例附加到提供商（外部）网络。没有自助（私有）网络，路由器或浮动IP地址。只有该`admin`特权用户或其他特权用户才能管理提供商网络。

```
yum install openstack-neutron openstack-neutron-ml2 \
  openstack-neutron-linuxbridge ebtables -y
```

### 编辑 `/etc/neutron/neutron.conf`文件

* 在[database]部分中，配置数据库访问：

```
[database]
connection = mysql+pymysql://neutron:neutron@10.200.51.100/neutron
```

* 在[DEFAULT]部分中

```bash
[DEFAULT]
#启用模块化层2（ml2）插件并禁用其他插件
core_plugin = ml2
service_plugins =
#配置rabbitmq消息队列访问
transport_url = rabbit://openstack:openstack@10.200.51.100
auth_strategy = keystone
```

* 在[default]和[keystone_authToken]部分中，配置标识服务访问：

```bash
[keystone_authtoken]
www_authenticate_uri = http://10.200.51.100:5000
auth_url = http://10.200.51.100:5000
memcached_servers = 10.200.51.100:11211
auth_type = password
project_domain_name = default
user_domain_name = default
project_name = service
username = neutron
password = 598941324
```

* 在[default]和[nova]部分中，配置networking以通知compute网络拓扑更改

```
[DEFAULT]
notify_nova_on_port_status_changes = true
notify_nova_on_port_data_changes = true
```

```
[nova]
auth_url = http://10.200.51.100:5000
auth_type = password
project_domain_name = default
user_domain_name = default
region_name = RegionOne
project_name = service
username = nova
password = 598941324
```

* 在[oslo_concurrency]部分中，配置锁路径

```
[oslo_concurrency]
lock_path = /var/lib/neutron/tmp
```

### 配置模块化第2层（ML2）插件

####配置 /etc/neutron/plugins/ml2/ml2_conf.ini

* 在[ML2]部分中，启用平面和VLAN网络

```
[ml2]
type_drivers = flat,vlan
```

* 在[ML2]部分中，禁用自助服务网络

```
[ml2]
tenant_network_types =
```

* 在[ml2]部分中，启用Linux网桥机制

```
[ml2]
mechanism_drivers = linuxbridge
```

> After you configure the ML2 plug-in, removing values in the `type_drivers` option can lead to database inconsistency.

* 在[ML2]部分中，启用端口安全扩展驱动程序：

```
[ml2]
extension_drivers = port_security
```

* 在[ml2_type_flat]部分中，将提供商虚拟网络配置为平面网络

```
[ml2_type_flat]
# ...
flat_networks = provider
```

* 在[SecurityGroup]部分中，启用IPset以提高安全组规则的效率

```
[securitygroup]
# ...
enable_ipset = true
```

#### 配置Linux网桥代理

编辑/etc/neutron/plugins/ml2/linuxbridge_agent.ini

* 在[Linux_Bridge]部分中，将提供程序虚拟网络映射到提供程序物理网络接口：

```
[linux_bridge]
physical_interface_mappings = provider:ens33
```

* 在[vxlan]部分，禁用vxlan覆盖网络：

```
[vxlan]
enable_vxlan = false
```

* 在[SecurityGroup]部分中，启用安全组并配置Linux网桥iptables防火墙驱动程序：

```
[securitygroup]
enable_security_group = true
firewall_driver = neutron.agent.linux.iptables_firewall.IptablesFirewallDriver
```

* 通过验证以下所有sysctl值均设置为1，确保Linux操作系统内核支持网络桥筛选器

```bash
vim /etc/sysctl.conf
#...
net.bridge.bridge-nf-call-ip6tables = 1
net.bridge.bridge-nf-call-iptables = 1
```

```bash
[root@linux-node1 ~]# sysctl -p 
net.bridge.bridge-nf-call-ip6tables = 1
net.bridge.bridge-nf-call-iptables = 1
```

> 要启用网桥支持，通常需要加载bru netfilter内核模块.

```
[root@linux-node1 ~]#  modprobe br_netfilter
[root@linux-node1 ~]#  ls /proc/sys/net/bridge
bridge-nf-call-arptables  bridge-nf-call-ip6tables  bridge-nf-call-iptables  bridge-nf-filter-pppoe-tagged  bridge-nf-filter-vlan-tagged  bridge-nf-pass-vlan-input-dev
```

### 配置DHCP代理

编辑`/etc/neutron/dhcp_agent.ini`文件

* 在[默认]部分中，配置Linux网桥接口驱动程序dnsmasq dhcp驱动程序，并启用隔离元数据，以便提供程序网络上的实例可以通过网络访问元数据：

```
[DEFAULT]
# ...
interface_driver = linuxbridge
dhcp_driver = neutron.agent.linux.dhcp.Dnsmasq
enable_isolated_metadata = true
```

### [Networking Option 2: Self-service networks](https://docs.openstack.org/neutron/rocky/install/controller-install-option2-rdo.html)

网络配置选项2：

### 配置元数据代理

* 在[DEFAULT]部分中，配置元数据主机和共享密钥：

```
[DEFAULT]
nova_metadata_host = 10.200.51.100
metadata_proxy_shared_secret = 598941324
```

### 将计算服务配置为使用网络服务

* 编辑/etc/nova/nova.conf文件

```
[neutron]
url = http://10.200.51.100:9696
auth_url = http://10.200.51.100:5000
auth_type = 598941324
project_domain_name = default
user_domain_name = default
region_name = RegionOne
project_name = service
username = neutron
password = 598941324
service_metadata_proxy = true
metadata_proxy_shared_secret = 598941324
```

### 最后安装

* 网络服务初始化脚本需要一个指向ml2插件配置文件/etc/neutron/plugins/ml2/ml2_conf.ini的符号链接/etc/neutron/plugins.ini。如果此符号链接不存在，则使用以下命令创建它：

```
ln -s /etc/neutron/plugins/ml2/ml2_conf.ini /etc/neutron/plugin.ini
```

### 填充数据库：

```
su -s /bin/sh -c "neutron-db-manage --config-file /etc/neutron/neutron.conf \
  --config-file /etc/neutron/plugins/ml2/ml2_conf.ini upgrade head" neutron
```

* 重新启动计算API服务：

```
systemctl restart openstack-nova-api.service
```

* 启动网络服务并将其配置为在系统启动时启动。对于两种网络选项：

```
# systemctl enable neutron-server.service \
  neutron-linuxbridge-agent.service neutron-dhcp-agent.service \
  neutron-metadata-agent.service
# systemctl start neutron-server.service \
  neutron-linuxbridge-agent.service neutron-dhcp-agent.service \
  neutron-metadata-agent.service
```

~~对于网络选项2，还启用并启动第3层服务~~

```
# systemctl enable neutron-l3-agent.service
# systemctl start neutron-l3-agent.service
```

> 这里我是第一种

# [neutron计算节点安装](https://docs.openstack.org/neutron/rocky/install/compute-install-rdo.html)

```
yum install openstack-neutron-linuxbridge ebtables ipset
```

## 配置公共组件

```
[DEFAULT]
transport_url = rabbit://openstack:openstack@10.200.51.100
```

* 在[default]和[keystone_authToken]部分中，配置标识服务访问：

```
[DEFAULT]
# ...
auth_strategy = keystone

[keystone_authtoken]
www_authenticate_uri = http://10.200.51.100:5000
auth_url = http://10.200.51.100:5000
memcached_servers = 10.200.51.100:11211
auth_type = password
project_domain_name = default
user_domain_name = default
project_name = service
username = neutron
password = 598941324
```

* 在[oslo_concurrency]部分中，配置锁路径：

```
[oslo_concurrency]
lock_path = /var/lib/neutron/tmp
```

## 配置网络选项

Choose the same networking option that you chose for the controller node to configure services specific to it. Afterwards, return here and proceed to [Configure the Compute service to use the Networking service](https://docs.openstack.org/neutron/rocky/install/compute-install-rdo.html#neutron-compute-compute-rdo).

* [Networking Option 1: Provider networks](https://docs.openstack.org/neutron/rocky/install/compute-install-option1-rdo.html)
* [Networking Option 2: Self-service networks](https://docs.openstack.org/neutron/rocky/install/compute-install-option2-rdo.html)

### [](https://docs.openstack.org/neutron/rocky/install/compute-install-option1-rdo.html)

#### 配置Linux网桥代理

编辑 `/etc/neutron/plugins/ml2/linuxbridge_agent.ini`文件

* [Linux_Bridge]部分中，将提供程序虚拟网络映射到提供程序物理网络接口

```
[linux_bridge]
physical_interface_mappings = provider:ens33
```

* 在[vxlan]部分，禁用vxlan覆盖网络：

```
[vxlan]
enable_vxlan = false
```

* 在[SecurityGroup]部分中，启用安全组并配置Linux网桥iptables防火墙驱动程序：

```
[securitygroup]
# ...
enable_security_group = true
firewall_driver = neutron.agent.linux.iptables_firewall.IptablesFirewallDriver
```

* 通过验证以下所有sysctl值均设置为1，确保Linux操作系统内核支持网络桥筛选器：

```
[root@linux-node2 ~]# modprobe br_netfilter
[root@linux-node2 ~]# ls /proc/sys/net/bridge
bridge-nf-call-arptables  bridge-nf-call-iptables        bridge-nf-filter-vlan-tagged
bridge-nf-call-ip6tables  bridge-nf-filter-pppoe-tagged  bridge-nf-pass-vlan-input-dev
```

```
vim /etc/sysctl.conf 
net.bridge.bridge-nf-call-ip6tables = 1 
net.bridge.bridge-nf-call-iptables = 1
```

使其生效

```
[root@linux-node2 ~]# sysctl -p
net.bridge.bridge-nf-call-ip6tables = 1
net.bridge.bridge-nf-call-iptables = 1
```

* 编辑/etc/nova/nova.conf文件并完成以下操作：

```
[neutron]
url = http://10.200.51.100:9696
auth_url = http://10.200.51.100:5000
auth_type = password
project_domain_name = default
user_domain_name = default
region_name = RegionOne
project_name = service
username = neutron
password = 598941324
```

### [第二种网络方法选项](https://docs.openstack.org/neutron/rocky/install/compute-install-option2-rdo.html)

暂不使用

## 完成安装

* 重启

```
systemctl restart openstack-nova-compute.service
```

* 启动Linux网桥代理并将其配置为在系统引导时启动

```
systemctl enable neutron-linuxbridge-agent.service 
systemctl start neutron-linuxbridge-agent.service
```

## [验证操作](https://docs.openstack.org/neutron/rocky/install/verify.html)

* 列出neutron验证成功的代理

```
[root@linux-node1 ~]# openstack network agent list
+--------------------------------------+--------------------+-------------+-------------------+-------+-------+---------------------------+
| ID                                   | Agent Type         | Host        | Availability Zone | Alive | State | Binary                    |
+--------------------------------------+--------------------+-------------+-------------------+-------+-------+---------------------------+
| 3a300c2c-73dd-4ddd-b8af-2e39b54846b5 | Metadata agent     | linux-node1 | None              | :-)   | UP    | neutron-metadata-agent    |
| 5ad73cc8-8a6d-4fcb-a630-7fb52722f2a8 | Linux bridge agent | linux-node1 | None              | :-)   | UP    | neutron-linuxbridge-agent |
| aa8498be-1f4e-4151-b9ed-50b474e49e28 | Linux bridge agent | linux-node2 | None              | :-)   | UP    | neutron-linuxbridge-agent |
| dfcc05c5-2a57-49ee-9013-8097d8ecb854 | DHCP agent         | linux-node1 | nova              | :-)   | UP    | neutron-dhcp-agent        |
+--------------------------------------+--------------------+-------------+-------------------+-------+-------+---------------------------+
```

# [创建网络](https://docs.openstack.org/install-guide/launch-instance-networks-provider.html)

> 首先需要创建一个虚拟网络，根据配置Neutron时选择的网络选项进行虚拟网络的配置。

## 创建网络

```
[root@linux-node1 ~]# . admin-openrc 
[root@linux-node1 ~]# openstack network create  --share --external \
>   --provider-physical-network provider \
>   --provider-network-type flat provider
+---------------------------+--------------------------------------+
| Field                     | Value                                |
+---------------------------+--------------------------------------+
| admin_state_up            | UP                                   |
| availability_zone_hints   |                                      |
| availability_zones        |                                      |
| created_at                | 2019-10-19T03:02:06Z                 |
| description               |                                      |
| dns_domain                | None                                 |
| id                        | e5179b09-cf50-46d5-b0e8-e02909b94ffe |
| ipv4_address_scope        | None                                 |
| ipv6_address_scope        | None                                 |
| is_default                | None                                 |
| is_vlan_transparent       | None                                 |
| mtu                       | 1500                                 |
| name                      | provider                             |
| port_security_enabled     | True                                 |
| project_id                | 6385e862e7874f0f91d4a46772a0d4e7     |
| provider:network_type     | flat                                 |
| provider:physical_network | provider                             |
| provider:segmentation_id  | None                                 |
| qos_policy_id             | None                                 |
| revision_number           | 0                                    |
| router:external           | External                             |
| segments                  | None                                 |
| shared                    | True                                 |
| status                    | ACTIVE                               |
| subnets                   |                                      |
| tags                      |                                      |
| updated_at                | 2019-10-19T03:02:06Z                 |
+---------------------------+--------------------------------------+
```

> --share选项允许所有项目使用虚拟网络。
> --external选项将虚拟网络定义为外部网络。如果希望创建内部网络，可以使用--internal代替。默认值为内部。
> --provider physical network provider 为在/etc/neutron/plugins/ml2/ml2_conf.ini中配置的flat_networks。

```
[ml2_type_flat]  
flat_networks = provider
```

--provider network type flat选项使用来自以下文件的信息将扁平虚拟网络连接到主机上ens0接口上的扁平（本机/未标记）物理网络：在 /etc/neutron/plugins/ml2/linuxbridge_agent.ini

```
[linux_bridge]
physical_interface_mappings = provider:enp61s0f0
```

* 在网络上创建子网：

```
[root@linux-node1 ~]# openstack subnet create --network provider   --allocation-pool start=192.168.51.10,end=192.168.51.150   --dns-nameserver 223.5.5.5  --gateway 192.168.51.1   --subnet-range 192.168.51.0/24 public
+-------------------+--------------------------------------+
| Field             | Value                                |
+-------------------+--------------------------------------+
| allocation_pools  | 192.168.51.10-192.168.51.150         |
| cidr              | 192.168.51.0/24                      |
| created_at        | 2019-10-19T03:39:46Z                 |
| description       |                                      |
| dns_nameservers   | 223.5.5.5                            |
| enable_dhcp       | True                                 |
| gateway_ip        | 192.168.51.1                         |
| host_routes       |                                      |
| id                | 0f6331e7-8f1d-4231-a2a4-f4bcd895ad83 |
| ip_version        | 4                                    |
| ipv6_address_mode | None                                 |
| ipv6_ra_mode      | None                                 |
| name              | public                               |
| network_id        | e5179b09-cf50-46d5-b0e8-e02909b94ffe |
| project_id        | 6385e862e7874f0f91d4a46772a0d4e7     |
| revision_number   | 0                                    |
| segment_id        | None                                 |
| service_types     |                                      |
| subnetpool_id     | None                                 |
| tags              |                                      |
| updated_at        | 2019-10-19T03:39:46Z                 |
+-------------------+--------------------------------------+
```

> PROVIDER_NETWORK_CIDR 采用物理网络上的CIDR子网表示。
> `START_IP_ADDRESS` and `END_IP_ADDRESS`：子网中要为实例分配的范围的第一个和最后一个IP地址。此范围不得包含任何现有的活动IP地址。
> DNS_RESOLVER使用DNS解析程序的IP地址。在大多数情况下，可以使用主机上/etc/resolv.conf文件中的一个。
> `PROVIDER_NETWORK_GATEWAY` 提供程序网络上的网关IP地址，通常是“.1”IP地址。

验证：

```
[root@linux-node1 ~]# ip netns
qdhcp-e5179b09-cf50-46d5-b0e8-e02909b94ffe (id: 0)
```

创建虚拟机：

```
[root@linux-node1 ~]# openstack flavor create --id 0 --vcpus 1 --ram 64 --disk 1 m1.nano
+----------------------------+---------+
| Field                      | Value   |
+----------------------------+---------+
| OS-FLV-DISABLED:disabled   | False   |
| OS-FLV-EXT-DATA:ephemeral  | 0       |
| disk                       | 1       |
| id                         | 0       |
| name                       | m1.nano |
| os-flavor-access:is_public | True    |
| properties                 |         |
| ram                        | 64      |
| rxtx_factor                | 1.0     |
| swap                       |         |
| vcpus                      | 1       |
+----------------------------+---------+
```

* 生成密钥对
  生成密钥对并添加公钥：

```
[root@linux-node1 ~]# ssh-keygen -q -N ""
Enter file in which to save the key (/root/.ssh/id_rsa): 
[root@linux-node1 ~]# openstack keypair create --public-key ~/.ssh/id_rsa.pub mykey
+-------------+-------------------------------------------------+
| Field       | Value                                           |
+-------------+-------------------------------------------------+
| fingerprint | ca:96:b1:22:4e:dd:7b:ed:26:9d:24:07:83:05:25:66 |
| name        | mykey                                           |
| user_id     | 93fe6925e0fb476f9ee66d8598f189cf                |
+-------------+-------------------------------------------------+
```

验证密钥对的添加：

```
[root@linux-node1 ~]# openstack keypair list
+-------+-------------------------------------------------+
| Name  | Fingerprint                                     |
+-------+-------------------------------------------------+
| mykey | ca:96:b1:22:4e:dd:7b:ed:26:9d:24:07:83:05:25:66 |
+-------+-------------------------------------------------+
```

### 添加安全组规则

默认情况下，默认安全组应用于所有实例，并包含拒绝远程访问实例的防火墙规则。对于cirros等linux映像，我们建议至少允许icmp（ping）和secure shell（ssh）。

* 向默认安全组添加规则：
  允许ICMP（ping）：

```
[root@linux-node1 ~]#  openstack security group rule create --proto icmp default
+-------------------+--------------------------------------+
| Field             | Value                                |
+-------------------+--------------------------------------+
| created_at        | 2019-10-19T06:31:41Z                 |
| description       |                                      |
| direction         | ingress                              |
| ether_type        | IPv4                                 |
| id                | 07a5686f-bac8-4b36-b036-1c67ca55f02e |
| name              | None                                 |
| port_range_max    | None                                 |
| port_range_min    | None                                 |
| project_id        | d13cc91dc74347628cb460d6f497ee47     |
| protocol          | icmp                                 |
| remote_group_id   | None                                 |
| remote_ip_prefix  | 0.0.0.0/0                            |
| revision_number   | 0                                    |
| security_group_id | 346b8ee6-7b94-4cff-a902-fdeadb812892 |
| updated_at        | 2019-10-19T06:31:41Z                 |
+-------------------+--------------------------------------+
```

允许安全（ssh）访问：

```
[root@linux-node1 ~]# openstack security group rule create --proto tcp --dst-port 22 default
+-------------------+--------------------------------------+
| Field             | Value                                |
+-------------------+--------------------------------------+
| created_at        | 2019-10-19T06:32:24Z                 |
| description       |                                      |
| direction         | ingress                              |
| ether_type        | IPv4                                 |
| id                | 4aabf58b-1d99-47ca-bef0-a423f2fb2e3a |
| name              | None                                 |
| port_range_max    | 22                                   |
| port_range_min    | 22                                   |
| project_id        | d13cc91dc74347628cb460d6f497ee47     |
| protocol          | tcp                                  |
| remote_group_id   | None                                 |
| remote_ip_prefix  | 0.0.0.0/0                            |
| revision_number   | 0                                    |
| security_group_id | 346b8ee6-7b94-4cff-a902-fdeadb812892 |
| updated_at        | 2019-10-19T06:32:24Z                 |
+-------------------+--------------------------------------+
```

### [启动网络实例](https://docs.openstack.org/install-guide/launch-instance-provider.html)

* Flavor指定了一个虚拟资源分配配置文件，其中包括处理器、内存和存储。列出可用的口味：

```
[root@linux-node1 ~]# . myuser-openrc 
[root@linux-node1 ~]#  openstack flavor list
+----+---------+-----+------+-----------+-------+-----------+
| ID | Name    | RAM | Disk | Ephemeral | VCPUs | Is Public |
+----+---------+-----+------+-----------+-------+-----------+
| 0  | m1.nano |  64 |    1 |         0 |     1 | True      |
+----+---------+-----+------+-----------+-------+-----------+
```

* 列出可用图像：

```
[root@linux-node1 ~]# openstack image list

+--------------------------------------+--------+--------+
| ID                                   | Name   | Status |
+--------------------------------------+--------+--------+
| 44dbc6cf-cf2a-4d0a-af1f-39489c454f39 | cirros | active |
+--------------------------------------+--------+--------+
```

* 列出可用网络：

```
[root@linux-node1 ~]#  openstack network list
+--------------------------------------+----------+--------------------------------------+
| ID                                   | Name     | Subnets                              |
+--------------------------------------+----------+--------------------------------------+
| e5179b09-cf50-46d5-b0e8-e02909b94ffe | provider | 0f6331e7-8f1d-4231-a2a4-f4bcd895ad83 |
+--------------------------------------+----------+--------------------------------------+
```

* 列出可用的安全组：

```
[root@linux-node1 ~]# openstack security group list
+--------------------------------------+---------+------------------------+----------------------------------+------+
| ID                                   | Name    | Description            | Project                          | Tags |
+--------------------------------------+---------+------------------------+----------------------------------+------+
| 346b8ee6-7b94-4cff-a902-fdeadb812892 | default | Default security group | d13cc91dc74347628cb460d6f497ee47 | []   |
+--------------------------------------+---------+------------------------+----------------------------------+------+
```

### 启动实例

```
[root@linux-node1 ~]#  openstack server create --flavor m1.nano --image cirros   --security-group default   --key-name mykey provider-instance
+-----------------------------+-----------------------------------------------+
| Field                       | Value                                         |
+-----------------------------+-----------------------------------------------+
| OS-DCF:diskConfig           | MANUAL                                        |
| OS-EXT-AZ:availability_zone |                                               |
| OS-EXT-STS:power_state      | NOSTATE                                       |
| OS-EXT-STS:task_state       | scheduling                                    |
| OS-EXT-STS:vm_state         | building                                      |
| OS-SRV-USG:launched_at      | None                                          |
| OS-SRV-USG:terminated_at    | None                                          |
| accessIPv4                  |                                               |
| accessIPv6                  |                                               |
| addresses                   |                                               |
| adminPass                   | xEbweLr2Yz74                                  |
| config_drive                |                                               |
| created                     | 2019-10-19T06:38:44Z                          |
| flavor                      | m1.nano (0)                                   |
| hostId                      |                                               |
| id                          | 1e497f41-aa2a-458a-9970-261d6fdc06dc          |
| image                       | cirros (44dbc6cf-cf2a-4d0a-af1f-39489c454f39) |
| key_name                    | mykey                                         |
| name                        | provider-instance                             |
| progress                    | 0                                             |
| project_id                  | d13cc91dc74347628cb460d6f497ee47              |
| properties                  |                                               |
| security_groups             | name='346b8ee6-7b94-4cff-a902-fdeadb812892'   |
| status                      | BUILD                                         |
| updated                     | 2019-10-19T06:38:44Z                          |
| user_id                     | 93fe6925e0fb476f9ee66d8598f189cf              |
| volumes_attached            |                                               |
+-----------------------------+-----------------------------------------------+
```

* 检查实例的状态：

```
[root@linux-node1 ~]# openstack server list
+--------------------------------------+-------------------+--------+----------+--------+---------+
| ID                                   | Name              | Status | Networks | Image  | Flavor  |
+--------------------------------------+-------------------+--------+----------+--------+---------+
| 1e497f41-aa2a-458a-9970-261d6fdc06dc | provider-instance | ERROR  |          | cirros | m1.nano |
+--------------------------------------+-------------------+--------+----------+--------+---------+
```

### 使用虚拟主控台存取执行个体

* 获取实例的虚拟网络计算（VNC）会话URL并从Web浏览器访问它：

## [创建实例：](https://docs.openstack.org/install-guide/launch-instance.html#launch-instance-networks)

```
[root@controller ~]# openstack flavor create --id 0 --vcpus 1 --ram 64 --disk 1 m1.nano
+----------------------------+---------+
| Field                      | Value   |
+----------------------------+---------+
| OS-FLV-DISABLED:disabled   | False   |
| OS-FLV-EXT-DATA:ephemeral  | 0       |
| disk                       | 1       |
| id                         | 0       |
| name                       | m1.nano |
| os-flavor-access:is_public | True    |
| properties                 |         |
| ram                        | 64      |
| rxtx_factor                | 1.0     |
| swap                       |         |
| vcpus                      | 1       |
+----------------------------+---------+
```

* 创建ssh key

```
[root@controller ~]#  ssh-keygen -q -N ""
Enter file in which to save the key (/root/.ssh/id_rsa): 
[root@controller ~]# openstack keypair create --public-key ~/.ssh/id_rsa.pub mykey
+-------------+-------------------------------------------------+
| Field       | Value                                           |
+-------------+-------------------------------------------------+
| fingerprint | ea:57:21:d5:cf:1b:be:f4:27:c3:11:4d:ca:63:ce:1f |
| name        | mykey                                           |
| user_id     | 3642a0239ea24f98a8eb39b5685e1fff                |
+-------------+-------------------------------------------------+
```

```
[root@controller ~]# openstack keypair list
+-------+-------------------------------------------------+
| Name  | Fingerprint                                     |
+-------+-------------------------------------------------+
| mykey | ea:57:21:d5:cf:1b:be:f4:27:c3:11:4d:ca:63:ce:1f |
+-------+-------------------------------------------------+
```

* 安全组配置（放通ping和ssh远程端口）

```
[root@controller ~]# openstack security group rule create --proto icmp default
+-------------------+--------------------------------------+
| Field             | Value                                |
+-------------------+--------------------------------------+
| created_at        | 2019-10-23T02:04:22Z                 |
| description       |                                      |
| direction         | ingress                              |
| ether_type        | IPv4                                 |
| id                | 01e7d03e-ac6b-40e8-99ac-751ae6435be7 |
| name              | None                                 |
| port_range_max    | None                                 |
| port_range_min    | None                                 |
| project_id        | 0eeb62090a094959ae36ce627f10cc1b     |
| protocol          | icmp                                 |
| remote_group_id   | None                                 |
| remote_ip_prefix  | 0.0.0.0/0                            |
| revision_number   | 0                                    |
| security_group_id | ae62b441-4ec0-46b0-aed8-51f0bef56610 |
| updated_at        | 2019-10-23T02:04:22Z                 |
+-------------------+--------------------------------------+
```

```
[root@controller ~]# openstack security group rule create --proto tcp --dst-port 22 default
+-------------------+--------------------------------------+
| Field             | Value                                |
+-------------------+--------------------------------------+
| created_at        | 2019-10-23T02:05:33Z                 |
| description       |                                      |
| direction         | ingress                              |
| ether_type        | IPv4                                 |
| id                | a81df169-6582-4f72-901d-503e05ad33a8 |
| name              | None                                 |
| port_range_max    | 22                                   |
| port_range_min    | 22                                   |
| project_id        | 0eeb62090a094959ae36ce627f10cc1b     |
| protocol          | tcp                                  |
| remote_group_id   | None                                 |
| remote_ip_prefix  | 0.0.0.0/0                            |
| revision_number   | 0                                    |
| security_group_id | ae62b441-4ec0-46b0-aed8-51f0bef56610 |
| updated_at        | 2019-10-23T02:05:33Z                 |
+-------------------+--------------------------------------+
```

* [启动实例](https://docs.openstack.org/install-guide/launch-instance-selfservice.html)

查看相关信息：

```
[root@controller ~]#  openstack flavor list
+----+---------+-----+------+-----------+-------+-----------+
| ID | Name    | RAM | Disk | Ephemeral | VCPUs | Is Public |
+----+---------+-----+------+-----------+-------+-----------+
| 0  | m1.nano |  64 |    1 |         0 |     1 | True      |
+----+---------+-----+------+-----------+-------+-----------+
[root@controller ~]#  openstack image list
+--------------------------------------+--------+--------+
| ID                                   | Name   | Status |
+--------------------------------------+--------+--------+
| f5f2008a-a230-4692-8fec-2634b4eaaac9 | cirros | active |
+--------------------------------------+--------+--------+
[root@controller ~]#  openstack network list

+--------------------------------------+-------------+--------------------------------------+
| ID                                   | Name        | Subnets                              |
+--------------------------------------+-------------+--------------------------------------+
| cd7dd9bc-c2fd-40a9-9a77-a8573091e272 | selfservice | 4d190708-3579-4040-a578-d54143339515 |
+--------------------------------------+-------------+--------------------------------------+
[root@controller ~]# 
[root@controller ~]#  openstack security group list
+--------------------------------------+---------+------------------------+----------------------------------+------+
| ID                                   | Name    | Description            | Project                          | Tags |
+--------------------------------------+---------+------------------------+----------------------------------+------+
| ae62b441-4ec0-46b0-aed8-51f0bef56610 | default | Default security group | 0eeb62090a094959ae36ce627f10cc1b | []   |
+--------------------------------------+---------+------------------------+----------------------------------+------+
```

```
[root@controller ~]#  openstack server create --flavor m1.nano --image cirros \
>   --nic net-id=cd7dd9bc-c2fd-40a9-9a77-a8573091e272 --security-group default \
>   --key-name mykey selfservice-instance
+-------------------------------------+-----------------------------------------------+
| Field                               | Value                                         |
+-------------------------------------+-----------------------------------------------+
| OS-DCF:diskConfig                   | MANUAL                                        |
| OS-EXT-AZ:availability_zone         |                                               |
| OS-EXT-SRV-ATTR:host                | None                                          |
| OS-EXT-SRV-ATTR:hypervisor_hostname | None                                          |
| OS-EXT-SRV-ATTR:instance_name       |                                               |
| OS-EXT-STS:power_state              | NOSTATE                                       |
| OS-EXT-STS:task_state               | scheduling                                    |
| OS-EXT-STS:vm_state                 | building                                      |
| OS-SRV-USG:launched_at              | None                                          |
| OS-SRV-USG:terminated_at            | None                                          |
| accessIPv4                          |                                               |
| accessIPv6                          |                                               |
| addresses                           |                                               |
| adminPass                           | 48QHgJn8fsL4                                  |
| config_drive                        |                                               |
| created                             | 2019-10-23T02:19:11Z                          |
| flavor                              | m1.nano (0)                                   |
| hostId                              |                                               |
| id                                  | 5ef50bf1-90f6-42be-ad4c-97e76b921ab4          |
| image                               | cirros (f5f2008a-a230-4692-8fec-2634b4eaaac9) |
| key_name                            | mykey                                         |
| name                                | selfservice-instance                          |
| progress                            | 0                                             |
| project_id                          | 0eeb62090a094959ae36ce627f10cc1b              |
| properties                          |                                               |
| security_groups                     | name='ae62b441-4ec0-46b0-aed8-51f0bef56610'   |
| status                              | BUILD                                         |
| updated                             | 2019-10-23T02:19:11Z                          |
| user_id                             | 3642a0239ea24f98a8eb39b5685e1fff              |
| volumes_attached                    |                                               |
+-------------------------------------+-----------------------------------------------+
```

* 检查实例的状态：

```
[root@controller ~]# openstack server list 
+--------------------------------------+----------------------+--------+----------+--------+---------+
| ID                                   | Name                 | Status | Networks | Image  | Flavor  |
+--------------------------------------+----------------------+--------+----------+--------+---------+
| 5ef50bf1-90f6-42be-ad4c-97e76b921ab4 | selfservice-instance | ERROR  |          | cirros | m1.nano |
+--------------------------------------+----------------------+--------+----------+--------+---------+
```

