title: 非常简单的java树结构实现，即拿即用
date: '2020-06-24 14:17:47'
updated: '2020-06-24 14:18:23'
tags: [java]
permalink: /articles/2020/06/24/1592979467491.html
---
![](https://b3logfile.com/bing/20190726.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

```java
public static List<SysDict> buildTree(List<SysDict> list, String pid){
        List<SysDict> treeList = new LinkedList<>();

        for (SysDict sysDict : list) {
            if (sysDict.getParentId().equals(pid)) {
                sysDict.setChild(buildTree(list, sysDict.getId()));
                treeList.add(sysDict);
            }
        }
        return treeList;
    }
```

```
package cn.wx.tbz.core.entity;

import cn.wx.common.persistence.base.BaseEntity;
import cn.wx.tbz.core.controller.DictTree;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableName;
import lombok.Data;
import lombok.ToString;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 * <p>
 * 字典表
 * </p>
 *
 * @author stz
 * @since 2019-08-14
 */
@TableName("sys_dict")
@ToString
@Data
public class SysDict extends BaseEntity<String> {

    /**
     * 数据值
     */
    private String value;
    /**
     * 标签名
     */
    private String label;
    /**
     * 类型
     */
    private String type;

    /**
     * 类型
     */
    @TableField("type_zh")
    private String typeZh;
    /**
     * 描述
     */
    private String description;
    /**
     * 排序（升序）
     */
    private Long sort;
    /**
     * 父级编号
     */
    @TableField("parent_id")
    private String parentId;
    /**
     * 所有父级编号
     */
    @TableField("parent_ids")
    private String parentIds;
    private List<SysDict> child = new ArrayList<SysDict>();
    /**
     * 备注信息
     */
    private String remarks;

    /**
     * 数据字段别名集合
     */
    @TableField(exist = false)
    private List<SysDictAlias> dictAlias;

    @TableField(exist = false)
    private String typeName;

    /**
     * 审批状态
     * 0:未审批
     * 1: 审批通过
     */
    private Integer status;
    @TableField("name_zh")
    private String nameZh; // 中文名
    @TableField("name_en")
    private String nameEn; // 英文名
    @TableField("dict_priority")
    private Integer dictPriority; // 匹配优先级


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        SysDict sysDict = (SysDict) o;
        return Objects.equals(label, sysDict.label) &&
                Objects.equals(type, sysDict.type) &&
                Objects.equals(typeZh, sysDict.typeZh) &&
                Objects.equals(nameEn, sysDict.nameEn) &&
                Objects.equals(dictPriority, sysDict.dictPriority);
    }

    @Override
    public int hashCode() {
        return Objects.hash(label, type, typeZh, nameEn, dictPriority);
    }

    public static SysDict buildFromJSON(JSONObject jsonObject) {
        SysDict sysDict = new SysDict();
        sysDict.setValue(jsonObject.getString("value"));
        sysDict.setLabel(jsonObject.getString("label"));
        sysDict.setType(jsonObject.getString("type"));
        sysDict.setTypeZh(jsonObject.getString("typeZh"));
        sysDict.setDescription(jsonObject.getString("description"));
        sysDict.setSort(jsonObject.getLong("sort"));
        sysDict.setRemarks(jsonObject.getString("remarks"));
        sysDict.setNameZh(jsonObject.getString("nameZh"));
        sysDict.setNameEn(jsonObject.getString("nameEn"));
        sysDict.setDictPriority(jsonObject.getInteger("dictPriority"));
        JSONArray dictAlias = jsonObject.getJSONArray("dictAlias");
        List<SysDictAlias> sysDictAliasList = new ArrayList<>();
        for (Object o : dictAlias) {
            SysDictAlias sysDictAlias = SysDictAlias.buildFromJSON(JSON.parseObject(o.toString()));
            sysDictAliasList.add(sysDictAlias);
        }
        sysDict.setDictAlias(sysDictAliasList);
        return sysDict;
    }
}

```
