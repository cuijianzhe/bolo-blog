title: slf4j-log4j12 与 logback-classic 冲突及解决方式
date: '2020-07-24 13:50:33'
updated: '2020-07-24 13:50:33'
tags: [java]
permalink: /articles/2020/07/24/1595569833387.html
---
![](https://b3logfile.com/bing/20190530.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

项目中手动引入了日志jar包,但是由于是springboot项目,里头已经内置了日志组件,所以要去除内置日志组件

```
<dependency>
			<groupId>org.springframework.boot</groupId>
			<artifactId>spring-boot-starter</artifactId>
			<exclusions>
				<exclusion>
					<groupId>org.springframework.boot</groupId>
					<artifactId>spring-boot-starter-logging</artifactId>
				</exclusion>
			</exclusions>
		</dependency>
```
