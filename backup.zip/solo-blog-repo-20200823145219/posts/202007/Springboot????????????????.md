title: Springboot项目启动时读取不到配置文件怎么办？
date: '2020-07-14 19:28:34'
updated: '2020-07-14 19:28:34'
tags: [java]
permalink: /articles/2020/07/14/1594726114402.html
---
![](https://b3logfile.com/bing/20180122.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

springboot会从classpath下的/config目录或者classpath的根目录查找application.properties或application.yml！！！



把配置文件的名称改为application.properties或application.yml就能读取到了
