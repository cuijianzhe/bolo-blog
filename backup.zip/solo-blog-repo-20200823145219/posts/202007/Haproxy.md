title: Haproxy
date: '2020-07-29 20:10:07'
updated: '2020-07-29 20:10:07'
tags: [Haproxy, Linux]
permalink: /articles/2020/07/29/1596024607735.html
---
## Haproxy

### haproxy配置文件

```bash
[root@ali-pro-ops-ldap_blance ~]# cat /usr/local/haproxy/conf/haproxy.cfg
global  
	log 127.0.0.1 local3
	log 127.0.0.1 local1 notice
	stats timeout 30s
        uid 99
        gid 99
        daemon
#        nbproc 4
#        chroot /usr/local/haproxy
        pidfile /usr/local/haproxy/run/haproxy.pid
        chroot /usr/local/haproxy
defaults
	log global
	mode http
	option httplog
	option dontlognull
	timeout connect 5000
	timeout client  50000
	timeout server  50000

listen LDAP-10389
	bind 0.0.0.0:10389
	mode tcp
        option tcplog
	maxconn 2000
	timeout connect 5000
	timeout client  50000
	timeout server  50000
#	balance roundrobin
        balance leastconn 
	server LDAP1                 172.16.16.4:389                                        check inter 30000 fastinter 1000
	server LDAP2_Via_SocksProxy1 172.16.16.35:389                                        check inter 30000 fastinter 1000 

# HAProxy web ui
listen stats
	bind 0.0.0.0:20000
	mode http
	log global

	maxconn 10
	timeout client 100s
	timeout server 100s
	timeout connect 100s
	timeout queue 100s

	stats enable
	stats uri /haproxy?stats
	stats realm HAProxy\ Statistics
	stats admin if TRUE
	stats show-node
```

![image.png](https://b3logfile.com/file/2020/07/image-6b36d889.png)



参考：

1. https://www.cnblogs.com/happy1983/p/9265358.html
2. http://cbonte.github.io/haproxy-dconv/2.3/configuration.html#balance
3. https://www.cnblogs.com/nmap/p/8781296.html


