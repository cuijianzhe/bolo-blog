title: Nginx的Vhost配置
date: '2020-05-12 19:52:34'
updated: '2020-08-12 17:50:07'
tags: [Linux, nginx]
permalink: /articles/2020/05/12/1589284354518.html
---
# vhost配置文件的作用

作用：vhost配置文件的作用是为了将多个server配置文件的信息，单独存放，不过于集中在nginx.conf配置中，这样有用助于故障排除，如配置查看

**通过访问服务端nginx代理的域名可将流量转发至配置的客户机，客户机将服务端转发过来的流量转发至本机的监听相应端口的服务。**

## **nginx代理服务端：**

```shell
#网易云音乐API虚拟主机块配置
server{
    listen 80;
    server_name music163.cjzshilong.cn;
    location / {
            proxy_pass http://127.0.0.1:3001;
               }
}

# HTTPS server

server {
    listen       443 ssl;
    server_name  music163.cjzshilong.cn;

    ssl_certificate      /usr/local/nginx/conf/ssl/1_163.cjzshilong.cn_bundle.crt;
    ssl_certificate_key  /usr/local/nginx/conf/ssl/2_163.cjzshilong.cn.key;

    ssl_session_cache    shared:SSL:1m;
    ssl_session_timeout  5m;

    ssl_ciphers  ECDHE-RSA-AES128-GCM-SHA256:HIGH:!aNULL:!MD5:!RC4:!DHE;
    ssl_prefer_server_ciphers  on;

    location /{
    proxy_set_header Host $host;
    proxy_set_header Connection "Keep-Alive";
    proxy_set_header X-Real-IP $remote_addr;
    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    proxy_buffer_size 128k;
    proxy_buffers  32 32k;
    proxy_busy_buffers_size 128k;
    proxy_pass    http://127.0.0.1:3001;
    }

}
```


* try_files 将尝试你列出的文件并设置内部文件指向,try_files方法让Nginx尝试访问后面得$uri链接，并进根据@confluence配置进行内部重定向。当然try_files也可以以错误代码赋值，如try_files /index.php = 404 @confluence，则表示当尝试访问得文件返回404时，根据@confluence配置项进行重定向。

## nginx配置：

```shell
[root@vpc /usr/local/nginx/conf]# cat nginx.conf
user  www www;

error_log /var/log/nginx/error.log error;
pid       /var/run/nginx.pid;
lock_file /var/lock/nginx;

worker_rlimit_nofile 102400;
worker_processes auto;

events {
    worker_connections 10240;
    use epoll;
    multi_accept on;
    accept_mutex off;
}


http {
#core
    include         mime.types;
    default_type    application/octet-stream;
    connection_pool_size        1024;
    client_body_buffer_size     16k;
    client_body_temp_path       /usr/local/nginx/var/tmp/client_body 1 2;
    client_body_timeout         30;
    client_header_buffer_size   4k;
    large_client_header_buffers 4 4k;
    client_header_timeout       30;
    client_max_body_size        32m;
    #keepalive_disable  msie6 safari;
    keepalive_timeout   3;
    tcp_nodelay         on;
    send_timeout 30;
    sendfile    on;
    tcp_nopush  off;
    server_names_hash_max_size      512;
    server_names_hash_bucket_size   128;
    server_tokens off;
    open_file_cache off;
#index
    index   index.php index.html index.htm;
#fastcgi
    fastcgi_connect_timeout     60;
    fastcgi_read_timeout        60;
    fastcgi_send_timeout        60;
    fastcgi_temp_path           /usr/local/nginx/var/tmp/fastcgi 1 2;
    fastcgi_buffer_size         128k;
    fastcgi_buffers             2 256k;
    fastcgi_busy_buffers_size   256k;
    fastcgi_temp_file_write_size 256k;
    fastcgi_max_temp_file_size  256k;
    fastcgi_intercept_errors    on;
    fastcgi_index               index.php;
#proxy
    proxy_temp_path             /usr/local/nginx/var/tmp/proxy;
    proxy_buffer_size           4k;
    proxy_buffering             on;
    proxy_buffers               256 4k;
    proxy_busy_buffers_size     8k;
#gzip
    gzip                on;
    gzip_buffers        16 4k;
    gzip_comp_level     6;
    gzip_http_version   1.1;
    gzip_min_length     2000;
    #gzip_types         application/json application/javascript text/javascript image/png text/css text/xml text/plain text/vnd.wap.wml application/x-javascript  application/rss+xml application/xhtml+xml application/json-rpc application/jsonrequest;
    gzip_types          text/plain text/css application/json application/x-javascript text/xml application/xml application/xml+rss text/javascript image/jpeg image/gif image/png;
    gzip_vary           off;


#realip module
#    set_real_ip_from    127.0.0.1;
#    real_ip_header      X-Real-IP;
    #real_ip_header     X-Forwarded-For;
#log module
    log_format main '$remote_addr - $remote_user [$time_local] $request '
                    '"$status" $body_bytes_sent "$http_referer" '
                    '"$http_user_agent" "$http_x_forwarded_for"';

    log_format moss '$remote_addr | $http_x_forwarded_for | $remote_user | [$time_local] |'
                    ' "$request" | $status | $body_bytes_sent |'
                    ' "$http_referer" | "$http_user_agent" | $request_time | $upstream_response_time';
#ClickJacking
#    add_header X-Frame-Options SAMEORIGIN;

#virtualhost
    include vhosts/*.conf;
}
```

