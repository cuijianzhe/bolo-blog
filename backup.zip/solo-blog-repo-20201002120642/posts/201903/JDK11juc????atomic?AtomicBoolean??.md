title: JDK11-juc包系列之atomic的AtomicBoolean类(一)
date: '2019-03-23 13:59:26'
updated: '2020-08-24 20:14:21'
tags: [java]
permalink: /articles/2019/03/23/1553320766611.html
---
![11.jpg](https://img.hacpai.com/file/2019/03/11-cd6be773.jpg)

~~第一次看源码，如果有理解不对的地方希望大家可以留下评论谢谢啦。~~

理解这个类之前需要先理解[java内存模型](https://blog.csdn.net/suifeng3051/article/details/52611310)

---

### 51-63 line

```
public class AtomicBoolean implements java.io.Serializable {

    private static final long serialVersionUID = 4654671469794556979L;
    private static final VarHandle VALUE;
    static {
        try {
            MethodHandles.Lookup l = MethodHandles.lookup();
            VALUE = l.findVarHandle(AtomicBoolean.class, "value", int.class);
        } catch (ReflectiveOperationException e) {
            throw new ExceptionInInitializerError(e);
        }
    }

    private volatile int value;
```

上段代码涉及知识点：

```
1. Java9以后新增加并延续到JDK11LTS版本的变量句柄`VarHandle`
2. MethodHandles.Lookup
3. static{}代码块和内部类
4. volatile关键字
```

### 1、Java9以后新增加并延续到JDK11LTS版本的变量句柄`VarHandle`

VarHandle是对变量或参数定义的变量系列的动态强类型引用，包括静态字段，非静态字段，数组元素或堆外数据结构的组件。在各种_访问模式_下都支持访问这些变量，包括普通读/写访问，易失性读/写访问以及比较和交换。`这样理解：VarHandle利用访问模式可以用来改变AtomicBoolean的值，访问模式控制原子性和一致性属性`

访问模式分为以下几类：

* 读取访问模式，获取指定内存排序效果下的变量值。该组对应属于该组的访问模式的方法的组成的方法中[`get`](https://docs.oracle.com/javase/9/docs/api/java/lang/invoke/VarHandle.html#get-java.lang.Object...-)，[`getVolatile`](https://docs.oracle.com/javase/9/docs/api/java/lang/invoke/VarHandle.html#getVolatile-java.lang.Object...-)，[`getAcquire`](https://docs.oracle.com/javase/9/docs/api/java/lang/invoke/VarHandle.html#getAcquire-java.lang.Object...-)，[`getOpaque`](https://docs.oracle.com/javase/9/docs/api/java/lang/invoke/VarHandle.html#getOpaque-java.lang.Object...-)。
* 写入访问模式，在指定的内存排序效果下设置变量的值。该组对应属于该组的访问模式的方法的组成的方法中[`set`](https://docs.oracle.com/javase/9/docs/api/java/lang/invoke/VarHandle.html#set-java.lang.Object...-)，[`setVolatile`](https://docs.oracle.com/javase/9/docs/api/java/lang/invoke/VarHandle.html#setVolatile-java.lang.Object...-)，[`setRelease`](https://docs.oracle.com/javase/9/docs/api/java/lang/invoke/VarHandle.html#setRelease-java.lang.Object...-)，[`setOpaque`](https://docs.oracle.com/javase/9/docs/api/java/lang/invoke/VarHandle.html#setOpaque-java.lang.Object...-)。
* 原子更新访问模式，例如，在指定的内存排序效果下，原子地比较和设置变量的值。该组对应属于该组的访问模式的方法的组成的方法中[`compareAndSet`](https://docs.oracle.com/javase/9/docs/api/java/lang/invoke/VarHandle.html#compareAndSet-java.lang.Object...-)，[`weakCompareAndSetPlain`](https://docs.oracle.com/javase/9/docs/api/java/lang/invoke/VarHandle.html#weakCompareAndSetPlain-java.lang.Object...-)，[`weakCompareAndSet`](https://docs.oracle.com/javase/9/docs/api/java/lang/invoke/VarHandle.html#weakCompareAndSet-java.lang.Object...-)，[`weakCompareAndSetAcquire`](https://docs.oracle.com/javase/9/docs/api/java/lang/invoke/VarHandle.html#weakCompareAndSetAcquire-java.lang.Object...-)，[`weakCompareAndSetRelease`](https://docs.oracle.com/javase/9/docs/api/java/lang/invoke/VarHandle.html#weakCompareAndSetRelease-java.lang.Object...-)，[`compareAndExchangeAcquire`](https://docs.oracle.com/javase/9/docs/api/java/lang/invoke/VarHandle.html#compareAndExchangeAcquire-java.lang.Object...-)，[`compareAndExchange`](https://docs.oracle.com/javase/9/docs/api/java/lang/invoke/VarHandle.html#compareAndExchange-java.lang.Object...-)，[`compareAndExchangeRelease`](https://docs.oracle.com/javase/9/docs/api/java/lang/invoke/VarHandle.html#compareAndExchangeRelease-java.lang.Object...-)，[`getAndSet`](https://docs.oracle.com/javase/9/docs/api/java/lang/invoke/VarHandle.html#getAndSet-java.lang.Object...-)，[`getAndSetAcquire`](https://docs.oracle.com/javase/9/docs/api/java/lang/invoke/VarHandle.html#getAndSetAcquire-java.lang.Object...-)，[`getAndSetRelease`](https://docs.oracle.com/javase/9/docs/api/java/lang/invoke/VarHandle.html#getAndSetRelease-java.lang.Object...-)。
* 数字原子更新访问模式，例如，通过在指定的内存排序效果下添加变量的值，以原子方式获取和设置。该组的属于该组的相应的访问模式的方法包括的方法中[`getAndAdd`](https://docs.oracle.com/javase/9/docs/api/java/lang/invoke/VarHandle.html#getAndAdd-java.lang.Object...-)，[`getAndAddAcquire`](https://docs.oracle.com/javase/9/docs/api/java/lang/invoke/VarHandle.html#getAndAddAcquire-java.lang.Object...-)，[`getAndAddRelease`](https://docs.oracle.com/javase/9/docs/api/java/lang/invoke/VarHandle.html#getAndAddRelease-java.lang.Object...-)，
* 按位原子更新访问模式，例如，在指定的内存排序效果下，以原子方式获取和按位OR变量的值。该组对应属于该组的访问模式的方法的组成的方法中[`getAndBitwiseOr`](https://docs.oracle.com/javase/9/docs/api/java/lang/invoke/VarHandle.html#getAndBitwiseOr-java.lang.Object...-)，[`getAndBitwiseOrAcquire`](https://docs.oracle.com/javase/9/docs/api/java/lang/invoke/VarHandle.html#getAndBitwiseOrAcquire-java.lang.Object...-)，[`getAndBitwiseOrRelease`](https://docs.oracle.com/javase/9/docs/api/java/lang/invoke/VarHandle.html#getAndBitwiseOrRelease-java.lang.Object...-)，[`getAndBitwiseAnd`](https://docs.oracle.com/javase/9/docs/api/java/lang/invoke/VarHandle.html#getAndBitwiseAnd-java.lang.Object...-)，[`getAndBitwiseAndAcquire`](https://docs.oracle.com/javase/9/docs/api/java/lang/invoke/VarHandle.html#getAndBitwiseAndAcquire-java.lang.Object...-)，[`getAndBitwiseAndRelease`](https://docs.oracle.com/javase/9/docs/api/java/lang/invoke/VarHandle.html#getAndBitwiseAndRelease-java.lang.Object...-)，[`getAndBitwiseXor`](https://docs.oracle.com/javase/9/docs/api/java/lang/invoke/VarHandle.html#getAndBitwiseXor-java.lang.Object...-)，[`getAndBitwiseXorAcquire`](https://docs.oracle.com/javase/9/docs/api/java/lang/invoke/VarHandle.html#getAndBitwiseXorAcquire-java.lang.Object...-)，[`getAndBitwiseXorRelease`](https://docs.oracle.com/javase/9/docs/api/java/lang/invoke/VarHandle.html#getAndBitwiseXorRelease-java.lang.Object...-)。

### MethodHandles.Lookup

从上面代码可以看出，MethodHandles.Lookup调用其内部的方法产出了`VarHandle`对象。

MethodHandles.Lookup:一个查找对象是用于创建方法处理，当创建需要访问检查的工厂。方法句柄在调用它们时不执行访问检查，而是在创建它们时执行。因此，在创建方法句柄时必须强制执行方法句柄访问限制。强制执行这些限制的调用者类称为[查找类](https://docs.oracle.com/javase/9/docs/api/java/lang/invoke/MethodHandles.Lookup.html#lookupClass)。

需要创建方法句柄的查找类将调用[`MethodHandles.lookup`](https://docs.oracle.com/javase/9/docs/api/java/lang/invoke/MethodHandles.html#lookup--)为自己创建工厂。当`Lookup`被创建工厂对象，查找类的身份被确定，并安全地存储在`Lookup`对象。然后，查找类（或其委托）可以在`Lookup`对象上使用工厂方法来为访问检查的成员创建方法句柄。这包括允许查找类的所有方法，构造函数和字段，甚至是私有的。`简单理解：通过MethodHandles.Lookup反射出某方法/某对象/某成员`

查找可能会失败，因为查找类无法访问包含类，或者因为缺少所需的类成员，或者因为查找类无法访问所需的类成员，或者因为查找对象不够信任访问该成员。在任何这些情况下，`ReflectiveOperationException`都将从尝试查找中抛出。确切的类将是以下之一：

* NoSuchMethodException - 如果请求方法但不存在
* NoSuchFieldException - 如果请求了一个字段但不存在
* IllegalAccessException - 如果成员存在但访问检查失败

### static{}代码块和内部类

当类被载入时，静态代码块被执行，且只被执行一次，静态块常用来执行类属性的初始化。[java中静态代码块的用法 static用法详解](http://www.cnblogs.com/panjun-Donet/archive/2010/08/10/1796209.html)

内部类分为静态内部类，成员内部类，局部内部类，匿名内部类四种。[Java内部类详解](https://www.jianshu.com/p/e385ce41ca5b)

### volatile关键字

整个类的核心就是`volatile`关键字,它保证了变量在线程只见是可见的。[volatile和synchronized的区别](http://blog.csdn.net/suifeng3051/article/details/52611233)

