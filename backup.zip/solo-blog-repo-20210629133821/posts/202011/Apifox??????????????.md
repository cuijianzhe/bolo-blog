title: Apifox 设置跳过登录验证访问后台接口
date: '2020-11-11 15:29:02'
updated: '2020-11-11 15:49:13'
tags: [java]
permalink: /articles/2020/11/11/1605079742459.html
---
![](https://b3logfile.com/bing/20200216.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

说起api接口管理工具,我认为主要分为两种,第一种是云端的接口管理工具,是纯页面的,但是功能也相当丰富,比如api管家.另外一种可以运行客户端的接口管理工具,断网情况下也可以测试局域网接口,所以推荐使用,但是因为需要下载软件,也比云端的稍微麻烦一点,这类比较著名古老的有PostMan,国内崛起的有Apipost和Apifox,这些客户端接口管理工具我都用过,更推荐Apifox一些,原因有二:

* Apifox体积更小,运行更流畅,Apipost很笨重,经常出现保存一下不管用的bug
* 多人协作Apifox没有人数限制,Apipost多人协作只有两个工位

Apipost的优点:

* 接口文档好用,可以生成实时文档网页链接,供他人查看,很方便,这点apifox是没有的
* Apipost可以进行沙盒测试和压力测试,这点apifox也没有它做的好
* 总之就是apifox满足基本功能,但是轮功能的丰富程度,还得是apipost,但它太笨重了,期待apifox的崛起

那么用Apifox的时候,如何跳过登录验证呢?


1. 设置cookie参数
   ![设置cookie.png](https://b3logfile.com/file/2020/11/设置cookie-9b731de8.png)

2.此cookie参数可以从redis中查看获取,也可以从F12浏览器调试的Application->Cookies 中获取
![shiroCookie.png](https://b3logfile.com/file/2020/11/shiroCookie-3a0725b2.png)

