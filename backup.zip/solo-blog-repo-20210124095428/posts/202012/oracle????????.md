title: oracle创建用户和表空间
date: '2020-12-02 16:10:51'
updated: '2020-12-03 09:25:38'
tags: [oracle]
permalink: /articles/2020/12/02/1606896650958.html
---
![](https://b3logfile.com/bing/20180716.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)
/* 删除用户,如果之前创建过此名称用户的话的话 */
drop user username cascade;

/* 删除表空间及对应的表空间文件,这个命令好用,但是不会删除磁盘上的bdf文件,如果需要的话,可以手动删除bdf文件来释放硬盘空间 */
drop tablespace tablespacename including contents and datafiles cascade contraint;


/* 查询表空间的物理地址路径,为了在第1步设置本地存储文件时使用*/

select
tablespace_name,
file_id, file_name,
round(bytes/(1024*1024),0) total_space
from
dba_data_files
order by tablespace_name;

/* 彻底删除表,如果之前创建过想重新创建的话 */

select 'drop table '||table_name ||';'  as dropsql from USER_TABLES where

table_name like 'CLASS%';
drop table tb_maintence purge;

/*第1步：创建数据表空间  */

create tablespace tablespace_here

logging

datafile 'E:\oracle\product\10.2.0\oradata\dbf_here.dbf'

size 200m

autoextend on

next 200m maxsize 20480m

extent management local;

/*第2步：创建用户并指定表空间  */

create user username_here identified by password_here

default tablespace tablespace_here;

/*第3步：给用户授予权限  */

grant connect,resource,dba to username_here;

