title: Mybatis一级缓存总结
date: '2021-08-11 22:49:41'
updated: '2022-03-30 16:22:53'
tags: [mybatis]
permalink: /articles/2021/07/23/1628692149983.html
---
![](https://b3logfile.com/bing/20201103.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

##### Mybatis一级缓存的相关概念参考网址

https://blog.csdn.net/weixin_39035120/article/details/106448300

https://blog.csdn.net/luanlouis/article/details/41280959

##### 自我总结

**当设置localCacheScope为SESSION的时候：**

* 不用spting管理，mybatis是使用一级缓存的，因为是同一个SESSION
* 当用spring管理的时候，如果没使用事务，则使用的是两个SESSION，则不使用一级缓存。当用spring管理的时候，如果使用事务，则使用的是同一个SESSION，同一个SESSION的情况下，如果设置mybatis-config.xml里的配置属性localCacheScope为STATMENT的时候，不使用一级缓存，设置属性localCacheScope为SESSION(默认)的时候，使用一级缓存
  
  ![微信图片20210811222728.png](https://b3logfile.com/file/2021/08/微信图片_20210811222728-498e614a.png)

