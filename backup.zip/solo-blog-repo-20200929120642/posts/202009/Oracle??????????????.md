title: Oracle中查看最近被修改过的表的方法
date: '2020-09-27 15:49:14'
updated: '2020-09-27 15:49:14'
tags: [oracle]
permalink: /articles/2020/09/27/1601192953949.html
---
![](https://b3logfile.com/bing/20180408.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

有时候，写着写着项目，因为功能需要，改了数据库，但是回头上线的时候，发现都忘记改了哪些表的哪些字段了。emmm

```java
SELECT
	uat.table_name AS 表名,
	( SELECT last_ddl_time FROM user_objects WHERE object_name = uat.table_name ) AS last_ddl_time 
FROM
	user_all_tables uat 
ORDER BY
	last_ddl_time DESC
```

