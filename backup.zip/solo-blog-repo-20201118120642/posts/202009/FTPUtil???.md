title: FTPUtil工具类
date: '2020-09-18 09:27:22'
updated: '2020-09-18 09:27:22'
tags: [ftp]
permalink: /articles/2020/09/18/1600392442485.html
---
![](https://b3logfile.com/bing/20190517.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

### 调用代码：

```java
//本地文件

File file =  new File(uploadPath + pictureName);
//远端ftp目标路径
String remotePath= "/";
//使用ftp工厂里的哪一个ftp进行上传，这个没啥用，就默认用0就行
Integer ftpNum = 0;
//上传到ftp

FTPUtil.uploadFile(ftpNum, remotePath, file);
```

### 所有有关类的代码打包，解压即可

[FTPUtil.rar](https://b3logfile.com/file/2020/09/FTPUtil-e31f3920.rar)



