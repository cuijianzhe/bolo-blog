title: 你还在用三目运算符来处理null值吗？
date: '2021-01-12 13:59:17'
updated: '2021-01-12 14:28:31'
tags: [java]
permalink: /articles/2021/01/12/1610431157208.html
---
![](https://b3logfile.com/bing/20191025.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

#### 三目运算符如何处理null值？

三目运算的一般形式a==null ? b : c

a = null,结果为b
a != null,结果为c

---

JDK1.8提供了一个`Optional.java`类来处理类似情况
`Optional.ofNullable(value).orElse(0)`，就可以实现想要的效果

