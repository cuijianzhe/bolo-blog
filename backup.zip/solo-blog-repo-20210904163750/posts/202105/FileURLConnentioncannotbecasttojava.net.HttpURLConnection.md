title: FileURLConnention cannot be cast to java.net.HttpURLConnection
date: '2021-05-27 16:18:36'
updated: '2021-05-27 16:18:36'
tags: [java]
permalink: /articles/2021/05/27/1622103516441.html
---
![](https://b3logfile.com/bing/20180430.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

是因为调用远程http的时候，yaml文件中漏配了ip和port，加上就好了，不加上的话，看起来就像是一个FileURL

