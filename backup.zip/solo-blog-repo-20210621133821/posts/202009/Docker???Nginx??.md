title: Docker里部署Nginx镜像
date: '2020-09-02 11:08:56'
updated: '2020-09-02 11:46:33'
tags: [nginx]
permalink: /articles/2020/09/02/1599016529798.html
---
![](https://b3logfile.com/bing/20181223.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

```
docker pull nginx 拉取镜像
```

```
mkdir -p /data/nginx/{conf,conf.d,html,log}  创建宿主机挂载目录
```

#### 编辑nginx.conf文件，并置于上述创建的conf目录下

```python
server {
        listen       5001;
        server_name    localhost;
	root   /usr/share/nginx/html; #此处的root是对应的docker容器里的地址
        index   index.html;
}
```

```python
docker run
--name my_nginx
-d -p 80:80
-v /data/nginx/conf/nginx.conf:/etc/nginx/nginx.conf \   冒号前面的是本机地址，冒号后面的是docker容器里的地址
-v /data/nginx/log:/var/log/nginx
-v /data/nginx/html:/usr/share/nginx/html
nginx
```

