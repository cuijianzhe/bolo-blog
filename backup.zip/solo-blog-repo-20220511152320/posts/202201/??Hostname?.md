title: 修改Hostname值
date: '2022-01-27 10:37:52'
updated: '2022-01-27 10:37:52'
tags: [zabbix]
permalink: /articles/2022/01/27/1643251072876.html
---
```sh
#!/bin/bash 

hostname=`hostname`
old_hostname=`grep -Ev '^$|^#' /etc/zabbix/zabbix_agentd.conf  | grep Hostname`
sed -i "s#$old_hostname#Hostname=$hostname#g" /etc/zabbix/zabbix_agentd.conf
systemctl restart zabbix-agent
```

下发：

```
ansible -i hosts.work  new-openstack  -m shell -a "netstat -lntup | grep 10050"
ansible -i hosts.work  new-openstack-ceph  -m shell -a "cat /etc/zabbix/zabbix_agentd.conf | grep 172.24.15.122"
ansible -i hosts.work  new-openstack -m copy -a "src=/root/test.sh dest=/tmp/test.sh"
ansible -i hosts.work  new-openstack  -m shell -a "sh /tmp/test.sh"
```

