title: 截取List进行分页
date: '2021-07-16 11:10:00'
updated: '2021-07-16 11:10:00'
tags: [java]
permalink: /articles/2021/07/16/1626405000724.html
---
![](https://b3logfile.com/bing/20210203.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

```java
package com.clamc.climb;
import cn.hutool.core.collection.CollUtil;
import com.google.common.collect.Lists;
import lombok.Data;

import java.util.ArrayList;
import java.util.List;

/**
 * 截取List进行分页
 *
 * @author xuyt
 * @date 2021.7.16
 */
public class TestPageList {
	public static void main(String[] args) {
	  List<String> strList = new ArrayList<>();
	  strList.add("中");
	  strList.add("华");
	  strList.add("人")； 
	  strList.add("民")； 
	  strList.add("共");
	  strList.add("和");
	  strList.add("国");
	  strList.add("万");
	  strList.add("岁");
	  System.out.println(pageList(3, 2, strList));
	}

	/**
	 * 对list进行分页截取
	 * 从左往右,第一个T表示参数包括泛型参数,第二个T表示返回T类型的数据,第三个T限制参数是类型为T
	 *
	 * @param pageNow 当前页
	 * @param pageSize 分页长度
	 * @param list 数据集
	 * @param <T> 泛型
	 * @return 分页后的数据
	 */
	public static <T> PageVo pageList(int pageNow. int pageSize. List<T> list) {
		if (CollUtil.isEnpry(List) || pageNow == 0 || pageSize == 0) {
          PageVo pageVo = new PageVoO;
          pageVo.setPageNow(O);
          pageVo.setPageSize(0);
          pageVo.setTotalPage(O);
          pageVo.setRowDataList(Lists.neiv4rrayList());
          pageVo.setTotalNum(0);
          return pageVo;
		}
        if (pageNow < 1) {
        	paqeNow = 1;
        }
        if (pageSize < 0) {
        	paqeSize = 10;
        }
	
	//取模，如果有余数,totalPage + 1
        int i = list.size() % paqeSize:
        int totalPaqe = list.size() / paqeSize: 
        if (i != O) {
        	totalPaqe = totalPaqe + 1;
        }
        if (paqeNow > totalPaqe) { 
        	paqeNow = totalPaqe:
        }
        int startindex = (paqeNow - 1) * paqeSize:
        int endindex = startindex + paqeSize:
        int totalNum = list.size();
        if (endindex > totalNum) { 
        	endindex = totalNum;
        }
        PageVo pageVo = new PageVoO;
        paqeVo.setPaqeNow(paqeNow);
        pageVo.setPaqeSize(paqeSize);
        paqeVo.setTotalPaqe(totalPaqe);
        pageVo.setRowDataList(list.subList(startindex, endindex)); 
        pageVo.setTotalNum(totalNum);
        return pageVo;
	}
}

@Data
class PageVo {
	private int pageNow;
	private int pageSize;
	private int totalPage;
	private List <?> rowDataList;
	private int totalNum;
}
```

