title: RabbitMQ单机实装简单测试
date: '2022-03-10 16:12:31'
updated: '2022-03-10 16:12:31'
tags: [RabbitMQ]
permalink: /articles/2022/03/10/1646899951655.html
---
![](https://b3logfile.com/bing/20210413.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

##### 安装erlang

在 `http://www.rabbitmq.com/which-erlang.html` 页面查看安装rabbitmq需要安装erlang对应的
版本

在 `https://github.com/rabbitmq/erlang-rpm/releases` 页面找到需要下载的erlang版本，
erlang-*.centos.x86_64.rpm 就是centos版本的。

* 复制下载地址后，使用wget命令下载

`wget -P /erlang https://github.com/rabbitmq/erlang-rpm/releases/download/v21.2.3/erlang-21.2.3-1.el7.centos.x86_64.rpm`

* 安装 Erlang

`sudo rpm -Uvh /erlang/erlang-21.2.3-1.el7.centos.x86_64.rpm`

* 安装 socat

`sudo yum install -y socat`

##### 安装RabbitMQ

下载

`wget -P /RabbitMQ https://github.com/rabbitmq/rabbitmq-server/releases/download/v3.7.9/rabbitmq-server-3.7.9-1.el7.noarch.rpm`

安装

`sudo rpm -Uvh /RabbitMQ/rabbitmq-server-3.7.9-1.el7.noarch.rpm`

##### 启动和关闭

* 启动服务

`sudo systemctl start rabbitmq-server`

* 查看状态

`sudo systemctl status rabbitmq-server`

* 停止服务

`sudo systemctl stop rabbitmq-server`

* 设置开机启动

`sudo systemctl enable rabbitmq-server`

##### 开启Web管理插件

* 开启插件

`rabbitmq-plugins enable rabbitmq_management`

* 添加用户

**说明：rabbitmq有一个默认的guest用户，但只能通过localhost访问，所以需要添加一个能够
远程访问的用户。**

`rabbitmqctl add_user admin admin`

* 为用户分配操作权限

`rabbitmqctl set_user_tags admin administrator`

* 为用户分配资源权限

`rabbitmqctl set_permissions -p / admin "." "." ".*"`

##### 防火墙添加端口

<kbd>(如果是阿里云主机所有端口全开放可以跳过此步骤)</kbd>

RabbitMQ 服务启动后，还不能进行外部通信，需要将端口添加都防火墙

* 添加端口
  `sudo firewall-cmd --zone=public --add-port=4369/tcp --permanent sudo firewall-cmd --zone=public --add-port=5672/tcp --permanent sudo firewall-cmd --zone=public --add-port=25672/tcp --permanent sudo firewall-cmd --zone=public --add-port=15672/tcp --permanent`
* 重启防火墙

`sudo firewall-cmd --reload`

##### rabbitmq基本配置

<kbd>RabbitMQ 有一套默认的配置，能够满足日常开发需求，如果需要修改，需要自己创建一个配置文件
touch /etc/rabbitmq/rabbitmq.conf</kbd>

配置文件示例：
`https://github.com/rabbitmq/rabbitmq-server/blob/master/deps/rabbit/docs/rabbitmq.conf.exam ple`

配置项说明：
`https://www.rabbitmq.com/configure.html#config-items`

##### hello world

RabbitMQ 支持多种语言访问，以 Java 为例看下一般使用 RabbitMQ 的步骤。

* maven工程的pom文件中添加依赖

```xml
<dependency>
    <groupId>com.rabbitmq</groupId>
    <artifactId>amqp-client</artifactId>
    <version>4.1.0</version>
</dependency>
```

##### 生产者代码

```java
package com.example.demo.RabbitMQ;

import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;

import java.io.IOException;
import java.util.concurrent.TimeoutException;

public class Producer {

    public static void main(String[] args) throws IOException, TimeoutException {
        //创建连接工厂
        ConnectionFactory factory = new ConnectionFactory();
        factory.setUsername("admin");
        factory.setPassword("admin");
        //设置 RabbitMQ 地址
        factory.setHost("xx.xx.xx.xx");
        //建立到代理服务器到连接
        Connection conn = factory.newConnection();
        //获得信道
        Channel channel = conn.createChannel();
        //声明交换器
        String exchangeName = "hello-exchange";
        channel.exchangeDeclare(exchangeName, "direct", true);
        String routingKey = "hola";
        //发布消息
        byte[] messageBodyBytes = "消息1".getBytes();
        channel.basicPublish(exchangeName, routingKey, null, messageBodyBytes);
        channel.close();
        conn.close();
    }
}
```

##### 消费者代码

```java
package com.example.demo.RabbitMQ;

import com.rabbitmq.client.*;

import java.io.IOException;
import java.util.concurrent.TimeoutException;

public class Consumer {
    public static void main(String[] args) throws IOException, TimeoutException {
        ConnectionFactory factory = new ConnectionFactory();
        factory.setUsername("admin");
        factory.setPassword("admin");
        factory.setHost("xx.xx.xx.xx");
        //建立到代理服务器到连接
        Connection conn = factory.newConnection();
        //获得信道
        final Channel channel = conn.createChannel();
        //声明交换器
        String exchangeName = "hello-exchange";
        channel.exchangeDeclare(exchangeName, "direct", true);
        //声明队列
        String queueName = channel.queueDeclare().getQueue();
        String routingKey = "hola";
        //绑定队列，通过键 hola 将队列和交换器绑定起来
        channel.queueBind(queueName, exchangeName, routingKey);
        while (true) {
        //消费消息
            boolean autoAck = false;
            String consumerTag = "";
            channel.basicConsume(queueName, autoAck, consumerTag, new
                    DefaultConsumer(channel) {
                        @Override
                        public void handleDelivery(String consumerTag,
                                                   Envelope envelope,
                                                   AMQP.BasicProperties properties,
                                                   byte[] body) throws IOException {
                            String routingKey = envelope.getRoutingKey();
                            String contentType = properties.getContentType();
                            System.out.println("消费的路由键：" + routingKey);
                            System.out.println("消费的内容类型：" + contentType);
                            long deliveryTag = envelope.getDeliveryTag();
                            //确认消息
                            channel.basicAck(deliveryTag, false);
                            System.out.println("消费的消息体内容：");
                            String bodyStr = new String(body, "UTF-8");
                            System.out.println(bodyStr);
                        }
                    });
        }
    }
}
```



