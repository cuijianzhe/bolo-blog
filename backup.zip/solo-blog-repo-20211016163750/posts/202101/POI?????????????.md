title: POI设置单元格为下拉框数据格式
date: '2021-01-06 09:53:29'
updated: '2021-01-08 16:29:29'
tags: [java]
permalink: /articles/2021/01/06/1609898009691.html
---
![](https://b3logfile.com/bing/20181105.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

#### HSSF版本

```
public void dropDownBox(Workbook wb, int size) {
        Sheet oneSheet = wb.getSheetAt(0);
        //为指定范围内的单元格添加下拉框样式
        CellRangeAddressList cas = new CellRangeAddressList(1, size, 4, 4);
        //创建下拉数据列
        String[] str = new String[]{"技术管理","专业管理","生产技能","其他"};
        DVConstraint dvConstraint = DVConstraint.createExplicitListConstraint(str);
        //将下拉数据放入下拉框
        HSSFDataValidation dataValidation = new HSSFDataValidation(cas, dvConstraint);
        dataValidation.createErrorBox("错误", "请选择下拉框的值");
        dataValidation.setShowErrorBox(true);
        oneSheet.addValidationData(dataValidation);
    }
```

---

#### XSSH版本

```
public void dropDownBox(Workbook wb, int size) {
        XSSFSheet oneSheet = (XSSFSheet)wb.getSheetAt(0);
        //创建下拉数据列
        String[] str = new String[]{"统一转账","现场缴费","统一转账+现场缴费","其他"};

        XSSFDataValidationHelper dvHelper = new XSSFDataValidationHelper(oneSheet);
        XSSFDataValidationConstraint dvConstraint = (XSSFDataValidationConstraint) dvHelper
                .createExplicitListConstraint(str);
        CellRangeAddressList addressList = null;
        XSSFDataValidation validation = null;

        addressList = new CellRangeAddressList(3, 2 + size, 8, 8);
        validation = (XSSFDataValidation) dvHelper.createValidation(
                dvConstraint, addressList);
        validation.createErrorBox("错误", "请选择下拉框的值");
        validation.setShowErrorBox(true);
        oneSheet.addValidationData(validation);
    }
```

