title: 总结归纳Spring的注解
date: '2021-11-24 22:07:29'
updated: '2022-03-30 16:25:15'
tags: [java]
permalink: /articles/2021/11/24/1637762849451.html
---
![](https://b3logfile.com/bing/20210525.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

##### 1.配置组件

| 注解名称 | 说明 |
| --- | --- |
| @Configuration | 把一个类作为一个IoC容器,它的某个方法头上如果注册了@Bean,就会作为这个Spring容器中的Bean |
| @ComponentScan | 该注解默认会扫描该类所在的包下所有的配置类.相当于"context:component-scan" |
| @Scope | 用于指定scope作用域的(用在类上) |
| @Lazy | 表示延迟初始化 |
| @Conditional | 按照一定条件进行判断,满足条件给容器注册Bean |
| @Import | 导入外部资源 |
| 生命周期控制 | @PostConstruct用于初始化,@PreDestory用于销毁,@DependsOn定义Bean初始化及销毁时的顺序 |

##### 2.赋值组件

| 注解名称 | 说明 |
| --- | --- |
| @Component | 泛指组件,当组件不好归类时,用它 |
| @Service | 用于标注业务层组件 |
| @Controller | 用于标注控制层组件 |
| @Repository | 用于标注数据访问组件,即DAO组件 |
| @Value | 普通数据类型赋值 |
| @Autowired | 默认按类型装配 |
| @PropertySource | 读取配置文件赋值 | 
| @Qualifier | 如存在多个实例配合使用 |
| @Primary | 自动装配时多个同名称Bean,会报异常,加上它会提升优先级不报异常 |
| @Resource | 默认按名称装配,当找不到与名称匹配的bean才会按类型装配 |

#### 3.织入组件

| 注解名称 | 说明 |
| --- | --- |
| ApplicationContextAware | 可以通过这个上下文环境对象得到Spring容器中的bean |
| BeanDefinitionRegistryPostProcessor | 它实现了BeanFactoryPostProcessor接口,是Spring框架的BeanDefinitionRegistry的后处理器,用来注册额外的BeanDefinition |

#### 4.切面组件

| 注解名称 | 说明 |
| --- | --- |
| @EnableTransactionManagement | 添加对事务管理的支持 |
| @Transactional | 配置声明式事务信息 |

