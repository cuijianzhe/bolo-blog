title: 将SpringBoot项目发布到Docker
date: '2020-02-05 20:48:20'
updated: '2020-02-05 20:48:20'
tags: [java]
permalink: /articles/2020/02/05/1580906900027.html
---
![](https://img.hacpai.com/bing/20190813.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

### 1.将SpringBoot项目打jar包
pom.xml增加`spring-boot-maven-plugin`插件
使用右侧maven-Lifecycle-package打jar包
使用`java -jar *-1.0.0.jar`测试可用

### 2.新建Dockerfile
```
FROM java:8
VOLUME /tmp
ADD love-0.0.1-SNAPSHOT.jar /love.jar
ENTRYPOINT["java","-Djava.security.egd=file:/dev/./urandom","-jar","/love.jar"]
```

### 3.将jar包拷贝到和Dockerfile同文件夹

### 4.创建镜像
```
docker build -f /usr/local/lovecaining/Dockerfile -t lovecaining
```

### 5.运行镜像
```
docker run -d -p 8088:8088 --name lovecaining lovecaining
```
