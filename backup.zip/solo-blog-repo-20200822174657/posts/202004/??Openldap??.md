title: 配置Openldap主从
date: '2020-04-16 16:43:22'
updated: '2020-04-18 09:42:09'
tags: [Linux, Openldap]
permalink: /articles/2020/04/16/1587026602880.html
---

> **公司有一台单点ldap服务器，为了账户备份以及灾备，搭建从服务器。**

**首先找两台机器：**
| ip | 角色 | 备注 |
| --- | --- | --- |
| 10.200.51.83 | ldap-master |  |
| 10.200.51.85 | ldap-slave |  |

**系统:**
```
[root@ldap-slave ~]# cat /etc/redhat-release 
CentOS Linux release 7.7.1908 (Core)
```
**配置yum源：**

`wget -O /etc/yum.repos.d/CentOS-Base.repo http://mirrors.aliyun.com/repo/Centos-7.repo`

**主机名修改：**
`
hostnamectl set-hostname ldap-master
`

## **安装OpenLDAP**
**master和slave都需要执行安装和基本数据配置**

`
yum -y install openldap compat-openldap openldap-clients openldap-servers openldap-servers-sql openldap-devel
`

```
[root@ldap-master ~]# systemctl enable --now slapd
[root@ldap-master ~]# slapd -VV 
@(#) $OpenLDAP: slapd 2.4.44 (Jan 29 2019 17:42:45) $
	mockbuild@x86-01.bsys.centos.org:/builddir/build/BUILD/openldap-2.4.44/openldap-2.4.44/servers/slapd
```

## **配置OpenLDAP**
### 生成LDAP管理员密码
```
[root@ldap-master ~]# slappasswd -s limikeji
{SSHA}LxwE7ndCNs3aE58ufW48/v7ziKKcbtEb
```
###  **修改openldap的基本配置**

**设定数据库：**
```
cat > db.ldif <<EOF
dn: olcDatabase={2}hdb,cn=config
changetype: modify
replace: olcSuffix
olcSuffix: dc=limikeji,dc=com

dn: olcDatabase={2}hdb,cn=config
changetype: modify
replace: olcRootDN
olcRootDN: cn=root,dc=limikeji,dc=com

dn: olcDatabase={2}hdb,cn=config
changetype: modify
replace: olcRootPW
olcRootPW:{SSHA}LxwE7ndCNs3aE58ufW48/v7ziKKcbtEb
EOF
```


>   #olcRootPW使用上面生成的密码


```
[root@ldap-master ~]#  ldapmodify -Y EXTERNAL -H ldapi:/// -f db.ldif
SASL/EXTERNAL authentication started
SASL username: gidNumber=0+uidNumber=0,cn=peercred,cn=external,cn=auth
SASL SSF: 0
modifying entry "olcDatabase={2}hdb,cn=config"

modifying entry "olcDatabase={2}hdb,cn=config"

modifying entry "olcDatabase={2}hdb,cn=config"
```

> 修改`/etc/openldap/slapd.d/cn=config/olcDatabase={1}monitor.ldif`, 不需要手动修改文件，使用更新配置的方式更改。

```
cat > monitor.ldif <<EOF
dn: olcDatabase={1}monitor,cn=config
changetype: modify
replace: olcAccess
olcAccess: {0}to * by dn.base="gidNumber=0+uidNumber=0,cn=peercred,cn=external, cn=auth" read by dn.base="cn=root,dc=limikeji,dc=com" read by * none
EOF
```

```
[root@ldap-master ~]# ldapmodify -Y EXTERNAL -H ldapi:/// -f monitor.ldif
SASL/EXTERNAL authentication started
SASL username: gidNumber=0+uidNumber=0,cn=peercred,cn=external,cn=auth
SASL SSF: 0
modifying entry "olcDatabase={1}monitor,cn=config"
```

**配置ldap数据库**
`cp /usr/share/openldap-servers/DB_CONFIG.example /var/lib/ldap/DB_CONFIG
`

**导入基础schema**

```
ldapadd -Y EXTERNAL -H ldapi:/// -f /etc/openldap/schema/cosine.ldif
ldapadd -Y EXTERNAL -H ldapi:/// -f /etc/openldap/schema/nis.ldif 
ldapadd -Y EXTERNAL -H ldapi:/// -f /etc/openldap/schema/inetorgperson.ldif
```

**配置openldap基础数据库**

```
cat > base.ldif <<EOF
dn: dc=limikeji,dc=com
dc: limikeji
objectClass: top
objectClass: domain

dn: cn=root,dc=limikeji,dc=com
objectClass: organizationalRole
cn: Manager
description: LDAP Manager

dn: ou=People,dc=limikeji,dc=com
objectClass: organizationalUnit
ou: People

dn: ou=Group,dc=limikeji,dc=com
objectClass: organizationalUnit
ou: Group

EOF
```
```
[root@ldap-master ~]# ldapadd -x -w limikeji -D "cn=root,dc=limikeji,dc=com" -f base.ldif
adding new entry "dc=limikeji,dc=com"

adding new entry "cn=root,dc=limikeji,dc=com"

adding new entry "ou=People,dc=limikeji,dc=com"

adding new entry "ou=Group,dc=limikeji,dc=com"
```

**开启日志**
```
cat > loglevel.ldif << EOF
dn: cn=config
changetype: modify
replace: olcLogLevel
olcLogLevel: stats
EOF
```
```
[root@ldap-master ~]# ldapmodify -Y EXTERNAL -H ldapi:/// -f loglevel.ldif
SASL/EXTERNAL authentication started
SASL username: gidNumber=0+uidNumber=0,cn=peercred,cn=external,cn=auth
SASL SSF: 0
modifying entry "cn=config"
```

```
[root@ldap-master ~]# echo 'local4.* /var/log/slapd.log' >> /etc/rsyslog.conf
[root@ldap-master ~]# systemctl restart rsyslog
[root@ldap-master ~]# systemctl restart slapd
```

## **配置master**

**创建一个对所有LDAP对象具有读访问权限的用户,用作`slave`访问`master`**

```
 cat > rpuser.ldif <<EOF
dn: uid=repl,dc=limikeji,dc=com
objectClass: simpleSecurityObject
objectclass: account
uid: repl
description: Replication User
userPassword: limikeji
EOF
```

```
[root@ldap-master ~]# ldapadd -x -w limikeji -D "cn=root,dc=limikeji,dc=com" -f rpuser.ldif
adding new entry "uid=repl,dc=limikeji,dc=com"
```

**开启syncprov module**

```
cat >syncprov_mod.ldif <<EOF
dn: cn=module,cn=config
objectClass: olcModuleList
cn: module
olcModulePath: /usr/lib64/openldap
olcModuleLoad: syncprov.la
EOF
```
```
[root@ldap-master ~]# ldapadd -Y EXTERNAL -H ldapi:/// -f syncprov_mod.ldif
SASL/EXTERNAL authentication started
SASL username: gidNumber=0+uidNumber=0,cn=peercred,cn=external,cn=auth
SASL SSF: 0
adding new entry "cn=module,cn=config"
```

**为每个目录开启syncprov**

```
cat >syncprov.ldif <<EOF
dn: olcOverlay=syncprov,olcDatabase={2}hdb,cn=config
objectClass: olcOverlayConfig
objectClass: olcSyncProvConfig
olcOverlay: syncprov
olcSpSessionLog: 100
EOF
```
```
[root@ldap-master ~]# ldapadd -Y EXTERNAL -H ldapi:/// -f syncprov.ldif
SASL/EXTERNAL authentication started
SASL username: gidNumber=0+uidNumber=0,cn=peercred,cn=external,cn=auth
SASL SSF: 0
adding new entry "olcOverlay=syncprov,olcDatabase={2}hdb,cn=config"
```

## **配置slave**
**配置同步**
```
cat >syncrepl.ldif <<EOF
dn: olcDatabase={2}hdb,cn=config
changetype: modify
add: olcSyncRepl
olcSyncRepl: rid=001
  provider=ldap://10.200.51.83:389/
  bindmethod=simple
  binddn="uid=repl,dc=limikeji,dc=com"
  credentials=limikeji
  searchbase="dc=limikeji,dc=com"
  scope=sub
  schemachecking=on
  type=refreshAndPersist
  attrs="*,+"
  retry="30 5 300 3"
  interval=00:00:05:00
EOF
```
```
[root@ldap-slave ~]# ldapmodify -Y EXTERNAL  -H ldapi:/// -f syncrepl.ldif
SASL/EXTERNAL authentication started
SASL username: gidNumber=0+uidNumber=0,cn=peercred,cn=external,cn=auth
SASL SSF: 0
modifying entry "olcDatabase={2}hdb,cn=config"
```
> 其中provider表示master的地址，其他的都是些基础信息。**不过这里面需要注意的是认证用户一定要使用超级管理员，** 如果使用普通用户连接master的话，slave将不会同步用户的密码字段信息。
* attrs="*,+"     #同步所有属性
*  schemachecking=on   #同步更新时开启语法检测
 
### **测试LDAP的主从复制**

**在master上添加测试账号**
```
cat > ldaptest.ldif << EOF
dn: uid=repltest,ou=People,dc=limikeji,dc=com
uid: repltest
cn: repltest
sn: repltest
mail: repltest@limikeji.com
objectClass: person
objectClass: organizationalPerson
objectClass: inetOrgPerson
objectClass: posixAccount
objectClass: top
objectClass: shadowAccount
userPassword: limikeji
shadowLastChange: 17763
shadowMin: 0
shadowMax: 99999
shadowWarning: 7
loginShell: /bin/bash
uidNumber: 1099
gidNumber: 1099
homeDirectory: /home/repltest
EOF
```
```
[root@ldap-master ~]# ldapadd -x -w limikeji -D "cn=root,dc=limikeji,dc=com" -f ldaptest.ldif
adding new entry "uid=repltest,ou=People,dc=limikeji,dc=com"
```

**在slave中搜索用户**

```
[root@ldap-slave ~]# ldapsearch -x cn=repltest -b dc=limikeji,dc=com
# extended LDIF
#
# LDAPv3
# base <dc=limikeji,dc=com> with scope subtree
# filter: cn=repltest
# requesting: ALL
#

# repltest, People, limikeji.com
dn: uid=repltest,ou=People,dc=limikeji,dc=com
uid: repltest
cn: repltest
sn: repltest
mail: repltest@limikeji.com
objectClass: person
objectClass: organizationalPerson
objectClass: inetOrgPerson
objectClass: posixAccount
objectClass: top
objectClass: shadowAccount
userPassword:: bGltaWtlamk=
shadowLastChange: 17763
shadowMin: 0
shadowMax: 99999
shadowWarning: 7
loginShell: /bin/bash
uidNumber: 1099
gidNumber: 1099
homeDirectory: /home/repltest

# search result
search: 2
result: 0 Success

# numResponses: 2
# numEntries: 1
```

### 同时可通过日志模块查看相关info输出（可看出正在同步信息）
```
[root@ldap-master ~]# tail -f 30 /var/log/slapd.log
tail: cannot open ‘30’ for reading: No such file or directory
==> /var/log/slapd.log <==
Apr 16 04:14:21 ldap-master slapd[13230]: slapd shutdown: waiting for 0 operations/tasks to finish
Apr 16 04:14:21 ldap-master slapd[13230]: slapd stopped.
Apr 16 04:14:21 ldap-master slapd[13289]: @(#) $OpenLDAP: slapd 2.4.44 (Jan 29 2019 17:42:45) $#012#011mockbuild@x86-01.bsys.centos.org:/builddir/build/BUILD/openldap-2.4.44/openldap-2.4.44/servers/slapd
Apr 16 04:14:21 ldap-master slapd[13291]: slapd starting
Apr 16 04:14:29 ldap-master slapd[13291]: conn=1000 fd=11 ACCEPT from IP=10.200.51.85:59884 (IP=0.0.0.0:389)
Apr 16 04:14:29 ldap-master slapd[13291]: conn=1000 op=0 BIND dn="uid=repl,dc=limikeji,dc=com" method=128
Apr 16 04:14:29 ldap-master slapd[13291]: conn=1000 op=0 BIND dn="uid=repl,dc=limikeji,dc=com" mech=SIMPLE ssf=0
Apr 16 04:14:29 ldap-master slapd[13291]: conn=1000 op=0 RESULT tag=97 err=0 text=
Apr 16 04:14:29 ldap-master slapd[13291]: conn=1000 op=1 SRCH base="dc=limikeji,dc=com" scope=2 deref=0 filter="(objectClass=*)"
Apr 16 04:14:29 ldap-master slapd[13291]: conn=1000 op=1 SRCH attr=* +
```

参考：
https://www.ilanni.com/?cat=1035
https://www.cnblogs.com/hope123/p/12083552.html
https://www.openldap.org/
https://blog.csdn.net/htvxjl02/article/details/80336788
