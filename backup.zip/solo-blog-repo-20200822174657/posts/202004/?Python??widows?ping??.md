title: 用Python实现widows下ping程序
date: '2020-04-18 13:43:21'
updated: '2020-04-20 10:14:19'
tags: [Python]
permalink: /articles/2020/04/18/1587188601330.html
---
# 背景
公司直播间直播课程，有时会出现发题、金币刷新等卡顿问题，为了解释不是网络而是接口或者服务问题，此程序诞生。
因为不带**多线程**版本ping程序挂钩多个ip的话，容易出现时间缺失（如下），所以加上多线程，同时程序简化了很多……
![image.png](https://img.hacpai.com/file/2020/04/image-b819cf9c.png)

# 带多线程ping指定主机
```python
#!/bin/python3
#######################################################
# This program is to check the ping in the Live Room  #
# Date: 2020-4-21                                     #
# Author: cuijianzhe                                  #
# Email: 598941324@qq.com                             #
#######################################################
import threading
import os
import subprocess
import re
import datetime as dt
import time

def ping_host(ip):
    nowdate = dt.datetime.now().strftime('%Y%m%d')  # 获取文件日期后缀
    p = subprocess.Popen(["ping.exe", '-n', '1', '-w', '1', ip],
                         stdin=subprocess.PIPE,
                         stdout=subprocess.PIPE,
                         stderr=subprocess.PIPE,
                         shell=True)
    out = p.stdout.read().decode('gbk')
    ping = re.search(r'来自..+|请求..+', out).group()
    now_time = dt.datetime.now().strftime('%F %T')
    file_name = 'ping%s_%s.txt' % (ip,nowdate)
    with open('C:\limi_ppt_log\%s' % file_name, 'a') as f:
        f.write(str(now_time) + '  ' + str(ping))

if __name__ == '__main__':
    hosts = ['www.baidu.com', '10.200.200.1', 'api-teacher.limiketang.com', 'www.qq.com']
    path = "C:\limi_ppt_log"
    if os.path.isdir(path):
        while True:
            time.sleep(1)
            for IP in hosts:
                #多线程同时执行
                thread = threading.Thread(target=ping_host,args=(IP,))
                thread.start()
    else:
        os.mkdir(path)
        while True:
            time.sleep(1)
            for IP in hosts:
                thread = threading.Thread(target=ping_host, args=(IP,))
                thread.start()
```

# ping程序（不带线程） subprocess：
* 自动判断目录存在否则生成存放日志目录
* 请求返回值只要超过1s则判定超时
* ping请求返回值加上时间戳
```python
# -*- coding:utf8 -*-
#!/usr/bin/python3
import subprocess
import re
import datetime as dt
import time
nowdate = dt.datetime.now().strftime('%Y%m%d')
class LinkState(object):
    def __init__(self,ip):
        self.ip = ip
        self.getLinkState(self.ip)

    # 获取链路状态
    def getLinkState(self,ip):
        #运行ping程序
        p = subprocess.Popen(["ping.exe",'-n','1', ip],
             stdin = subprocess.PIPE,
             stdout = subprocess.PIPE,
             stderr = subprocess.PIPE,
             shell = True)
        #得到ping的结果
        out = p.stdout.read().decode('gbk')
        # print(out.decode('gbk'))
        regex = re.compile(r'来自..+', re.M).findall(out)
        now_time = dt.datetime.now().strftime('%F %T')
        file_name = 'ping_ip_%s.txt' % nowdate
        with open('C:\limi_ppt_log\%s' % file_name, 'a') as f:
            f.write(str(now_time) + '  ' + str(regex) + '\n')

if __name__ == '__main__':
    ip = 'baidu.com'    #要ping的主机
    while True:
        time.sleep(1)
        LinkState(ip)
```
## 调用os.popen
注：此代码生成exe无法运行……原因待查找
```python
#!/bin/python3
#######################################################
# This program is to check the ping in the Live Room #
# Date: 2020-4-18                                     #
# Author: cuijianzhe                                  #
# Email: 598941324@qq.com                             #
#######################################################
import os
import re
import datetime as dt
import time
nowdate = dt.datetime.now().strftime('%Y%m%d')
def baidu():
    ping = os.popen('ping www.baidu.com -n 1').read()
    ping = re.compile(r'来自..+', re.M).findall(ping)
    now_time = dt.datetime.now().strftime('%F %T')
    file_name = 'ping_baidu_%s.txt' % nowdate
    with open('C:\limi_ppt_log\%s'%file_name, 'a') as f:
        f.write(str(now_time) + '  ' + str(ping) + '\n')

if __name__ == "__main__":
    while True:
        time.sleep(1)
        baidu()
```

## 生成exe文件
`D:\python_cuijianzhe\cuijianzhe\limi>pyinstaller -F -w  test.py
`

-w：关闭调试窗口
