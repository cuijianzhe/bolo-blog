title: 解决centos7系统搭建wordpress出现403问题
date: '2019-03-15 18:51:36'
updated: '2019-03-15 18:54:26'
tags: [wordpress, 博客搭建]
permalink: /articles/2019/03/15/1552647096813.html
---
使用习惯了LNMP环境了，在部署wordpress的时候出现了一个问题，修改完了[固定链接](https://blog.cjzshilong.cn/wordpress "【查看含有[固定链接]标签的文章】")页面找不到了，直接403了。因为是Nginx的服务器，连个htaccess文件也没有，网上找了大半圈，最后修改个Nginx的伪静态规则搞定，如下：
修改nginx配置文件就可以

```
  server {

        listen       80;
        server_name  localhost;
        root            /usr/local/nginx/html;

        if (-f $request_filename/index.html){
        rewrite (.*) $1/index.html break;
        }
        if (-f $request_filename/index.php){
        rewrite (.*) $1/index.php;
        }
        if (!-f $request_filename){
        rewrite (.*) /index.php;
        }
        rewrite /wp-admin$ $scheme://$host$uri/ permanent;
```

