title: kafka简单了解
date: '2022-04-12 17:35:36'
updated: '2022-04-12 17:35:36'
tags: [java]
permalink: /articles/2022/04/12/1649756136376.html
---
![](https://b3logfile.com/bing/20201120.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

#kafka可以以来zookeeper进行，最新版本kafka已经不需要额外再安装zookeeper了，它可以自己存储元数据信息了。#

##### kafka的核心概念

> Broker 消息中间件处理节点（服务器），一个节点就是一个broker，一个Kafka集群由一个或多个broker组成
> 
> Topic Kafka对消息进行归类，发送到集群的每一条消息都要指定一个topic
> 
> Partition 物理上的概念，每个topic包含一个或多个partition，一个partition对应一个文件夹，这个文件夹下存储partition的数据和索引文件，每个partition内部是有序的
> 
> Producer 生产者，负责发布消息到broker
> 
> Consumer 消费者，从broker读取消息
> 
> ConsumerGroup 每个consumer属于一个特定的consumer group，可为每个consumer指定group name，若不指定，则属于默认的group，一条消息可以发送到不同的consumer group，但一个consumer group中只能有一个consumer能消费这条消息

##### kafka的特点

高吞吐，顺序消费，分布式

###### 高吞吐

> 十万级别的吞吐量
> 
> 使用到了内存零拷贝，使用到了硬盘的顺序存储

###### 顺序消费

> 使用zookeeper存储offset，记录上一次访问到了那里

###### 分布式

> kafka支持分区存储数据，搭建集群

###### 适合大数据

> 大数据喜欢kafka，因为它是使用的流式处理数据，高吞吐量



