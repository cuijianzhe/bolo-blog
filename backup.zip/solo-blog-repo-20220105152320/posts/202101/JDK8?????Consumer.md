title: JDK8 函数式接口Consumer
date: '2021-01-15 11:41:02'
updated: '2021-02-03 10:03:00'
tags: [java]
permalink: /articles/2021/01/15/1610682061990.html
---
![](https://b3logfile.com/bing/20181015.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

#### 题目

`下面的字符串数组当中存有多条信息，请按照格式"姓名：xx，性别：xx"将信息打印出来，要求将打印姓名的动作作为第一个Consumer接口的Lambda实例，将打印性别的动作作为第二个Consumer接口的Lambda实例，将两个Consumer接口按照顺序拼接在一起。 `

`String [] str = {"迪丽热巴,女", "古力娜扎,女", "马尔扎哈,男"};`

#### 代码实现

```java
import java.util.function.Consumer;

/**
 * @author xuyuntong
 * @date 2021/1/14 10:20
 */
public class testmain {

    public static void main(String[] args) throws Exception {

        String [] str = {"迪丽热巴,女", "古力娜扎,女", "马尔扎哈,男"};

        Consumer<String> nameConsumer = testmain::printName;
        Consumer<String> sexConsumer = testmain::printSex;

        for (String s : str) {
            //当两个Consumer的参数一样时，可以用andThen方法来同时执行两个函数，并且将按照顺序执行
            //如果需要consumer传递多个参数，需要封装成一个对象，因为consumer只支持一个参数，所以要把多个参数封装成一个参数
            nameConsumer.andThen(sexConsumer).accept(s);
        }
    }

    public static void printName(String name){

        String[] split = name.split(",");
        System.out.print(split[0] + ": ");
    }

    public static void printSex(String sex){

        String[] split = sex.split(",");
        System.out.println(split[1]);
    }
}
```

