title: 排查java项目中的死锁和死循环
date: '2022-02-03 17:14:15'
updated: '2022-02-03 17:14:31'
tags: [排查]
permalink: /articles/2022/02/03/1643879655765.html
---
![](https://b3logfile.com/bing/20210501.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

##### 准备工作

**安装含有jstack的java版本**
`yum whatprovides '*/jmap'`
然后从查询结果里安装适合自己服务器的版本:
`yum install -y java-1.8.0-openjdk-devel-slowdebug-1:1.8.0.312.b07-2.al8.x86_64`

**下载可以制造死锁和死循环的项目代码**

[threaddemo0.0.1SNAPSHOT.jar](https://b3logfile.com/file/2022/02/thread-demo-0.0.1-SNAPSHOT-3d6f3c69.jar)

##### 运行项目

`nohup java -jar -Dserver.port=8088 thread-demo-0.0.1-SNAPSHOT.jar >all.log &`

##### 制造死锁

`curl http://127.0.0.1:8088/dead`

显示所有当前运行的pid
`jps`

使用`jstack pid`来查看死锁的信息
![image.png](https://b3logfile.com/file/2022/02/image-c56b3f23.png)

##### 制造死循环

`curl http://127.0.0.1:8088/loop`

使用`top -c`命令查看满负荷的那个java进程,我这里的进程id是436256
![image.png](https://b3logfile.com/file/2022/02/image-d931caa4.png)

使用`top -H -p 436256`查看cpu利用率高的**线程**,我这里利用率高的线程id是443233
![image.png](https://b3logfile.com/file/2022/02/image-22c86c15.png)

然后将443233这个高利用率的线程id转换为16进制的字符串
`printf "0x%x\n" 443233`,输出结果`0x6c361`
![image.png](https://b3logfile.com/file/2022/02/image-960b65cf.png)

然后根据进程id和线程id来定位死循环的信息
`jstack 436256 | grep -A 20 0x6c361`
![image.png](https://b3logfile.com/file/2022/02/image-fb7d5e0d.png)
可以看到问题出在了ThreadController.java:33,那么33行到底是什么代码呢:

![image.png](https://b3logfile.com/file/2022/02/image-902c7191.png)

