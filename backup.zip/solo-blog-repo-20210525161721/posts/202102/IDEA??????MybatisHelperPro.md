title: IDEA生成代码插件MybatisHelperPro
date: '2021-02-03 11:32:51'
updated: '2021-02-03 11:32:51'
tags: [java]
permalink: /articles/2021/02/03/1612323171006.html
---
![](https://b3logfile.com/bing/20190831.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

~~这年头好用的插件太少了,要么收费要么不好用~~

#### MybatisHelperPro

[LDevKit插件说明文档传送门](https://gitee.com/lsl-gitee/LDevKit/tree/master/MybatisHelperPro#https://gitee.com/lsl-gitee/LDevKit/blob/master/MybatisHelperPro/UsageInstructions.md)

[点击下载MybatisHelperPro1.0.6.zip](https://b3logfile.com/file/2021/02/MybatisHelperPro1.0.6-32c6817b.zip)

##### 但是但是!它目前只支持mysql5.x版本,甚至不支持8以上版本,oracle更别想了,期待它升级优化

![icon](https://gitee.com/lsl-gitee/LDevKit/raw/master/MybatisHelperPro/img/icon.png)

