title: Docker安装Oracle11g镜像
date: '2021-11-18 23:19:35'
updated: '2021-11-19 10:46:42'
tags: [oracle]
permalink: /articles/2021/11/18/1637248775558.html
---
![](https://b3logfile.com/bing/20210828.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

1. 拉取阿里云的oracle镜像
   `docker pull registry.aliyuncs.com/helowin/oracle_11g`
2. 查看镜像是否下载成功
   `docker images`
3. 运行该镜像
   `docker run -d -p 1521:1521 --name oracle registry.aliyuncs.com/helowin/oracle_11g `
4. 进入容器
   `docker exec -it oracle /bin/bash`
5. 配置容器内的oracle的环境变量和修改账户密码``

* [ ] `进入root账户su root,输入密码：helowin`
* [ ] `vi /etc/profile,并在文件的末尾添加下面内容`

```shell
export ORACLE_HOME=/home/oracle/app/oracle/product/11.2.0/dbhome_2
export ORACLE_SID=helowin
export PATH=$ORACLE_HOME/bin:$PATH
```

* [ ] `source /etc/profile`

6. 切换oracle用户
   `su oracle`
7. 设置数据库

* [ ] `使用sqlplus链接数据库 sqlplus /nolog`
* [ ] `切换到sysdba用户 connect /as sysdba`
* [ ] `显示当前使用用户 show user`
* [ ] 修改 sys 和 system 的密码并且修改密码的有效时间为无限

```sql
alter user system identified by oracle;
alter user sys identified by oracle;
ALTER PROFILE DEFAULT LIMIT PASSWORD_LIFE_TIME UNLIMITED;
```

* [ ] `查询SID值,供连接时使用 select INSTANCE_NAME from v$instance;`

##### 远程连接oracle数据库

![111111.png](https://b3logfile.com/file/2021/11/111111-9df89d72.png)

