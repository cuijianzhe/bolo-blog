title: 查看Spring的获取资源文件源码
date: '2021-01-14 11:48:56'
updated: '2021-01-14 11:48:56'
tags: [java]
permalink: /articles/2021/01/14/1610596136279.html
---
![](https://b3logfile.com/bing/20171105.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

```
InputStream fis = new DefaultResourceLoader().getResource(ResourceLoader.CLASSPATH_URL_PREFIX + trainResouceProperties.getFeeScheduleExportPath()).getInputStream();
```

#### 1.spring会判断是否包含classpath:字符串进行不同的逻辑，(本文只看包含classpath:的代码)

![1.png](https://b3logfile.com/file/2021/01/1-734ed683.png)

![2.png](https://b3logfile.com/file/2021/01/2-8eec17ab.png)

#### 2.由于Resource继承了InputStreamSource接口，所以可以直接调用其的getInputStream()方法

![3.png](https://b3logfile.com/file/2021/01/3-503fdfc8.png)

#### 3.在返回inputstream流对象时，还会将这个文件流资源放入一个弱引用的map集合里，从而达到关闭资源目的

![4.png](https://b3logfile.com/file/2021/01/4-2311a0df.png)

![5.png](https://b3logfile.com/file/2021/01/5-9e91cc89.png)

#### 4.总结

`先获取org.springframework.core.io.Resource对象的子类ClassPathResource，ClassPathResource对象的构造方法会创建java.lang.ClassLoader对象,java.lang.ClassLoader对象可以调用getResourceAsStream方法获取java.io.InputStream对象`

