title: Navicat12连接oracle
date: '2019-12-04 11:59:30'
updated: '2019-12-04 11:59:30'
tags: [oracle]
permalink: /articles/2019/12/04/1575431970752.html
---
![](https://img.hacpai.com/bing/20180331.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

选择本地的oracle里的oci.dll文件即可
![image.png](https://img.hacpai.com/file/2019/12/image-9e132017.png)



![image.png](https://img.hacpai.com/file/2019/12/image-7164e030.png)

