title: java发送邮件的代码（很nice版）
date: '2021-01-16 20:13:22'
updated: '2021-01-16 20:13:22'
tags: [java]
permalink: /articles/2021/01/16/1610799202500.html
---
![](https://b3logfile.com/bing/20200104.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

#### Github上Fork的代码

`https://github.com/biezhi/oh-my-email`

#### 支持附件，模板等订制功能。

[sendmail.rar](https://b3logfile.com/file/2021/01/sendmail-24ac9fb5.rar)

##### 163的邮箱作为发送方的时候，需要开启授权码并使用授权码作为密码，是一串字母和数字的结合。

