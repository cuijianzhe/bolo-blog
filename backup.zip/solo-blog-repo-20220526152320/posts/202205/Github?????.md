title: Github访问慢解决
date: '2022-05-18 19:26:40'
updated: '2022-05-18 19:26:40'
tags: [java]
permalink: /articles/2022/05/18/1652873200269.html
---
![](https://b3logfile.com/bing/20180704.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

```shell
#github related website
52.69.186.44 github.com
151.101.185.194 github.global.ssl.fastly.net
203.98.7.65 gist.github.com
13.229.189.0 codeload.github.com
185.199.109.153 desktop.github.com
185.199.108.153 guides.github.com
185.199.108.153 blog.github.com
18.204.240.114 status.github.com
185.199.108.153 developer.github.com
185.199.108.153 services.github.com
192.30.253.175 enterprise.github.com
34.195.49.195 education.github.com
185.199.108.153 pages.github.com
34.196.237.103 classroom.github.com
```

将上述ip映射修改hosts`C:\Windows\System32\drivers\etc\hosts`
然后`ipconfig/flushdns`刷新dns缓存。

