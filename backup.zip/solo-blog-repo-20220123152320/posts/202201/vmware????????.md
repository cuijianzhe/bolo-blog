title: vmware添加硬盘识别问题
date: '2022-01-04 15:24:35'
updated: '2022-01-04 15:24:35'
tags: [vmware]
permalink: /articles/2022/01/04/1641281074919.html
---
添加硬盘后，输入如下命令可识别：

```
echo '- - -' > /sys/class/scsi_host/host0/scan  #vm虚拟机扫描硬盘并识别硬盘
```

