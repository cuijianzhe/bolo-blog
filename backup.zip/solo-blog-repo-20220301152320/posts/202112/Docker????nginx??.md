title: Docker安装配置nginx镜像
date: '2021-12-03 14:05:35'
updated: '2021-12-03 14:05:35'
tags: [Docker]
permalink: /articles/2021/12/03/1638511535202.html
---
![](https://b3logfile.com/bing/20190405.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

#### 第一种方式：在容器内部修改配置文件实现代理

##### 拉取镜像

`docker pull nginx`

##### 启动容器

`docker run --name nginxweb -p 8080:80 -d nginx`
~此时可以打开网站 ip:8080 访问nginx首页~

##### 进入容器

`docker exec -it nginxweb /bin/bash`

##### 更新源的索引，这样才能获取到最新的软件包

`apt-get update`

##### 安装vim

`apt-get install vim`

<u>如果是将80映射为其他端口，需要注释掉最下面的那句默认的配置
#include /etc/nginx/conf.d/*.conf;</u>

##### 新增一个server配置如下，其他地方都不用动：

```xml
server{
	listen 80;
    server_name localhost;
    location /MerryChristmas/ {
		proxy_pass http://ip:63302/index/v1;
		proxy_redirect default;
    }
}
```

##### 访问代理的地址(:80可省略)

`ip:80/MerryChristmas`

##### 修改后校验配置文件是否ok

`nginx -t -c nginx.conf`

##### 重启nginx

`nginx -s reload`

#### 第二种方式：宿主机目录挂在配置文件的方式

##### 删除已创建的容器

`docker stop nginx`
`docker rm nginx`

##### 先建立几个文件夹用于存放数据卷的

`mkdir -p /docker/nginx`
`mkdir -p /docker/nginx/conf`
`mkdir -p /docker/nginx/www`
`mkdir -p /docker/nginx/logs`

##### 创建一个临时容器用来复制配置信息

`docker run --name nginx -p 80:80 -d nginx`

##### 删除临时容器

`docker stop nginx`
`docker rm nginx`

##### 创建带数据卷映射的容器

```shell
docker run \
--name nginx \
-p 80:80 \
-v /docker/nginx/nginx.conf:/etc/nginx/nginx.conf \
-v /docker/nginx/conf/conf.d:/etc/nginx/conf.d \
-v /docker/nginx/www:/usr/share/nginx \
-v /docker/nginx/logs:/var/log \
-d \
nginx
```

##### 访问ip进入nginx的欢迎页

`http://xxx.xx.xxx.xxx/`

##### 修改/docker/nginx/nginx.conf文件

`vim /docker/nginx/nginx.conf`

##### 修改完后重启nginx

`docker restart nginx`

##### 访问代理的地址(:80可省略):

`ip:80/MerryChristmas`


