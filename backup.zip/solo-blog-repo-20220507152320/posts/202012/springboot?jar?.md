title: springboot打jar包
date: '2020-12-02 15:07:24'
updated: '2020-12-02 15:07:24'
tags: [待分类]
permalink: /articles/2020/12/02/1606892844720.html
---
![](https://b3logfile.com/bing/20180815.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

### 替换下方build,然后使用maven package即可打jar包

```
<build>
        <plugins>
            <plugin>
                <groupId>org.springframework.boot</groupId>
                <artifactId>spring-boot-maven-plugin</artifactId>
                <configuration>
                    <mainClass>com.Application</mainClass>
                    <fork>true</fork><!-- 如果没有该项配置，肯呢个devtools不会起作用，即应用不会restart -->
                </configuration>
            </plugin>
        </plugins>

<resources>
        <resource>
            <directory>src/main/webapp</directory>
        </resource>
        <resource>
            <directory>src/main/resources</directory>
            <excludes>
                <exclude>**/*.xlsx</exclude>
                <exclude>**/*.xls</exclude>
                <exclude>**/*.docx</exclude>
                <exclude>**/*.doc</exclude>
            </excludes>
            <filtering>true</filtering>
        </resource>
        <resource>
            <directory>src/main/resources</directory>
            <includes>
                <include>**/*.xlsx</include>
                <include>**/*.xls</include>
                <include>**/*.docx</include>
                <include>**/*.doc</include>
            </includes>
            <filtering>false</filtering>
        </resource>
        <resource>
            <directory>src/main/java</directory>
            <includes>
                <include>**/*.xml</include>
            </includes>
        </resource>
    </resources>
</build>
```

