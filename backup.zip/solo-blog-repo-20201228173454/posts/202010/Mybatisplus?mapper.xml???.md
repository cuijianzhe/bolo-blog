title: Mybatis-plus 的 mapper.xml 热加载
date: '2020-10-23 18:33:40'
updated: '2020-10-23 19:07:32'
tags: [待分类]
permalink: /articles/2020/10/23/1603449220417.html
---
![](https://b3logfile.com/bing/20171227.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

#### mybatis-plus支持mapper.xml热加载新版本不再支持

`能支持的版本截止到 [v3.1.0] 2019.02.24`
![热加载移除.png](https://b3logfile.com/file/2020/10/热加载移除-9cd0af18.png)

```
#自动刷新mapper
mybatis-plus.global-config.refresh-mapper=true
````

`在支持的版本里头，如果想要更新mapper.xml的话，修改后build下就可以了，或者直接修改target里的mapper.xml文件，然后重新访问接口就可以调用修改后的xml了，不用重启项目！`

