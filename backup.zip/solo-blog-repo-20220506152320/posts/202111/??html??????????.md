title: 前端html之前传递中文参数乱码
date: '2021-11-30 14:40:03'
updated: '2021-11-30 14:40:03'
tags: [js]
permalink: /articles/2021/11/30/1638254403311.html
---
##### 场景：

使用`window.location.href="../../../cleangame/index.html?playgame=" + $('#email').val();`跳转到项目内一个页面，并且携带中文参数

##### 解决方法：

```js
//根据参数部分和参数名来获取参数值
function getParamString(paraPart,name) {
	var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)");
	var r = paraPart.substr(1).match(reg);
	if (r != null) return decodeURI(r[2]); return null;
}
function getParamFromUrl(name){
	var r = getParamString(window.location.search,name)
	return r
}
//使用：
var playname=decodeURI(getParamFromUrl('playgame'))
```

