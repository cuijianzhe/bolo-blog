title: Oracle sql对SORTNUM排序问题
date: '2021-03-08 16:04:25'
updated: '2021-03-08 16:04:25'
tags: [oracle]
permalink: /articles/2021/03/08/1615190665844.html
---
![](https://b3logfile.com/bing/20180312.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

#### 排序错乱的sql及其结果图:

```sql
SELECT
    NAME
FROM
    ST_SCHDULE_NUM
ORDER BY
    NAME ASC
```

![之前.png](https://b3logfile.com/file/2021/03/之前-262d78d2.png)

`可以看到上图中的1-10排在了1-2的前面,这是因为没有使用to_number(),针对此问题做出修改.`

`修改思路:先根据字符`-`前面的数字排序,再根据字符`-`后面的数字排序`

#### 排序正确的sql及其结果图:

```sql
SELECT
    NAME
FROM
    ST_SCHDULE_NUM
ORDER BY
    TO_NUMBER(substr( NAME, 1, instr( NAME, '-',- 1 ) - 1 )) ASC,
    TO_NUMBER(substr( NAME, instr( NAME, '-',- 1 ) + 1 )) ASC
```

![之后.png](https://b3logfile.com/file/2021/03/之后-706f340d.png)

