title: 从新认识for循环
date: '2021-01-20 10:34:11'
updated: '2021-01-20 10:34:11'
tags: [java]
permalink: /articles/2021/01/20/1611110051163.html
---
![](https://b3logfile.com/bing/20200324.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

#### 🌻🌻🌻for循环的最常用的基本结构🌻🌻🌻

```java
for(条件表达式1;条件表达式2;条件表达式3) {
语句块;
}
```

---




#### 🌻🌻🌻for循环执行过程剖析🌻🌻🌻

`for 循环语句执行的过程为：首先执行条件表达式 1 进行初始化，然后判断条件表达式 2 的值是否为 true，如果为 true，则执行循环体语句块；否则直接退出循环。最后执行表达式 3，改变循环变量的值，至此完成一次循环。接下来进行下一次循环，直到条件表达式 2 的值为 false，才结束循环，其运行流程如下图所示。`
```flowchart
st=>start: Start
op1=>operation: 条件表达式1
cond=>condition: 条件表达式2
op2=>operation: 语句块
op3=>operation: 条件表达式3
e=>end: End

st->op1(right)->cond
cond(true)->op2
op2->op3
op3(right)->cond
cond(false)->e
```

