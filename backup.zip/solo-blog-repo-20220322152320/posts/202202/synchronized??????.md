title: synchronized关键字的理解
date: '2022-02-13 09:28:30'
updated: '2022-02-13 09:28:30'
tags: [java]
permalink: /articles/2022/02/13/1644715710062.html
---
![](https://b3logfile.com/bing/20191002.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

###### 为什么要用synchornized?

由于多线程编程时引发的线程安全问题,所以要用synchornized.

多线程编程,会有原子性,可见性,有序性的问题

使用synchornized可以解决原子性,可见性和有序性需要使用volatile关键字解决

###### synchornized怎么使用?

当synchornized里填入成员变量或者成员方法或者代码块的时候,表示这个锁只针对这一个实例对象有效.

当synchornized里填入静态对象或者静态方法或者.class的时候,表示这个锁针对这个类的所有实例对象

###### 为什么在synchornized的小括号里填入任何对象都可以锁?

synchornized(this),synchornized("1"),synchornized(User.class),这几种都可以实现锁,因为无论是this还是"1"还是User.class,它们都含有java对象头MarkWord

###### 何为MarkWord?

在**Hotspot**虚拟机中，对象在内存中的存储布局，可以分为三个区域:对象头(Header)、实例数据
(Instance Data)、对齐填充(Padding)。

**mark-word**：对象标记字段占4个字节，用于存储一些列的标记位，比如：哈希值、轻量级锁的标
记位，偏向锁标记位、分代年龄等。

可以通过引入`ClassLayout`依赖打印对象头

```xml
<dependency>
	<groupId>org.openjdk.jol</groupId>
	<artifactId>jol-core</artifactId>
	<version>0.9</version>
</dependency>
```

编写代码查看加锁前对象头的变化和加锁后对象头的变化

```java
public class Demo {
	Object o=new Object();
	public static void main(String[] args) {
		Demo demo=new Demo(); //o这个对象，在内存中是如何存储和布局的。
		System.out.println(ClassLayout.parseInstance(demo).toPrintable());
		synchronized (demo){
		System.out.println(ClassLayout.parseInstance(demo).toPrintable());
		}
	}
}
```

###### 关于Synchronized锁的升级

Jdk1.6对锁的实现引入了大量的优化，如自旋锁、适应性自旋锁、锁消除、锁粗化、偏向锁、轻量级锁
等技术来减少锁操作的开销。
锁主要存在四中状态，依次是：**无锁状态、偏向锁状态、轻量级锁状态、重量级锁**状态，他们会随着竞
争的激烈而逐渐升级。

锁的状态不同,对象头MarkWord的信息也不相同.


![image202202081446079ipk1gi.png](https://b3logfile.com/file/2022/02/image-20220208144607-9ipk1gi-8efe08da.png)



默认情况下，偏向锁的开启是有个延迟，默认是4秒。为什么这么设计呢？
因为JVM虚拟机自己有一些默认启动的线程，这些线程里面有很多的Synchronized代码，这些
Synchronized代码启动的时候就会触发竞争，如果使用偏向锁，就会造成偏向锁不断的进行锁的升级和
撤销，效率较低。
通过下面这个JVM参数可以讲延迟设置为0.
`-XX:BiasedLockingStartupDelay=0`

###### CAS

cas的底层也是要用到锁的,只不过不同的底层操作系统用到的锁不一样.

锁升级主要步骤是：

* 先是通过偏向锁来获取锁，解决了虽然有同步但无竞争的场景下锁的消耗。
* 再是通过对象头的Mark Word来实现的轻量级锁，通过轻量级锁如果还有竞争，那么继续升级。
* 升级为自旋锁，如果达到最大自旋次数了，那么就直接升级为重量级锁，所有未获取锁的线程都阻塞等待。
  

