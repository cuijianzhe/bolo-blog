title: windows换一个声音主题
date: '2021-03-27 21:06:56'
updated: '2021-03-27 21:08:53'
tags: [windows]
permalink: /articles/2021/03/27/1616850416424.html
---
![](https://b3logfile.com/bing/20200707.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

**mac系统的内置默认提示音,要比windows好听的多,比如最经典的mac的那个倾倒废纸篓的咔一下的声响,很舒服,所以我想就像能不能windows的清空回收站操作也能有声音呢,还真让我给找到了**

#### 设置-个性化-主题-声音

![image.png](https://b3logfile.com/file/2021/03/image-521b54ff.png)

**这里可以发现,可以为清空回收站事件添加音效,这时候音效有两种,一种是系统内置的,虽然很多,但都很不好听,也就这个Ring10听着还行,那另一种还可以自己添加wav波形文件,也是一种常见的音频格式.**

#### 修改完记得将声音方案保存

![image.png](https://b3logfile.com/file/2021/03/image-94840bab.png)

#### 将声音与鼠标与壁纸与颜色等配置做成主题,并与他人分享你的主题,分享可保存为一个打开即用的压缩主题包很方便

![image.png](https://b3logfile.com/file/2021/03/image-7e992ef8.png)

