title: Oracle12不支持 wm_concat() 函数的解决办法
date: '2019-11-27 10:55:50'
updated: '2019-11-27 13:56:38'
tags: [oracle]
permalink: /articles/2019/11/27/1574823350052.html
---
![](https://img.hacpai.com/bing/20190726.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

### wm_concat() 
```sql
select wmsys.wm_concat(SKILL_GROUP_ID) from C_ULC_SKILL_GROUP
```

<details>
<summary>wm_concat支持的数据库版本</summary>

	Oracle Database 11g Enterprise Edition Release 11.2.0.1.0 - 64bit Production  
	PL/SQL Release 11.2.0.1.0 - Production  
	CORE    11.2.0.1.0      Production  
	TNS for 64-bit Windows: Version 11.2.0.1.0 - Production  
	NLSRTL Version 11.2.0.1.0 - Production~~
</details>

### xmlagg()
<details>
<summary>使用xmlagg函数，需要将上面的 wmsys.wm_concat函数修改如下：</summary>

	select SUBSTR(a.string,0,length(a.string)-1)   from (   
	select xmlagg(xmlparse(content upper(SKILL_GROUP_ID)||','   
	wellformed)).getclobval() as string   
	from C_ULC_SKILL_GROUP   
	) a  
</details>

