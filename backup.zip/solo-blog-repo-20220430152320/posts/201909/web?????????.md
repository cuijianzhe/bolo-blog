title: web状态码检测监控提醒
date: '2019-09-07 11:24:38'
updated: '2019-10-31 20:21:46'
tags: [Linux, Python]
permalink: /articles/2019/09/07/1567826678848.html
---
![image.png](https://img.hacpai.com/file/2019/09/image-84f43c22.png)


最近换了一款新皮肤[solo-nexmoe](https://github.com/InkDP/solo-nexmoe)，但是无奈一直间歇性报500，但是访问有时有时好的，所以找了一个脚本检测500出现的时间，第一时间去看情况。

## shell脚本
```bash
#!/bin/bash

URL=https://www.cjzshilong.cn
DING_URL=https://oapi.dingtalk.com/robot/send?access_token=XXXXXXXXXXXXXXXXXXXXXXX

function SendMessageToDingding(){ 
    curl "${DING_URL}" -H 'Content-Type: application/json' -d "
    {
        \"actionCard\": {
            \"title\": \"o(╥﹏╥)o Solo故障啦\", 
            \"text\": \"Web地址: $URL\n\n状态码: $1\n\n响应时间：${REQUEST_TIME}秒\n\n当前时间：${DT}\n\n\",
            \"hideAvatar\": \"0\", 
            \"btnOrientation\": \"0\", 
            \"btns\": [
            {
                \"title\": \"URL地址链接\", 
                \"actionURL\": \"$URL\"
            }
        ]
        }, 
        \"msgtype\": \"actionCard\"
    }"
} 

function httpRequest()
{
    DT=$(date)
    CODE=$(echo `curl -o /dev/null -s -m 10 --connect-timeout 10 -w %{http_code} "$URL"`)
    REQUEST_TIME=$(curl -o /dev/null -s -w "time_connect: %{time_connect}\ntime_starttransfer: %{time_starttransfer}\ntime_total: %{time_total}\n" "$URL" | awk /time_total/ | awk -F ': ' '{print $2}')
    if [[ "$REQUEST_TIME" > "2" ]] || [[ "$CODE" -ne 200 ]];then
         SendMessageToDingding $CODE
    else
         :
    fi
}

httpRequest
step=5
while true
do
    httpRequest
    sleep $step
done

```
## python脚本
```python
#!/bin/env python3
import requests
import json
import os
import sys
import subprocess
import time
url = "https://www.cjzshilong.cn"
api_url = "https://oapi.dingtalk.com/robot/send?access_token=89e3fdff70455b39xxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
headers = {'Content-Type': 'application/json;charset=utf-8'}
cur_time = time.asctime(time.localtime(time.time()))
CMD_code = '''echo `curl -o /dev/null -s -m 10 --connect-timeout 10 -w %{http_code} "https://www.cjzshilong.cn"`'''
code = subprocess.getoutput(CMD_code)
#print(code)
CMD_time = ''' curl -o /dev/null -s -w "time_connect: %{time_connect}\ntime_starttransfer: %{time_starttransfer}\ntime_total: %{time_total}\n" "https://www.cjzshilong.cn" | awk /time_total/ | awk -F ': ' '{print $2}' '''
res_time = subprocess.getoutput(CMD_time)
#print(res_time)

def msg(text):
    json_text= {
        "actionCard": {
            "title": "solo状态码报警",
            "text":
             text,
            "hideAvatar": "0",
            "btnOrientation": "0",
            "btns": [
                {
                    "title": "URL链接测试",
                    "actionURL": "https://www.cjzshilong.cn/"
                },
            ]
        },
        "msgtype": "actionCard"
    }
    Text = requests.post(api_url,data=json.dumps(json_text),headers=headers).json()
    return Text

def message():
    mess = "solo网站状态码测试 \n\n Web网址: %s \n\n 状态码：%s \n\n 网站响应时间: %s s \n\n 当前时间：%s \n\n"%(url,code,res_time,cur_time)
    return mess

if __name__ == '__main__':
    if code != '200' or res_time > '2':
      text = message()
      msg(text)
    else:
      pass

```
后台运行此脚本，触发规则发送[钉钉消息到自定义机器人](https://ding-doc.dingtalk.com/doc#/serverapi2/qf2nxq)。
![image.png](https://img.hacpai.com/file/2019/09/image-77d78bb7.png)

在此，也希望 @InkDP 能够给看下是不是还存在小漏洞（具体标签内容），我得环境就是docker+nginx+mysql没其他设置了。

