title: vnote初始配置
date: '2021-03-11 10:24:06'
updated: '2021-03-11 19:49:21'
tags: [笔记]
permalink: /articles/2021/03/11/1615429446249.html
---
![](https://b3logfile.com/bing/20200914.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

# 初始配置

## Markdown配置项

![image.png](https://b3logfile.com/file/2021/03/image-3dc0047a.png)

![image.png](https://b3logfile.com/file/2021/03/image-8be4680e.png)

![image.png](https://b3logfile.com/file/2021/03/image-458326c1.png)

## 编辑配置项

![image.png](https://b3logfile.com/file/2021/03/image-63198685.png)

![image.png](https://b3logfile.com/file/2021/03/image-b9555d0b.png)

# 采用gitee同步文件夹方式同步笔记

![image.png](https://b3logfile.com/file/2021/03/image-fc67f89e.png)

