title: 到底如何区分Spring和SpringMVC的注解？
date: '2021-01-14 17:36:46'
updated: '2021-01-14 17:36:53'
tags: [java]
permalink: /articles/2021/01/14/1610617006196.html
---
![](https://b3logfile.com/bing/20181201.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

#### 验证思路：首先要确定引入springmvc时候都需要引入哪些jar包。通过观察pom.xml中springboot整合springmvc的代码：

```
<groupId>org.springframework.boot</groupId>
<artifactId>spring-boot-starter-web</artifactId>
</dependency>
点击spring-boot-starter-web进去看发现：
<dependency>
<groupId>org.springframework</groupId>
<artifactId>spring-web</artifactId>
<version>5.0.5.RELEASE</version>
<scope>compile</scope>
</dependency>
<dependency>
<groupId>org.springframework</groupId>
<artifactId>spring-webmvc</artifactId>
<version>5.0.5.RELEASE</version>
<scope>compile</scope>
</dependency>
```

`说明spring-web、spring-webmvc这两个才是真正的springmvc所在jar包，org.springframework.spring-web:spring-web-5.0.5.RELEASE.jar中都有如下注解可供使用：`

* @ControllerAdvice
* @CookieValue
* @CrossOrigin
* @DeleteMapping
* @ExceptionHandler
* @GetMapping
* @InitBinder
* @Mapping
* @MatrixVariable
* @ModelAttribute
* @PatchMapping
* @PathVariable
* @PostMapping
* @PutMapping
* @RequestAttribute
* @RequestBody
* @RequestHeader
* @RequestMapping
* @RequestParam
* @RequestPart
* @ResponseBody
* @ResponseStatus
* @RestController
* @RestControllerAdvice
* @SessionAttribute
* @SessionAttributes
  `其中不乏我们熟悉的 @ResponseBody、@RequestBody、@RequestMapping、@RequestParam、@GetMapping、@RestController等restful风格接口api的注解。`

---

#### 那么去除掉springmvc之后，spring还有哪些我们经常用到的注解呢？

`spring-context-5.0.0.RELEASE.jar中包含了@Controller、@Service、@Repository、@Component等注解.spring-beans-5.0.0.RELEASE.jar中包含了@Autowired`

