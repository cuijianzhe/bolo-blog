title: windows使用sonarqube测试覆盖率
date: '2021-12-17 16:17:39'
updated: '2021-12-17 16:20:51'
tags: [java]
permalink: /articles/2021/12/17/1639729059800.html
---
![](https://b3logfile.com/bing/20210317.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

#### 准备工作

##### 准备jdk1.8、maven-3.6.0并配置环境变量

##### sonarqube下载(7.8版本之后不支持jdk1.8)

[下载官网](https://binaries.sonarsource.com/Distribution/sonarqube/sonarqube-7.6.zip)

##### mysql数据库(5.6-8.0)

#### 步骤二：sonarqube安装和配置篇

```shell
下载好sonarqube后，解压打开bin目录，启动相应OS目录下的StartSonar。
如本文演示使用的是win的64位系统，则打开E:\sonar\sonarqube-7.6\bin\windows-x86-64\StartSonar.bat
然后修改 sonarqube-7.6\conf\wrapper.conf
修改本地的javapath，注意后缀要配置为 \bin\java
将其中的 wrapper.java.command=C:\Users\JavaCoder\.jdks\corretto-1.8.0_312\bin\java
先使用管理员运行 InstallNTService.bat
然后使用管理员运行 StartNTService.bat
然后使用管理员运行 StartSonar.bat
然后访问 http://localhost:9000
```

##### 配置数据库(避免sonar重启后之前的分析结果丢失)

千万千万不要在sonar.properties里使用//进行注释，我以为//也是注释呢，复制别人的网页上的内容，结果坑了我好几个小时。

修改sonar.properties文件，添加mysql连接信息配置。
`\sonarqube-7.6\conf\sonar.properties`

```xml
sonar.jdbc.url=jdbc:mysql://xxx.xxx.xxx.xxx:3306/sonar?useUnicode=true&characterEncoding=utf8&rewriteBatchedStatements=true&useConfigs=maxPerformance
sonar.jdbc.username=root
sonar.jdbc.password=123456

sonar.login=admin
sonar.password=admin
```

#### 步骤三：登录

重启 `StartSonar.bat`,再次访问 `http://localhost:9000`，会稍微有点慢(大概需要6分钟)，因为要初始化数据库信息。
访问地址进行登录，初始的账号密码是：`admin/admin`，数据库有初始化的表信息。

#### 步骤四：汉化

登陆进去之后进行汉化
下载对应自己版本的汉化包
[查看适配sonarqube的汉化版本页面](https://gitcode.net/mirrors/sonarqubecommunity/sonar-l10n-zh?utm_source=csdn_github_accelerator)
[github下载jar包页面](https://github.com/xuhuisheng/sonar-l10n-zh/releases?after=sonar-l10n-zh-plugin-8.0&page=2)
将下载的汉化jar包，复制到 sonarqube-7.6\extensions\plugins目录下，
任务管理器-详细信息，kill掉所有java进程,重启 StartSonar.bat

#### 步骤五：配置项目

登录进后创建一个项目
然后设置名字，然后生成一个令牌
然后选择java，然后选择maven
然后在项目中使用命令进行测试：
`mvn sonar:sonar -Dsonar.projectKey=MerryChristmas -Dmaven.test.failure.ignore=true -Dsonar.host.url=http://localhost:9000 -Dsonar.login=24cafddfb012aa43587566df238a49ee5baffe2b`
分析完成后会出现如此提示：
ANALYSIS SUCCESSFUL, you can browse `http://localhost:9000/dashboard?id=MerryChristmas`
浏览器打开就可查看分析结果,**但此时跑出来的分析结果是没有运行单元测试的的**

#### 步骤6：配置jacoco

需要在pom加上这些配置：

```xml
<plugin>
    <groupId>org.apache.maven.plugins</groupId>
    <artifactId>maven-surefire-plugin</artifactId>
    <version>2.18.1</version>
</plugin>
<plugin>
    <groupId>org.jacoco</groupId>
    <artifactId>jacoco-maven-plugin</artifactId>
    <version>0.7.9</version>
    <configuration >
        <destFile>${project.build.directory}/jacoco.exec</destFile>
        <dataFile>${project.build.directory}/jacoco.exec</dataFile>
        <includes>
            <include>**/controller/**</include>
        </includes>
    </configuration>
    <executions>
        <execution>
            <goals>
                <goal>prepare-agent</goal>
            </goals>
        </execution>
        <execution>
            <id>report</id>
            <phase>prepare-package</phase>
            <goals>
                <goal>report</goal>
            </goals>
        </execution>
    </executions>
</plugin>
```

#### 步骤六：使用

然后需要先执行
`mvn clean org.jacoco:jacoco-maven-plugin:prepare-agent install -Dmaven.test.failure.ignore=true`

执行完后会出现jacoco.exec，并且此时已经可以查看 `target/site/jacoco/index.html`不过是不容易看懂的报告，需要用sonar优化显示

使用sonar优化测试报告(24cafddfb012aa43587566df238a49ee5baffe2b就是之前创建的令牌):
`mvn sonar:sonar -Dsonar.projectKey=MerryChristmas -Dmaven.test.failure.ignore=true -Dsonar.host.url=http://localhost:9000 -Dsonar.login=24cafddfb012aa43587566df238a49ee5baffe2b`

然后此时就发现测试类已经可以在sonar中出现了!

![image.png](https://b3logfile.com/file/2021/12/image-1c15e486.png)

