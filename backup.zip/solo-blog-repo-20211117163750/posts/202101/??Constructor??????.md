title: 重温Constructor构造函数（转载）
date: '2021-01-25 16:43:29'
updated: '2021-07-01 13:33:17'
tags: [java]
permalink: /articles/2021/01/25/1611564209687.html
---
![](https://b3logfile.com/bing/20180317.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

```java
class grandpaClass {

    public grandpaClass() {

        System.out.println("1912年 爷爷 出生了");

    }

}


class fatherClass extends grandpaClass {

    public fatherClass() {

        System.out.println("1956年 爸爸 出生了");

    }

}


class grandmaMotherClass {

    public grandmaMotherClass() {

        System.out.println("奶奶的妈妈 是 1890年出生的");

    }

}


class gandmaClass {

    static int year = 0;

    static grandmaMotherClass nnmm = new grandmaMotherClass();

    public gandmaClass() {

        year = 1911;

        System.out.println(year + "年 奶奶 出生了");

    }


    public gandmaClass(int count) {

        year += count;

        System.out.println(year + "年 奶奶的妹妹 出生了");

    }

}


class motherClass {

    public motherClass() {

        System.out.println("1957年 妈妈 出生了");

    }

}


public class javaclass extends fatherClass {

    motherClass b = new motherClass();

    static gandmaClass b1 = new gandmaClass();

    static gandmaClass b2 = new gandmaClass(2);

    public javaclass() {

        System.out.println("1981年 我 出生了");

    }

    public static void main(String[] args) {

        System.out.println("mainfunction is called");

        javaclass my = new javaclass();
    }

}
```

1. 先执行内部静态对象的构造函数，如果有多个按定义的先后顺序执行；而且静态类的构造函数只会被执行一次，只在其第一个对象创建时调用，即便是创建了同一个类的多个对象，例如main（）函数里b1,b2创建了同一个类的两个对象，但是grandmaMotherClass的构造函数只被执行了一次
2. 再执行父类的构造函数（c++中如果有多个，可按照左右先后顺序执行）
3. 再执行内部普通对象的构造函数
4. 最后执行该类本身的构造函数

`程序执行结果：`

```
奶奶的妈妈 是 1890年出生的
1911年 奶奶 出生了
1913年 奶奶的妹妹 出生了
mainfunction is called
1912年 爷爷 出生了
1956年 爸爸 出生了
1957年 妈妈 出生了
1981年 我 出生了
```

```text
在继承中代码的执行顺序为：

1.父类静态对象，父类静态代码块

2.子类静态对象，子类静态代码块

3.父类非静态对象，父类非静态代码块

4.父类构造函数

5.子类非静态对象，子类非静态代码块

6.子类构造函数4.父类构造函数
```


