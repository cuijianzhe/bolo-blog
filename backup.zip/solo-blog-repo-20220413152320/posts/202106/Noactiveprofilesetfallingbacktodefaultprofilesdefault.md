title: 'No active profile set, falling back to default profiles: default'
date: '2021-06-30 11:24:34'
updated: '2021-06-30 11:24:34'
tags: [java]
permalink: /articles/2021/06/30/1625023474146.html
---
![](https://b3logfile.com/bing/20180907.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

使用idea新建一个springboot项目时，直接运行启动发现出现此错误

解决方法：将依赖的`spring-boot-starter`改为`spring-boot-starter-web`

