title: word的三级标题不见了怎么恢复?
date: '2021-04-21 21:11:12'
updated: '2021-04-21 21:11:12'
tags: [office]
permalink: /articles/2021/04/21/1619010671950.html
---
![](https://b3logfile.com/bing/20190709.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

#### 编写宏,然后运行即可!

```
Sub 三级标题()
'
' 三级标题 宏
'
'

'
' 这是注释,For Each templ In ActiveDocument.ListTemplates ,获取指定文档的所有列表格式,并将每一种格式封装到 templ 这个对象里面
'
'
For Each templ In ActiveDocument.ListTemplates

'
' 这是注释,For Each lev In templ.ListLevels ,是获取该列表格式元素的所有级别,并将每一个级别封装到 lev 这个对象里面
'
'

For Each lev In templ.ListLevels


'
' 这是注释,lev.Font.Reset ,某个级别删除手动字符格式 (不使用样式应用的格式)。这一步是重中之重了,等同于恢复Font的初识设置
'
'

lev.Font.Reset


'
' 这是注释,Next lev ,循环下一个lev
'
'
Next lev

'
' 这是注释,Next templ ,循环下一个templ
'
'
Next templ
End Sub
```

