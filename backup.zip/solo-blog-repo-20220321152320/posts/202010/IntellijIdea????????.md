title: Intellij Idea 修改右键弹出菜单
date: '2020-10-30 14:15:17'
updated: '2020-10-30 14:15:17'
tags: [待分类]
permalink: /articles/2020/10/30/1604038517882.html
---
![](https://b3logfile.com/bing/20201029.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

#### File->Settings->Appearance & Behavior->Menus and Toolbar

Editor Popup Menu 是修改在文件内部(即代码行处)打开的右键菜单
Editor Tab Popup Menu 是修改在打开文件的tab页签上右击时修改的右键菜单
Project View Popup Menu 是修改在项目目录里右击文件或文件夹的右键菜单

