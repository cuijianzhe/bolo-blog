title: 多线程之同步屏障CyclicBarrier的使用
date: '2019-04-10 17:07:01'
updated: '2022-02-28 17:16:43'
tags: [进阶之路]
permalink: /articles/2019/04/10/1554887221480.html
---
![](https://b3logfile.com/bing/20180529.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

```
package com.example.demo;

import java.util.concurrent.BrokenBarrierException;
import java.util.concurrent.CyclicBarrier;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * @author xuyt
 * @date 2022/2/28 15:15
 */
public class CyclicBarrierTest {
    public static void main(String[] args) {
        ExecutorService executorService = Executors.newCachedThreadPool();
        CyclicBarrier cyclicBarrier = new CyclicBarrier(6);
        for (int i = 1; i <= 5; i++) {
            executorService.execute(() -> {
                System.out.println(Thread.currentThread().getName() + "开始等待其他线程");
                try {
                    cyclicBarrier.await();
                    System.out.println(Thread.currentThread().getName() + "执行完毕");
                } catch (InterruptedException | BrokenBarrierException e) {
                    e.printStackTrace();
                }
            });
        }
        executorService.shutdown();
    }
}
```

### 方法简介

CyclicBarrier有两个构造函数:

　　　　`CyclicBarrier(int parties): `int类型的参数表示有几个线程来参与这个屏障拦截

　　　　`CyclicBarrier(int parties,Runnable barrierAction): `当所有线程到达一个屏障点时,优先执行barrierAction这个线程的run().

　　　　`await(): `每个线程调用await(),表示我已经到达屏障点,然后当前线程被阻塞

