title: RocketMQ的安装
date: '2022-03-08 11:02:57'
updated: '2022-03-08 11:02:57'
tags: [RocketMQ]
permalink: /articles/2022/03/08/1646708577038.html
---
![](https://b3logfile.com/bing/20181015.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

###### 删除系统自带的openjdk

```shell
#查看
rpm -qa | grep java
#删除(把上一个命令看到的所有的jdk文件 用 如下命令删除)
rpm -e --nodeps java-1.8.0-openjdk-1.8.0.232.b09-0.el7_7.x86_64
...
```

###### #下载jdk1.8

```
wget -P /java8  --no-check-certificate -c --header "Cookie: oraclelicense=accept-securebackup-cookie" http://download.oracle.com/otn-pub/java/jdk/8u131-b11/d54c1d3a095b4ff2b6607d096fa80163/jdk-8u131-linux-x64.tar.gz
#解压
tar -xzvf jdk-8u131-linux-x64.tar.gz
#配置环境变量
JAVA_HOME=/java8/jdk1.8.0_131
CLASSPATH=$JAVA_HOME/lib/
PATH=$PATH:$JAVA_HOME/bin
export PATH JAVA_HOME CLASSPATH
```

#下载maven

```
wget https://mirrors.tuna.tsinghua.edu.cn/apache/maven/maven-3/3.6.3/binaries/apache-maven-3.6.3-bin.tar.gz
#解压
tar -zxvf apache-maven-3.6.3-bin.tar.gz
#配置环境变量 /usr/local/src地址可变
MAVEN_HOME=/usr/local/src/apache-maven-3.6.3
export MAVEN_HOME
export PATH=${PATH}:${MAVEN_HOME}/bin
```

#下载RocketMQ源码

```
wget https://github.com/apache/rocketmq/archive/rocketmq-all-4.9.3.tar.gz
#解压
tar -zxvf rocketmq-all-4.9.3.tar.gz
#编译源码 cd rocketmq-all-4.9.3
mvn -Prelease-all -DskipTests clean install -U
```



