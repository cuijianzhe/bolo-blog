title: Unable to import Maven project
date: '2020-09-24 17:02:04'
updated: '2020-09-24 17:46:55'
tags: [待分类]
permalink: /articles/2020/09/24/1600938124541.html
---
![](https://b3logfile.com/bing/20190907.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

我的（idea版本2019.3.1）解决的方式：

```
把VM options for importer 修改为: `-Xmx1024m` 就可以了。
很神奇的
```

还有一种方法是水友提供的，还未测试，如下：

```
删这个目录下的文件,然后重启电脑（ 2020.2的idea版本）
```

![image.png](https://b3logfile.com/file/2020/09/image-e6913243.png)

就是这篇博文救了我一条狗命
[Intellij IDEA整合Maven不能加载的问题 – CoLaBug.com](https://www.colabug.com/2020/0211/6977131/)

