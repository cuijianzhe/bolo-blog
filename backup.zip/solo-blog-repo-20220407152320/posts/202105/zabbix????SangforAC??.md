title: zabbix添加监控Sangfor AC监控
date: '2021-05-18 16:19:43'
updated: '2021-05-18 17:01:49'
tags: [Linux]
permalink: /articles/2021/05/18/1621325983655.html
---
因为zabbix自带的snmp模板只是标准的，没能监控自己想要的数据，所以从Sangfor设备导出mib文件，进行转换成zabbix识别的模板。

将mib文件导入zabbix服务器：

```
[root@monitor /usr/share/snmp/mibs]# snmptranslate -IR -On SANGFOR-GENERAL-MIB::cpuLoadAvg
.1.3.6.1.4.1.35047.1.6
[root@monitor /usr/share/snmp/mibs]# snmpwalk -v 2c -c limi@2018 10.200.101.1 .1.3.6.1.4.1.35047.1.6
SNMPv2-SMI::enterprises.35047.1.6.1.0 = STRING: "1.63"
SNMPv2-SMI::enterprises.35047.1.6.2.0 = STRING: "2.06"
SNMPv2-SMI::enterprises.35047.1.6.3.0 = STRING: "2.00"
[root@monitor /usr/share/snmp/mibs]# snmpget -v 2c -c limi@2018 10.200.101.1 .1.3.6.1.4.1.35047.1.6.1.0
SNMPv2-SMI::enterprises.35047.1.6.1.0 = STRING: "1.85"
```

至于上面的取值对象，从mib文件里面找

操作如下：

1. 安装依赖

```
yum -y install net-snmp-utils net-snmp-libs
yum -y install "perl(SNMP)" "perl(XML::Simple)"
```

3. 下载转换脚本：

```
curl https://raw.githubusercontent.com/cavaliercoder/mib2zabbix/master/mib2zabbix.pl > mib2zabbix
chmod a+x mib2zabbix
```

3. 查看mib信息：
   `snmptranslate -Tz -m ./SANGFOR-GENERAL-MIB.mib`

![image.png](https://b3logfile.com/file/2021/05/image-e81f82aa.png)

5. 转换

```
snmptranslate -Tz -m ./SANGFOR-GENERAL-MIB.mib | ./mibszabbix -e -o .1.3.6.1.4.1 -f Template_Sangfor_AC.xml -N Template_Sangfor_AC
```

最后，导入模板文件

参考：
https://www.zabbix.com/documentation/4.0/zh/manual/config/items/itemtypes/snmp/mib_files

