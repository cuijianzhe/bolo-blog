title: controller下载单个文件
date: '2020-12-31 17:48:22'
updated: '2022-03-30 16:07:23'
tags: [java]
permalink: /articles/2020/12/31/1609408102061.html
---
![](https://b3logfile.com/bing/20200822.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

#### controller里调用下载方法：然后controller下载方法返回值设置为void即可

```java
DownloadFile.download(request, response, "培训班材料合集", new File(folderPathDto.getTodoDownloadZipPath()));
````

#### 下载方法代码

```java
import org.apache.commons.io.IOUtils;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

/**
 * 下载文件工具类
 *
 * @author xuyuntong
 * @date 2020/12/31 15:29
 */
public class DownloadFile {

    /**
     * 用户浏览器关键字：IE
     */
    private static final String USER_AGENT_IE = "MSIE";
    /**
     * 后缀名
     */
    private static final String FILE_SUFFIX = ".zip";

    /**
     * 下载单个文件
     *
     * @param request 请求
     * @param response 响应
     * @param attachmentFileName 附件名称
     * @param file file对象
     */
    public static void download(HttpServletRequest request, HttpServletResponse response, String attachmentFileName, File file) {

        FileInputStream fis = null;
        BufferedInputStream bis = null;
        OutputStream os = null;

        String excelFileName = encodeDownloadFileName(request, attachmentFileName + FILE_SUFFIX);
        try {
            if(!file.exists()){
                response.setContentType("text/html; charset=utf-8");
                PrintWriter writer = response.getWriter();
                writer.print("<script language='javascript'>alert('"+"下载的文件不存在!"+"');</script>");
                writer.flush();
                writer.close();
            }else{
                response.setContentType("multipart/form-data");
                response.setHeader("Content-Disposition", "attachment; " +
                        "filename=\"" + excelFileName + "\";target=_blank");
                os = response.getOutputStream();
                fis = new FileInputStream(file);
                bis = new BufferedInputStream(fis);
                byte[] buffer = new byte[bis.available()];
                int i = bis.read(buffer);
                while(i != -1){
                    os.write(buffer, 0, i);
                    i = bis.read(buffer);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }finally {
            IOUtils.closeQuietly(bis);
            IOUtils.closeQuietly(fis);
            IOUtils.closeQuietly(os);
        }
    }

    /**
     * 根据不同的浏览器设置下载文件名称的编码
     *
     * @param request 请求request
     * @param fileName 文件名称
     * @return 文件名称
     */
    public static String encodeDownloadFileName(HttpServletRequest request, String fileName) {
        String userAgent = request.getHeader("User-Agent");
        if (userAgent.indexOf(USER_AGENT_IE) > 0) {// 用户在用IE
            try {
                return URLEncoder.encode(fileName, "UTF-8");
            } catch (UnsupportedEncodingException ignore) {}
        } else {
            try {
                return new String(fileName.getBytes(StandardCharsets.UTF_8), "ISO-8859-1");
            } catch (UnsupportedEncodingException ignore) {
            }
        }
        return fileName;
    }
}
```

