title: java翻转字符串几种方法
date: '2021-03-09 11:00:49'
updated: '2022-03-30 16:08:38'
tags: [java]
permalink: /articles/2021/03/09/1615258849247.html
---
![](https://b3logfile.com/bing/20200406.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

#### 1.使用StringBuilder的reverse()方法

```java
String str = "12345";
//1.使用StringBuilder类
String reverse = new StringBuilder(str).reverse().toString();
```

#### 2.使用charArray的for循环倒序输出

```java
String str = "12345";
//2.使用charArray的for循环倒序输出
char[] chars = str.toCharArray();
String result = "";
for (int i = chars.length - 1; i >= 0; i--) {
    result += chars[i];
}
System.out.println(result);
```

#### 3.使用栈Stack的先进后出原理

```java
String str = "12345";
//3.使用栈的先进后出原理
Stack<Character> stack = new Stack<>();
for (int i = 0; i < str.length(); i++) {
    stack.push(str.charAt(i));
}
while(!stack.isEmpty()){
    System.out.print(stack.pop());
}
```

#### 4.使用递归算法

```java
public class 递归 {

    //定义一个变量，作为比较值
    static int i = 0;

    public static void reverse(char [] chars, int k){
        //如果已经到了字符数组最大长度，就不再递归
        if (k == chars.length)
            return;
        //未到字符数组最大长度，继续递归
        reverse(chars, k + 1);
        //走到这一步，说明已经递归完成了，开始要从后往前挨个实现逻辑了
        if(i <= k){
            //定义一个中间临时值，然后将首位与末位的值进行互换
            char temp = chars[k];
            chars[k] = chars[i];
            chars[i++] = temp;
        }
    }

    public static void main(String[] args){
        String str = "java";
        char[] chars = str.toCharArray();
        //递归的次数取决于chars数组的长度，而且次数不能太多，否则容易造成栈内存溢出
        reverse(chars, 0);
        System.out.println(String.copyValueOf(chars));
    }
}
```

