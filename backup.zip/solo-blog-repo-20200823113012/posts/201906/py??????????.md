title: py项目中学到的知识梳理
date: '2019-06-14 17:40:33'
updated: '2019-10-31 20:24:12'
tags: [Python]
permalink: /articles/2019/06/14/1560505233857.html
---
![](https://img.hacpai.com/bing/20190609.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

两个月前需求：`使用python3做一个将观测数据编译产出成bufr数据的一个工具`
刚刚完成初版，其中的数据文件路径和数据内容格式还需要仔细核对，但整体逻辑已实现，剩下的工作时间可能会用来完善它

### Anaconda3
The open-source [Anaconda Distribution](https://docs.anaconda.com/anaconda/) is the easiest way to perform Python/R data science and machine learning on Linux, Windows, and Mac OS X. With over 11 million users worldwide, it is the industry standard for developing, testing, and training on a single machine, enabling _individual data scientists_ to:

*   Quickly download 1,500+ Python/R data science packages
*   Manage libraries, dependencies, and environments with [Conda](https://conda.io/docs/)
*   Develop and train machine learning and deep learning models with [scikit-learn](https://scikit-learn.org/stable/), [TensorFlow](https://www.tensorflow.org/), and [Theano](https://pypi.org/project/Theano/)
*   Analyze data with scalability and performance with [Dask](https://dask.org/), [NumPy](http://www.numpy.org/), [pandas](https://pandas.pydata.org/), and [Numba](http://numba.pydata.org/)
*   Visualize results with [Matplotlib](https://matplotlib.org/), [Bokeh](https://bokeh.pydata.org/en/latest/), [Datashader](http://datashader.org/), and [Holoviews](http://holoviews.org/)

### python读取xml
```
from xml.dom import minidom


def readXmlByTagName(path):
    with open(path, 'r', encoding='utf8') as fh:
        # 获取根节点
        root = minidom.parse(fh).documentElement
        # 节点类型：'ELEMENT_NODE'，元素节点； 'TEXT_NODE'，文本节点； 'ATTRIBUTE_NODE'，属性节点
        #print('节点类型:')
        return root
def getElementsByTagName(root,tagName):
    return root.getElementsByTagName(tagName)[0].childNodes[0].data
```

### DataFrame --- pandas
`pandas is an open source, BSD-licensed library providing high-performance, easy-to-use data structures and data analysis tools for the Python programming language.`
pandas的使用效果很腻害，在项目中主要用来读取如下图格式数据：
![image.png](https://img.hacpai.com/file/2019/06/image-f2b8afd5.png)

用到的pandas语法大概有:

* `pandas.read_table(data_path, sep=',',dtype = 'str')` 用来将数据读取出来
* `.shape[0]`用来获取数据的行数
* `.iloc`根据x和y轴来定位元素
*  [文档地址](https://pandas.pydata.org/pandas-docs/stable/reference/frame.html)

### 十进制转二进制
```
def Number2BinStr(num, size):

	'''
	整形转二进制字符的方法；
	:param num: 需要变换的整数；
	:param size:设定二进制宽度
	:return:
	'''
	fmt = '{0:0%db}' % size
	return fmt.format(num),size
```

### 字符串转二进制
```
def encode(s='', size=8):
   str_len = len(s)
   if str_len*8 <size:
      for i in range(0, int((size - str_len*8)/8)):
         s = s + ' '
   elif str_len*8 >size:
      pass
      # s = s
      # for i in range(0, int((str_len*8 - size)/8)):
   strs = ''
   for c in s:
      str_byte = bin(ord(c)).replace('0b', '')
      b = 8 - len(str_byte)
      for i in range(0, b):
         str_byte = '0'+str_byte
      strs = strs + str_byte
   return strs, size
```

### 求数据乘以比例因子加系数
```
def data_trasform_func(data, x, b):
   '''
   求数据乘以比例因子加系数的方法；
   :param data: 数据值；
   :param x:比例因子
   :param b:基准值
   :return:返回转换后的值；
   '''
   return int(data*math.pow(10, x) + b)
```

### 判断某文件夹下是否包含某个名称的文件，仅支持单个词模糊查询
```
#判断是否有数据文件
def search(path=".", name=""):
    result = []
    for item in os.listdir(path):
        item_path = os.path.join(path, item)
        if os.path.isdir(item_path):
            search(item_path, name)
        elif os.path.isfile(item_path):
            if name in item:
                result.append(item_path)
    return result
```
### bufr编码格式附件


[bufr编码格式规则.rar](https://img.hacpai.com/file/2019/06/bufr编码格式规则-f7a2b0f3.rar)


### 判断对象是不是空
```
if (type(None) != type(aapae33) and type(None) != type(aapae33object))
```

### 获取前一天时间
```
#UTC时间获取前一天

td = datetime.timedelta(days=1,hours=0,,seconds=0,microseconds=0)
print(datetime.datetime.utcnow().isoformat())
print((datetime.datetime.utcnow() - td).isoformat())

#本地时间获取前一天
now_time = datetime.datetime.now()
yes_time = now_time + datetime.timedelta(days=-1)
print(now_time)
print(yes_time)
```

### 获取文件指定行内容
```
import linecache
file_path = r'D:\work\python\test.txt'
line_number = 5
context = linecache.getline(file_path, line_number).strip()
```
