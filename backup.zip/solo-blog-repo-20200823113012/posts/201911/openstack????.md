title: openstack配额调整
date: '2019-11-15 15:50:34'
updated: '2019-11-23 19:39:51'
tags: [openstack, Linux]
permalink: /articles/2019/11/15/1573804234510.html
---

> **nova服务的功能和特点：**  
实例生命周期的管理  
管理计算资源  
网络和认证管理  
REST风格的API  
异步的一致性通信  
Hypervisor透明：支持Xen，XenServer/XCP，KVM，UML，VMware vSphere and Hyper-V

* 项目ID也就是租户ID
```
[root@controller ~]# openstack project list 
+----------------------------------+---------+
| ID                               | Name    |
+----------------------------------+---------+
| 4454e6deae3640b190d5ad2c3571e90d | service |
| f1942a0395ee4f91a9c6fcc4bd348cab | admin   |
+----------------------------------+---------+
```

# [openstack nova租户配额](https://docs.openstack.org/nova/pike/admin/quotas.html#view-and-update-compute-quotas-for-a-project-user)

## 查看默认配额

默认配额
```
[root@controller ~]# nova quota-defaults
+----------------------+-------+
| Quota                | Limit |
+----------------------+-------+
| instances            | 10    |
| cores                | 20    |
| ram                  | 51200 |
| metadata_items       | 128   |
| key_pairs            | 100   |
| server_groups        | 10    |
| server_group_members | 10    |
+----------------------+-------+
```
修改默认配额：例如
```
nova quota-class-update default --instances 15
```

例如：
* 查看项目的id：
```
[root@controller ~]# openstack project show -f value -c id service
4454e6deae3640b190d5ad2c3571e90d
```
或者
```
[root@controller ~]# openstack project list | awk '/service/ {print $2}'
4454e6deae3640b190d5ad2c3571e90d
```
* 获取项目配额：
```
[root@controller ~]# tenant=$(openstack project list | awk '/service/ {print $2}')
[root@controller ~]# nova quota-show --tenant $tenant
+----------------------+-------+
| Quota                | Limit |
+----------------------+-------+
| instances            | 10    |
| cores                | 20    |
| ram                  | 51200 |
| metadata_items       | 128   |
| key_pairs            | 100   |
| server_groups        | 10    |
| server_group_members | 10    |
+----------------------+-------+
```
## 更新项目的配额值：例如
```
nova quota-update --user $projectUser --floating-ips 12 $project
```
* 查看当前配额使用情况  
```  
[root@controller ~]# nova limits --tenant $tenant  
+------+-----+-------+--------+------+----------------+  
| Verb | URI | Value | Remain | Unit | Next_Available |  
+------+-----+-------+--------+------+----------------+  
+------+-----+-------+--------+------+----------------+  
+--------------------+------+-------+  
| Name               | Used | Max   |  
+--------------------+------+-------+  
| Cores              | 0    | 20    |  
| Instances          | 0    | 10    |  
| Keypairs           | -    | 100   |  
| RAM                | 0    | 51200 |  
| Server Meta        | -    | 128   |  
| ServerGroupMembers | -    | 10    |  
| ServerGroups       | 0    | 10    |  
+--------------------+------+-------+  
```

> 查看：
` nova help quota-update`

## [修改cinder配额：](https://docs.openstack.org/operations-guide/ops-quotas.html#view-and-update-compute-quotas-for-a-tenant-project)
* 默认配额：
```
[root@controller ~]# cinder quota-defaults 4454e6deae3640b190d5ad2c3571e90d
+----------------------+-------+
| Property             | Value |
+----------------------+-------+
| backup_gigabytes     | 1000  |
| backups              | 10    |
| gigabytes            | 1000  |
| groups               | 10    |
| per_volume_gigabytes | -1    |
| snapshots            | 10    |
| volumes              | 10    |
+----------------------+-------+
```

修改之后：
```
[root@controller ~]# cinder quota-update --volumes 15 4454e6deae3640b190d5ad2c3571e90d
+----------------------+-------+
| Property             | Value |
+----------------------+-------+
| backup_gigabytes     | 1000  |
| backups              | 10    |
| gigabytes            | 1000  |
| groups               | 10    |
| per_volume_gigabytes | -1    |
| snapshots            | 10    |
| volumes              | 15    |
+----------------------+-------+
```

* 查询配额：
```
[root@controller ~]# cinder quota-show $tenant 
+----------------------+-------+
| Property             | Value |
+----------------------+-------+
| backup_gigabytes     | 1000  |
| backups              | 10    |
| gigabytes            | 1000  |
| groups               | 10    |
| per_volume_gigabytes | -1    |
| snapshots            | 10    |
| volumes              | 15    |
+----------------------+-------+
```

## Dashboard配额修改
![image.png](https://img.hacpai.com/file/2019/11/image-d6e33137.png)

![image.png](https://img.hacpai.com/file/2019/11/image-422e4dbc.png)






