title: docker容器命名和资源配额控制(2)
date: '2019-03-27 09:36:26'
updated: '2019-10-31 20:26:48'
tags: [Linux]
permalink: /articles/2019/03/27/1553650586883.html
---
# 一、 docker容器命名和重命名
docker 容器命名和重命名
容器命名语法：docker run -d --name 容器实例名 容器镜像名 
要执行的命令容器重命名语法： docker rename 旧容器名 新容器名
## 1.1 运行一个名字为 docker1 的容器
```bash
[root@bogon ~]# docker run -itd --name docker1 docker.io/centos:latest /bin/bash 

0104b83de8bbb95ceceb6178c776623be8dd0a9b456e4a4bca5663152d6d2709
[root@bogon ~]# 
[root@bogon ~]# docker ps
CONTAINER ID        IMAGE                     COMMAND                  CREATED             STATUS              PORTS                NAMES
0104b83de8bb        docker.io/centos:latest   "/bin/bash"              7 seconds ago       Up 6 seconds                             docker1
6a1fc818a972        docker.io/centos:httpd    "/bin/sh -c /usr/l..."   14 hours ago        Up 14 hours         0.0.0.0:80->80/tcp   unruffled_yonath
[root@bogon ~]# 
```
## 1.2 将 docker1 容器重命名
```bash
[root@bogon ~]# docker rename docker1 docker2 

[root@bogon ~]# docker ps
CONTAINER ID        IMAGE                     COMMAND                  CREATED              STATUS              PORTS                NAMES
0104b83de8bb        docker.io/centos:latest   "/bin/bash"              About a minute ago   Up About a minute                        docker2
6a1fc818a972        docker.io/centos:httpd    "/bin/sh -c /usr/l..."   14 hours ago         Up 14 hours         0.0.0.0:80->80/tcp   unruffled_yonath
```

# 二、创建docker容器实例指定主机名
## 2.1创建 docker 容器实例时指定主机名
语法：docker run  -it  --name  容器名 -h 指定主机名 镜像   /bin/bash 
```bash
[root@bogon ~]# docker run  -it --name docker3 -h cuijianzhe centos bash 

[root@cuijianzhe /]# hostname 
cuijianzhe
[root@cuijianzhe /]# 
```
## 2.2 让docker容器开机自启动
语 法 ： docker run --restart=always  -itd   --name   容 器 名 镜 像  /bin/bash
参数：--restart=always   #在容器退出时总是重启容器。
```bash
[root@bogon ~]# docker run --restart=always -itd --name test centos bash 
f2afaa28abc8ce569e5ba172ff48014f892bff653e14af0ea4b2554562daca0b
[root@bogon ~]# 
[root@bogon ~]# systemctl restart docker 
[root@bogon ~]# docker ps 
CONTAINER ID        IMAGE               COMMAND             CREATED             STATUS              PORTS               NAMES
f2afaa28abc8        centos              "bash"              37 seconds ago      Up 6 seconds                            test
```
扩展：

Docker 容器的重启策略如下：
no，默认策略，在容器退出时不重启容器
on-failure，在容器非正常退出时（退出状态非 0），才会重启容器 
on-failure:3，在容器非正常退出时重启容器，最多重启 3 次
always，在容器退出时总是重启容器
unless-stopped，在容器退出时总是重启容器，但是不考虑在 Docker  守护迚程启动时就已经停止了的容器

如果创建时未指定 --restart=always ,可通过 update 命令设置

语法：docker update --restart=always 容器 ID 或名字
```bash
[root@bogon ~]# docker run -itd --name test111 centos bash 

ec295f4752e2e008020d0ef19569b72f6e715ed9e3fbb619cb068115ecdb2e4e
[root@bogon ~]# docker update --restart=always test111 
test111
[root@bogon ~]# systemctl stop docker 
[root@bogon ~]# systemctl start  docker 
[root@bogon ~]# docker ps | grep 111
ec295f4752e2        centos              "bash"              About a minute ago   Up 7 seconds                            test111
[root@bogon ~]# docker pa 
docker: 'pa' is not a docker command.
See 'docker --help'
[root@bogon ~]# docker ps
CONTAINER ID        IMAGE               COMMAND             CREATED              STATUS              PORTS               NAMES
ec295f4752e2        centos              "bash"              About a minute ago   Up 24 seconds                           test111
f2afaa28abc8        centos              "bash"              7 minutes ago        Up 24 seconds                           test
```
只设置了开机启动的实例会启动
# 三、docker容器配额控制值CPU
Docker容器资源配额控制
启劢 docker 容器时，指定 cpu，内存，硬盘性能等的硬件资源使用份额
Docker 通过 cgroup 来控制容器使用的资源配额，包括 CPU、内存、磁盘三大方面，基本覆盖了常见的资源配额和使用量控制。
cgroup 概述：
cgroup 是 Control Groups 的缩写，是 Linux 内核提供的一种可以限制、记录、隔离迚程组所使用的物理资源(如 cpu、memory、磁盘 IO 等等) 的机制，被 LXC、docker 等很多项目用于实现进程资源控制。cgroup 将任意进程进行分组化管理的 Linux 内核功能。cgroup 本身是提供将过程迚行分组化管理的功能和接口的基础结构，I/O 或内存的分配控制等具体的资源管理功能是通过这个功能来实现的。

为什么要进行硬件配额？
当多个容器运行时，防止某容器把所有的硬件都占用了。（比如一台被黑的容器，有可能把所有的资 源都占用）
## 3.1 给容器分配512权重的cpu使用份额
```bash
[root@bogon ~]# docker run --help | grep cpu-shares

  -c, --cpu-shares int                        CPU shares (relative weight)
[root@bogon ~]# docker run -it --cpu-shares 512 centos /bin/bash

[root@301f8326465a /]# cat /sys/fs/cgroup/cpu/cpu.shares 
512
```
cpu 配额参数：-c, --cpu-shares int    CPU shares (relative weight) 在创建容器时指定容器所使用的 CPU 份额值。cpu-shares 的值丌能保证可以获得 1 个 vcpu 戒者多少 GHz 的 CPU 资源，仅仅只是一个弹性的加权值。
默认每个 docker 容器的 cpu 份额值都是 1024，也手动修改份额值，超过 1024。单独一个容器的同时运行多个容器时，容器的 cpu 加权的效果才能体现出来。

# 3.2 CPU core核心控制
参数：--cpuset 可以绑定 CPU
对多核  CPU  的服务器，docker  还可以控制容器运行限定使用哪些  cpu  内核和内存节点，即使用
--cpuset-cpus 和--cpuset-mems 参数。对具有 NUMA 拓扑（具有多 CPU、多内存节点）的服务器尤其有用， 可以对需要高性能计算的容器迚行性能最优的配置。如果服务器只有一个内存节点，则
--cpuset-mems 的配置基本上不会有明显效果。
