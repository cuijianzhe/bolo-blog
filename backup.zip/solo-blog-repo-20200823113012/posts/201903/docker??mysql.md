title: docker安装mysql
date: '2019-03-27 17:22:53'
updated: '2019-10-31 20:26:30'
tags: [Linux]
permalink: /articles/2019/03/27/1553678573009.html
---
1.  mysql容器搭建

* 更新yum镜像源，下载docker的阿里镜像源：
`[root@bogon ~]# wget -O /etc/yum.repos.d/CentOS-Base.repo http://mirrors.aliyun.com/repo/Centos-7.repo
`

*  安装docker所需的依赖包:
`[root@bogon ~]# yum -y install yum-utils device-mapper-persistent-data lvm2 container-selinux
`

* 添加docker的阿里源
`[root@bogon ~]# yum-config-manager --add-repo https://download.docker.com/linux/centos/docker-ce.repo
`
* 启动docker
```
[root@bogon ~]# yum install docker -y
```
*  安装阿里云加速器
登录自己的阿里云账号进入一下页面即可复制专属加速器地址

[https://cr.console.aliyun.com/#/accelerator](https://cr.console.aliyun.com/#/accelerator)

```bash
sudo mkdir -p /etc/docker

sudo tee /etc/docker/daemon.json <<-'EOF'
{
  "registry-mirrors": ["https://vtbf99sa.mirror.aliyuncs.com"]
}
EOF
sudo systemctl daemon-reload
sudo systemctl restart docker
```

* 拉取所需镜像

```bash
[root@bogon ~]# docker pull nginx:latest 
[root@bogon ~]# docker pull mysql:8 
[root@bogon ~]# docker pull bitnami/php-fpm

```

* 创建文件夹

```bash
[root@bogon ~]# mkdir -pv /docker/www     #网站根目录

mkdir: 已创建目录 "/docker"
mkdir: 已创建目录 "/docker/www"
[root@bogon ~]# mkdir -pv /docker/nginx/conf.d/
      #nginx配置文件
mkdir: 已创建目录 "/docker/nginx"
mkdir: 已创建目录 "/docker/nginx/conf.d/"
[root@bogon ~]# mkdir -pv /docker/mysql 
mkdir: 已创建目录 "/docker/mysql"
    #数据库文件夹
[root@bogon ~]# 
```

* 构建mysql容器
```bash
[root@bogon ~]# docker run -d -p 3306:3306 -e MYSQL_ROOT_PASSWORD=598941324 -v /docker/mysql:/var/lib/mysql --name mysql8 mysql:8

528438949af0625fd7a936c49768d953c238f2d633614d2ef9cca74b9254843c
[root@bogon ~]# docker exec -it mysql8 /bin/bash 

root@528438949af0:/# mysql -uroot -p598941324
mysql: [Warning] Using a password on the command line interface can be insecure.
Welcome to the MySQL monitor.  Commands end with ; or \g.
Your MySQL connection id is 11
Server version: 8.0.15 MySQL Community Server - GPL

Copyright (c) 2000, 2019, Oracle and/or its affiliates. All rights reserved.

Oracle is a registered trademark of Oracle Corporation and/or its
affiliates. Other names may be trademarks of their respective
owners.

Type 'help;' or '\h' for help. Type '\c' to clear the current input statement.

mysql> use mysql;
Reading table information for completion of table and column names
You can turn off this feature to get a quicker startup with -A

Database changed
mysql> ALTER USER 'root'@'%' IDENTIFIED WITH mysql_native_password BY 'root';
Query OK, 0 rows affected (0.00 sec)

mysql> alter  user 'root'@'%' identified by '598941324';
Query OK, 0 rows affected (0.01 sec)

mysql> FLUSH PRIVILEGES;
Query OK, 0 rows affected (0.01 sec)

mysql> 
```
* 在宿主机上测试是否能连接mysql容器
```bash
[root@bogon ~]# 

[root@bogon ~]# docker inspect mysql8 --format='{{.NetworkSettings.IPAddress}}'
    #查看数据库ip
172.17.0.2
[root@bogon ~]# 
[root@bogon ~]# mysql -h172.17.0.2 -uroot -p598941324
      #重置密码
Warning: Using a password on the command line interface can be insecure.
Welcome to the MySQL monitor.  Commands end with ; or \g.
Your MySQL connection id is 12
Server version: 8.0.15 MySQL Community Server - GPL

Copyright (c) 2000, 2016, Oracle and/or its affiliates. All rights reserved.

Oracle is a registered trademark of Oracle Corporation and/or its
affiliates. Other names may be trademarks of their respective
owners.

Type 'help;' or '\h' for help. Type '\c' to clear the current input statement.

mysql> 
```
mysql到此搭建完成

