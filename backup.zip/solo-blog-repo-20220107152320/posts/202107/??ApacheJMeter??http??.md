title: 使用Apache JMeter压测http接口
date: '2021-07-26 19:23:08'
updated: '2021-07-26 19:23:08'
tags: [java]
permalink: /articles/2021/07/26/1627298588078.html
---
![](https://b3logfile.com/bing/20180310.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

##### 下载

[Apache JMeter最新版官方下载地址](https://jmeter.apache.org/download_jmeter.cgi)

##### 打开

解压后双击bin目录中的ApacheJMeter.jar即可打开

##### 配置线程组

添加线程组
![image.png](https://b3logfile.com/file/2021/07/image-9545193d.png)
设置线程数
![image.png](https://b3logfile.com/file/2021/07/image-ec9e2747.png)

##### 添加结果分析项

右击线程组进行添加察看结果树

![image.png](https://b3logfile.com/file/2021/07/image-c087ef25.png)

右击线程组进行添加聚合报告
![image.png](https://b3logfile.com/file/2021/07/image-0985a8ab.png)
右击线程组进行添加图形结果

![image.png](https://b3logfile.com/file/2021/07/image-c9e6ad1f.png)

##### 添加HTTP信息头管理器

![image.png](https://b3logfile.com/file/2021/07/image-b48bd559.png)

json传参的接口需要添加 `Content-Type:application/json`

![image.png](https://b3logfile.com/file/2021/07/image-461df504.png)

##### 添加HTTP请求

![image.png](https://b3logfile.com/file/2021/07/image-6439b3e0.png)

##### 设置路径和传参

![image.png](https://b3logfile.com/file/2021/07/image-0ec6fc6f.png)

到此已经全部配置完毕啦！

